# Flujo 1: Cotizador — Salesforce Seguros del Pichincha

## Precondiciones y Bloqueadores (Setup)

Antes de ejecutar los flujos principales, se han identificado los siguientes requisitos:

- **Autenticación y Login:** La estrategia OTP ya está resuelta mediante `storage-state/salesforce-auth.json`. El bootstrap de sesión se ejecuta con `npm run salesforce:auth:bootstrap` y guarda la sesión autenticada para ser reutilizada en todos los tests.
- **Datos de Prueba (Data Driven):** Se requiere un listado de clientes válidos preexistentes en el sistema. No todos los registros sirven para iniciar el flujo. Los datos deben estar centralizados en `src/utils/constants.ts` o en un fixture separado.

---

## Descripción del Flujo

Este es el primer flujo del proceso. Se centra en la búsqueda del cliente, la validación de sus datos y la generación de la solicitud de cotización.

**URL de entrada:** `https://tu_empresa.net.lightning.force.com/lightning/page/home`

**Rol del usuario:** Agente comercial / cotizador

---

## Pasos del Flujo

| Paso | Acción del Sistema / Usuario | Datos Requeridos | Validación Esperada |
| ---- | ---------------------------- | --------------- | ------------------- |
| 1 | Buscar al cliente | Documento de identidad del cliente | El sistema debe mostrar un listado o resultado desplegable en la parte inferior |
| 2 | Seleccionar cliente | Clic en el registro desplegado | Redirección a la pantalla con los datos personales del cliente |
| 3 | Revisar información del cliente | N/A | Verificar que todos los campos obligatorios estén llenos y que la información sea correcta |
| 4 | Ingresar datos de cotización | "Actividades personales", "Nombre de la cotización" (ej. "cotizar") | Los campos deben aceptar el texto ingresado sin errores |
| 5 | Finalizar solicitud | Clic en finalizar/enviar | El flujo de cotización termina y la solicitud se transfiere automáticamente al área comercial |

---

## Casos de Prueba a Cubrir

### Happy Path

1. Buscar cliente con documento válido → aparece resultado desplegable → seleccionar cliente → datos personales visibles y completos → ingresar actividades personales y nombre de cotización → finalizar → solicitud transferida a comercial

### Validaciones Clave

- El campo de búsqueda por documento debe mostrar resultados en el desplegable inferior
- Al seleccionar el cliente, se debe redirigir a la pantalla de datos personales
- Los campos obligatorios deben estar presentes y llenos
- El campo "Nombre de la cotización" debe aceptar texto libre
- El botón de finalizar debe estar habilitado solo cuando los datos requeridos están completos
- Tras finalizar, el sistema debe confirmar la transferencia al área comercial

---

## Page Objects Necesarios

- `CotizadorPage` — Encapsula: búsqueda de cliente, selección de resultado, revisión de datos personales, ingreso de datos de cotización, finalización de solicitud

---

## Datos de Prueba de Ejemplo

```typescript
export const TEST_DATA_COTIZADOR = {
  clienteDocumento: '1234567890',       // Cédula de cliente válido en el sandbox
  nombreCotizacion: 'cotizar',
  actividadesPersonales: 'Actividades personales',
};
```
