# Especificación: Creación de Prospecto (Línea Vida)

## Historia de Usuario

Como asesor comercial
Quiero registrar un nuevo prospecto en el sistema Salesforce leyendo desde un spec local
Para iniciar el flujo de ventas de la línea de Vida de forma ágil y sin conexión a Jira.

## Criterios de Aceptación

1. Precondiciones:

- El asesor debe iniciar sesión en Salesforce correctamente.
- El sistema debe cargar la página de Inicio (Home).

1. Navegación al formulario:

- El usuario debe dirigirse a la sección o pestaña de "Prospectos".
- El usuario debe hacer clic en la opción para crear un "Nuevo" prospecto.

1. Llenado de datos de la Línea Vida:

- Se debe rellenar la Identificación con el valor: "1723111105".
- Se debe rellenar el Teléfono con el valor: "0991234567".
- Se debe rellenar el Correo Electrónico con el valor: "cliente.vida@test.com".
- Se debe seleccionar "Vida" en el campo de Línea de Negocio.

1. Validación de Guardado:

- El usuario debe guardar el formulario.
- El sistema debe confirmar la creación exitosa mostrando la pantalla de detalle del nuevo prospecto o un mensaje emergente de éxito.