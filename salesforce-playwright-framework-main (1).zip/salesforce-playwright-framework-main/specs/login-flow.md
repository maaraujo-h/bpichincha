# Salesforce Login Flow

## Flow Description

This flow validates access to Salesforce and authenticated entry to Lightning Home.

- Entry URL: `https://tu_empresa.net.lightning.force.com/lightning/page/home`
- User role: Salesforce authenticated user

## Preconditions

- Valid credentials are configured (`SALESFORCE_USERNAME`, `SALESFORCE_PASSWORD`)
- MFA/OTP may be required depending on Salesforce security policies
- `storage-state/salesforce-auth.json` should be refreshed with `npm run salesforce:auth:bootstrap`

## Core Steps

1. Open Salesforce home entry URL
2. If redirected to login, provide username and password
3. If MFA is requested, complete verification
4. Confirm Lightning Home is visible
5. Persist refreshed authenticated storage state for reuse

## Validation Rules

- Login page or Lightning Home must be reachable from entry URL
- After authentication, Lightning Home must be visible
- On success, storage state must be saved for subsequent flows
