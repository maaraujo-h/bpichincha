# Flujo 2: Comercial — Salesforce Seguros del Pichincha

## Descripción del Flujo

Este flujo es **consecuente al Flujo 1 (Cotizador)** y es manejado por otra área de negocio. Se activa una vez que la solicitud de cotización ha sido finalizada y transferida.

**URL de entrada:** `https://tu_empresa.net.lightning.force.com/lightning/page/home`

**Rol del usuario:** Agente del área comercial

**Precondición obligatoria:** El Flujo 1 (Cotizador) debe haberse completado exitosamente y la solicitud transferida al área comercial.

---

## Flujo 2A: Gestión Comercial (Prospecto + Oportunidad)

| Paso | Acción del Sistema / Usuario | Condición Previa | Resultado Esperado |
| ---- | ---------------------------- | ---------------- | ------------------ |
| 1 | Iniciar flujo comercial | La solicitud de cotización debe estar finalizada en el Flujo 1 | Acceso a la gestión comercial del cliente |
| 2 | Crear Prospecto | N/A | El prospecto queda registrado en el sistema |
| 3 | Crear Oportunidad | El prospecto debe estar creado | El flujo finaliza con la oportunidad comercial generada exitosamente |

---

## Flujo 2B: Interacción Manual (Módulo Call Center / Seguros)

Flujo paralelo para la gestión de siniestros o atención al cliente. Ejecutado por un **Agente de Call Center**.

| Elemento | Descripción / Datos a Ingresar |
| -------- | ----------------------------- |
| Rol del Usuario | Agente de Call Center |
| Dirección de Contacto | "BIM" (El cliente llamó al agente) o "DON" (El agente llamó al cliente) |
| Tipo de Contacto | Web, Chatbot, etc. |
| Acción Principal | Ingresar a "Interacción" > "Interacción Manual" |
| Datos del Reporte | Requerimientos del cliente, reporte de siniestros (ej. "se chocó") y detalles del incidente |
| Fin del Flujo | Tras generar la interacción manual, el ticket o reporte pasa a otra sección para su resolución |

---

## Casos de Prueba a Cubrir

### Flujo 2A — Happy Path

1. Desde el área comercial, acceder a la gestión del cliente → Crear Prospecto → verificar registro en sistema → Crear Oportunidad → verificar oportunidad comercial generada

### Flujo 2B — Happy Path

1. Navegar a "Interacción" > "Interacción Manual" → seleccionar dirección de contacto (BIM/DON) → seleccionar tipo de contacto → ingresar datos del reporte/siniestro → finalizar → ticket generado y trasladado a resolución

### Validaciones Clave

- El flujo comercial solo debe estar disponible si existe una cotización previa transferida
- La creación de Prospecto debe confirmar el registro en el sistema
- La Oportunidad solo puede crearse si el Prospecto existe
- En Interacción Manual, los campos "Dirección de Contacto" y "Tipo de Contacto" deben ser selectores con las opciones definidas
- El reporte de siniestros debe aceptar texto libre
- Al finalizar la interacción, debe redirigir o confirmar que el ticket pasó a resolución

---

## Page Objects Necesarios

- `ComercialPage` — Encapsula: acceso a gestión comercial, creación de Prospecto, creación de Oportunidad
- `InteraccionManualPage` — Encapsula: navegación al módulo Interacción > Interacción Manual, selección de dirección/tipo de contacto, ingreso de reporte, finalización

---

## Datos de Prueba de Ejemplo

```typescript
export const TEST_DATA_COMERCIAL = {
  direccionContactoBIM: 'BIM',
  direccionContactoDON: 'DON',
  tipoContactoWeb: 'Web',
  tipoContactoChatbot: 'Chatbot',
  reporteSiniestro: 'El cliente reporta accidente de tránsito, el vehículo se chocó.',
};
```
