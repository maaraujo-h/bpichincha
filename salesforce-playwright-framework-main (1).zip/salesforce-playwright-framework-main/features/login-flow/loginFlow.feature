@salesforce @auth
Feature: Salesforce Login flow - Signin
  As a Salesforce user
  I want to access the Salesforce lightning home URL
  So I can reach either the login page or the authenticated home safely

  Background:
    Given the user opens the Salesforce home entry page

  @login-page-validation
  Scenario: Validate Salesforce login page loads correctly
    Then the Salesforce login page should be visible
    And the URL should contain "lightning.force.com"
    And a primary Salesforce action should be visible
    And the Salesforce username input should be visible

  @login-success
  Scenario: Sign in to Salesforce successfully
    When the user signs in to Salesforce with configured credentials
    Then the Salesforce lightning home should be visible

@login-failed @guest
  Scenario: Validate error message on invalid credentials
    When the user attempts to sign in with username "usuario_invalido@test.com" and password "ClaveFalsa123!"
    Then an authentication error message should be visible