@salesforce @commercial-flow @opportunity
Feature: Salesforce commercial flow - Opportunity Creation
  As a Salesforce commercial agent
  I want to manage business opportunities
  So that I can generate new quotations for the business pipeline

  Background:
    Given the user is authenticated in Salesforce
    Then the Salesforce lightning home should be visible

  Scenario: Create a new opportunity with valid data successfully
    When the user clicks the "Flujo Comercial" menu in Salesforce
    And the user clicks the "Crear Oportunidad" button on the Commercial Flow screen
    And the user enters "1713175071" in the Search Identification Number or Prospect Name field
    And the user clicks the "Seleccionar" button
    And the user selects "Tradicional" in the Business Line field
    And the user enters "BAN" in the Broker / Sponsor field
    And the user enters "1000,00" in the Estimated Premium field
    And the user enters "10" in the Validity Days field
    And the user selects "FIDELIDAD" in the Branch Options and moves it to Selected
    And the user clicks the "Guardar" button
    And the Salesforce opportunity should be created successfully showing a confirmation message
    Then the system should automatically redirect to the created Salesforce opportunity screen