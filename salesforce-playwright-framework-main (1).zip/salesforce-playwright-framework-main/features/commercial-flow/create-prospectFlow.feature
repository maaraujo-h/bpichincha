@salesforce @commercial-flow @prospect
Feature: Salesforce commercial flow - Prospect Creation
  As a Salesforce commercial agent
  I want to manage prospects
  So that I can generate new quotations for the business pipeline

  Background:
    Given the user is authenticated in Salesforce
    Then the Salesforce lightning home should be visible

  Scenario: Create a new prospect with valid data successfully
    When the user clicks the "Flujo Comercial" menu in Salesforce
    And the user clicks the "Crear Prospecto" button on the Commercial Flow screen
    And the user selects "CEDULA" in the Identification Type field
    And the user enters "1713175071" in the Identification Number field
    And the user enters "Juan" in the First Name field
    And the user enters "Mario" in the Middle Name field
    And the user enters "Perez" in the First Last Name field
    And the user enters "Martin" in the Second Last Name field
    And the user enters "0987654321" in the Phone field
    And the user enters "usuario@test.com" in the Salesforce prospect email field
    And the user selects "Tradicional" in the Business Line field
    And the user enters "BROKER" in the Broker / Sponsor field
    And the user enters "1000.00" in the Estimated Premium field
    And the user enters "10" in the Validity Days field
    And the user selects "TRANSPORTE" in the Branch Options and moves it to Selected
    And the user clicks the "Guardar" button
    And the Salesforce prospect should be created successfully showing a confirmation message
    Then the system should automatically redirect to the created Salesforce prospect screen