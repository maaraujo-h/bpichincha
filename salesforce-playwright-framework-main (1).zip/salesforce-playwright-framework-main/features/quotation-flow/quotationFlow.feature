@salesforce @quotation
Feature: Salesforce quotation flow - Quotation Client
  As a Salesforce quotation agent
  I want to search for an existing client and register their data
  So that I can generate a quotation for the available products

  Background:
    Given the user is authenticated in Salesforce
    Then the Salesforce lightning home should be visible

Scenario Outline: Complete quotation flow with different delegated signature methods
    When the user accesses the "Cotizador" menu in Salesforce
    And the user enters "1716524564" in the client search field
    And the user clicks the "Buscar" button on the quotation screen
    And the user selects the found person with identification "1716524564"
    And the user clicks the "Guardar" button in the quotation form
    And the user selects the disease "ACALASIA" in the options and moves it to selected
    And the user enters "Preexistencia" in the Preexistence field
    And the user enters the current date in the treatment date field
    And the user enters "Observaciones" in the Treatment or Observation field
    And the user selects "Tipo de venta" in the sales type combobox
    And the user selects "Producto" in the product combobox
    And the user selects "AÑOS DORADOS PLAN EG 25.000 G5 PROPIEDAD" in the Plan combobox
    And the user selects "Mensual" in the payment frequency combobox
    And the user marks the account holder option as "Si"
    And the user selects "DÉB. AUT. CORRIENTE" in the Methods combobox
    And the user selects "BANCO DINERS CLUB" in the Banks combobox
    And the user enters "1234567890" in the Account Number field
    And the user clicks the "Buscar" button to assign a beneficiary
    And the user selects the first beneficiary from the results list
    And the user clicks the "Guardar" button in the quotation form
    And the user clicks the "Agregar" button for the relationship
    And the user selects the relationship "HIJO" in the combobox
    And the user selects "100" in the Participation and Benefit combobox
    And the user manages the delegated signature using the "<Method>" method
    And the user clicks the "<ButtonAction>" button in the quotation form
    And the user clicks the "Aplicar" button in the quotation form
    Then the system should transition to the delegated signature confirmation screen

    Examples:
      | Method     | ButtonAction   |
      | Correo     | Enviar código  |
      | Celular    | Enviar código  |
      | Presencial | Ha firmado     |