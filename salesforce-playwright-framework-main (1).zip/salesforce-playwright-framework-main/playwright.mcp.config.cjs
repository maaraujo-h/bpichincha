require('dotenv').config();
// Habilita requerir módulos TypeScript directamente (transpileOnly, ver tsconfig.json)
// para reutilizar la ÚNICA fuente de verdad de configuración (RUNTIME_CONFIG) y evitar
// que este archivo mantenga su propia copia divergente de la lectura de variables de entorno.
require('ts-node/register');

const { RUNTIME_CONFIG } = require('./src/config/runtime.config');
const { BROWSER_CONFIG } = require('./src/config/browser.config');
const { TIMEOUTS } = require('./src/utils/constants');

module.exports = {
  testDir: './specs',
//testDir: './features',
  timeout: RUNTIME_CONFIG.timeout,
  use: {
    baseURL: RUNTIME_CONFIG.baseURL,
    ignoreHTTPSErrors: true,
    navigationTimeout: TIMEOUTS.NAVIGATION,
    actionTimeout: TIMEOUTS.SHORT,
    trace: RUNTIME_CONFIG.traceOnFailure ? 'on-first-retry' : 'off',
    screenshot: RUNTIME_CONFIG.screenshotOnFailure ? 'only-on-failure' : 'off',
    video: RUNTIME_CONFIG.videoOnFailure ? 'retain-on-failure' : 'off',
    storageState: RUNTIME_CONFIG.salesforceStorageStatePath,
    viewport: BROWSER_CONFIG.viewport,
    locale: BROWSER_CONFIG.locale,
    timezoneId: 'Europe/Madrid',
  },
  projects: [
    {
      name: 'chromium',
      use: {
        browserName: 'chromium',
        headless: RUNTIME_CONFIG.headless,
      },
    },
  ],
};