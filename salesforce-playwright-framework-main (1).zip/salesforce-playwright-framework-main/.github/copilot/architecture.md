# 🏗️ Arquitectura del Proyecto

---
applyTo: "**/*"

---

## Estructura de Directorios

```text
playwright-bdd-pom-template/
├── features/               # Feature files (Gherkin)
│   ├── domain/            # Agrupados por dominio/módulo
│   └── *.feature          # Archivos de features
├── src/
│   ├── config/            # Configuración del navegador
│   ├── pages/             # Page Objects (POM)
│   ├── steps/             # Step Definitions
│   ├── support/           # Hooks y configuración
│   └── utils/             # Utilidades compartidas
├── docs/                  # Documentación del proyecto
└── scripts/               # Scripts de utilidad
```

---

## Principios de Arquitectura

### 1. Separación de Responsabilidades

- **Features**: Especificación de comportamiento en lenguaje natural (Gherkin)
- **Steps**: Orquestación de acciones y mapeo Gherkin → código
- **Pages**: Interacción con elementos del DOM y navegación
- **Utils**: Lógica reutilizable y funciones auxiliares

### 2. Single Responsibility Principle (SRP)

- Cada clase/módulo debe tener una única razón para cambiar
- Page Objects representan una única página o componente
- Steps definitions no contienen lógica de negocio, solo orquestación

### 3. Don't Repeat Yourself (DRY)

- Reutiliza steps existentes antes de crear nuevos
- Centraliza selectores y constantes
- Usa BasePage para funcionalidad común
- Factory Pattern para crear instancias

### 4. Escalabilidad

- Estructura modular por dominio/funcionalidad
- Factory Pattern para crear instancias de Page Objects
- Configuración centralizada en `utils/constants.ts`
- Hooks centralizados en `support/hooks.ts`

---

## Flujo de Ejecución

```mermaid
graph TD
    A[Feature File .feature] --> B[Cucumber Parser]
    B --> C[Step Definition]
    C --> D[Page Object]
    D --> E[BasePage]
    E --> F[Playwright Browser API]
    F --> G[Browser/DOM]
    
    H[Hooks] --> C
    I[Utilities] --> D
    J[Logger] --> C
    J --> D
```

### Descripción del Flujo

1. **Feature File**: Define el comportamiento en Gherkin
2. **Cucumber Parser**: Interpreta y ejecuta escenarios
3. **Step Definition**: Mapea pasos Gherkin a código TypeScript
4. **Page Object**: Encapsula interacciones con la página
5. **BasePage**: Proporciona métodos comunes heredados
6. **Playwright API**: Ejecuta acciones en el navegador
7. **Hooks**: Configuración before/after de escenarios
8. **Utilities**: Funciones helper (logger, constants, etc.)

---

## Capas del Proyecto

### 🎭 Capa de Presentación (Features)

```Text
features/
├── cart/
│   └── add-product-from-plp.feature
├── search/
│   └── product-search.feature
└── navigation/
    └── site-navigation.feature
```

**Responsabilidad**: Definir comportamiento esperado en lenguaje natural

### 🔄 Capa de Orquestación (Steps)

```Text
src/steps/
├── common.steps.ts
├── cart.steps.ts
├── search.steps.ts
└── authentication.steps.ts
```

**Responsabilidad**: Mapear pasos Gherkin a llamadas de Page Objects

### 📄 Capa de Abstracción (Pages)

```Text
src/pages/
├── BasePage.ts
├── HomePage.ts
├── SearchResultsPage.ts
└── CartPage.ts
```

**Responsabilidad**: Encapsular interacciones con el DOM

### ⚙️ Capa de Configuración (Config + Support)

```Text
src/
├── config/
│   └── browser.config.ts
└── support/
    └── hooks.ts
```

**Responsabilidad**: Configuración global y lifecycle hooks

### 🛠️ Capa de Utilidades (Utils)

```Text
src/utils/
├── constants.ts
├── logger.ts
├── page-factory.ts
├── test-data.ts
└── wait-helpers.ts
```

**Responsabilidad**: Funciones reutilizables y constantes

---

## Patrones de Diseño Implementados

### 1. Page Object Model (POM)

Encapsula lógica de interacción con páginas web.

```typescript
export class HomePage extends BasePage {
  private readonly selectors = { /* ... */ };
  
  async search(term: string): Promise<void> {
    // Lógica de búsqueda
  }
}
```

### 2. Factory Pattern

Gestiona creación e instanciación de Page Objects.

```typescript
export class PageFactory {
  static getHomePage(context: any, page: Page): HomePage {
    if (!context.homePage) {
      context.homePage = new HomePage(page);
    }
    return context.homePage;
  }
}
```

### 3. Template Method Pattern

BasePage define métodos comunes que heredan todas las páginas.

```typescript
export abstract class BasePage {
  constructor(protected page: Page) {}
  
  protected async waitForElement(selector: string): Promise<void> {
    // Implementación común
  }
}
```

### 4. Singleton Pattern (implícito en Factory)

Reutiliza instancias de Page Objects dentro del mismo contexto.

---

## Convenciones de Naming

### Features

```Text
✅ CORRECTO: add-product-from-plp.feature
❌ INCORRECTO: KAN-1212.feature, test-1.feature
```

### Steps

```Text
✅ CORRECTO: cart.steps.ts, search.steps.ts
❌ INCORRECTO: KAN-1212.steps.ts, test-cart-1.steps.ts
```

### Pages

```Text
✅ CORRECTO: HomePage.ts, SearchResultsPage.ts
❌ INCORRECTO: home-page.ts, search_page.ts
```

### Utilities

```Text
✅ CORRECTO: page-factory.ts, wait-helpers.ts
❌ INCORRECTO: PageFactory.ts, WaitHelpers.ts
```

---

## Gestión de Estado

### Contexto de Cucumber (World)

```typescript
// En hooks.ts
Before(async function (this: ICustomWorld) {
  this.context = {}; // Inicializa contexto por escenario
});

// En steps
When('...', async function (this: ICustomWorld) {
  const homePage = PageFactory.getHomePage(this.context, this.page);
});
```

### Almacenamiento de Instancias

- Page Objects se almacenan en `context` del escenario
- Se reutilizan dentro del mismo escenario
- Se limpian al finalizar el escenario (After hook)

---

## Manejo de Dependencias

### Instalación

```bash
npm install
```

### Dependencias Principales

- `@playwright/test`: Browser automation
- `@cucumber/cucumber`: BDD framework
- `typescript`: Type safety
- `winston`: Logging
- `cucumber-html-reporter`: Reporting

### Dev Dependencies

- `@types/*`: TypeScript definitions
- `eslint`: Linting
- `prettier`: Code formatting

---

## Configuración de Entornos

### playwright.config.ts

```typescript
export default defineConfig({
  testDir: './features',
  timeout: 60000,
  use: {
    baseURL: process.env.BASE_URL || 'https://www.example.com',
    headless: process.env.HEADLESS !== 'false',
  },
});
```

### cucumber.js

```javascript
module.exports = {
  default: {
    require: ['src/**/*.ts'],
    parallel: 3,
    retry: 2,
  },
};
```

---

## Escalabilidad y Mantenimiento

### ✅ Buenas Prácticas

1. **Un Feature por dominio funcional** (no por ticket)
2. **Steps reutilizables** entre múltiples features
3. **Page Objects pequeños** y enfocados
4. **Selectores centralizados** en objeto `selectors`
5. **Logging estratégico** para debugging
6. **Factory Pattern** para gestión de instancias

### ❌ Anti-Patrones a Evitar

1. ❌ Features/Steps con IDs de tickets en nombres
2. ❌ Lógica de negocio en Step Definitions
3. ❌ Assertions en Page Objects
4. ❌ Selectores hardcodeados en múltiples lugares
5. ❌ Dependencias entre escenarios
6. ❌ Tests que dependen del orden de ejecución

---

## Referencias

- **Documentación completa**: Ver `docs/ARCHITECTURE.md`
- **Ejemplos de código**: Ver `src/pages/`, `src/steps/`
- **Features de ejemplo**: Ver `features/`

---

**📌 Recuerda**: La arquitectura busca **separación de responsabilidades**, **reutilización** y **mantenibilidad** a largo plazo.
