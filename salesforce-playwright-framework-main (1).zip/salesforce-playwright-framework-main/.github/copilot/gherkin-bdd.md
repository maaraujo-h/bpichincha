# 🥒 Cucumber BDD (Gherkin)

---
applyTo: "features/**/*.feature, cucumber.js"
---

## Organización de Features

### ❌ INCORRECTO - Un feature por cada test o por ticket

```
features/
├── login-valid-user.feature
├── login-invalid-user.feature
├── KAN-1212-add-to-cart.feature  # ❌ No usar ID de ticket como nombre
└── kan-1212-remove-cart.feature  # ❌ No usar ID de ticket como nombre
```

### ✅ CORRECTO - Features agrupados por dominio/funcionalidad

```
features/
├── authentication/
│   ├── login.feature              # Todos los escenarios de login
│   └── registration.feature       # Todos los escenarios de registro
├── search/
│   └── product-search.feature     # Búsqueda de productos
├── cart/
│   ├── add-product-from-plp.feature    # Añadir desde listado
│   ├── add-product-from-pdp.feature    # Añadir desde detalle
│   └── remove-product.feature          # Eliminar productos
└── navigation/
    └── site-navigation.feature    # Navegación general
```

---

## 🎯 Reglas de Organización

1. **Subdirectorios por dominio funcional**: `cart/`, `search/`, `authentication/`, etc.
2. **Nombres descriptivos de acción**: `add-product-from-plp.feature` (no `KAN-1212.feature`)
3. **Referencia al ticket en comentarios**: `# Ticket: KAN-1212` dentro del feature
4. **Tags incluyen el ID del ticket**: `@KAN-1212 @cart @smoke`

---

## Estructura de Features

```gherkin
# language: es
@search @smoke
Característica: Búsqueda de productos en un sitio web
  Como usuario del sitio web
  Quiero buscar productos
  Para encontrar lo que necesito comprar

  Antecedentes:
    Dado el usuario está en la página principal del sitio web
    Y el usuario acepta las cookies

  @critical
  Escenario: Búsqueda exitosa de producto existente
    Cuando el usuario busca "portátil"
    Entonces debería ver resultados de búsqueda para "portátil"
    Y debería haber al menos 1 producto en los resultados

  Esquema del escenario: Búsqueda con diferentes términos
    Cuando el usuario busca "<término>"
    Entonces debería ver resultados de búsqueda para "<término>"

    Ejemplos:
      | término      |
      | televisión   |
      | smartphone   |
      | auriculares  |
```

---

## Mejores Prácticas de Gherkin

### 1. Usa lenguaje de negocio, no técnico

```gherkin
# ❌ INCORRECTO
Cuando hago clic en el botón con id "btn-search"

# ✅ CORRECTO
Cuando el usuario busca "portátil"
```

### 2. Sigue el patrón Given-When-Then

- **Given**: Estado inicial (precondiciones)
- **When**: Acción del usuario
- **Then**: Resultado esperado (verificación)

```gherkin
Dado el usuario está en la página de productos  # Estado inicial
Cuando el usuario hace clic en "Añadir"        # Acción
Entonces el producto debería estar en el carrito  # Verificación
```

### 3. Mantén los escenarios independientes

```gherkin
# ✅ CORRECTO - Escenario independiente
Escenario: Añadir producto al carrito
  Dado el usuario está en la página principal
  Y el usuario acepta las cookies
  Cuando el usuario busca "portátil"
  Y el usuario hace clic en "Añadir" del primer producto
  Entonces el producto debería estar en el carrito

# ❌ INCORRECTO - Depende de escenario previo
Escenario: Eliminar producto del carrito
  # ¿Cómo llegó el producto al carrito?
  Cuando el usuario elimina el producto
  Entonces el carrito debería estar vacío
```

### 4. Usa tags estratégicamente

```gherkin
@smoke @critical      # Pruebas críticas
@regression          # Suite de regresión completa
@wip                 # Work in progress
@skip               # Temporalmente deshabilitado
@KAN-1212           # Referencia al ticket de Jira
```

### 5. Escribe escenarios declarativos, no imperativos

```gherkin
# ❌ IMPERATIVO (cómo hacer las cosas)
Cuando hago clic en "Buscar"
Y escribo "portátil" en el campo de búsqueda
Y presiono Enter

# ✅ DECLARATIVO (qué se quiere lograr)
Cuando el usuario busca "portátil"
```

### 6. Agrupa escenarios relacionados en un mismo feature

- Máximo 10-15 escenarios por feature
- Si crece más, considera dividir por sub-funcionalidad

```gherkin
# ✅ CORRECTO - Feature con escenarios relacionados
Característica: Búsqueda de productos

  Escenario: Búsqueda con término válido
  Escenario: Búsqueda sin resultados
  Escenario: Búsqueda con caracteres especiales
  Esquema del escenario: Búsqueda con diferentes términos
```

### 7. Usa Background para setup común

```gherkin
Antecedentes:
  Dado el usuario está en la página principal de un sitio web
  Y el usuario acepta las cookies

# Estos pasos se ejecutan antes de CADA escenario
```

### 8. Documenta la referencia al ticket de Jira

```gherkin
# Referencia: KAN-1212
# URL: https://plataformas.atlassian.net/browse/KAN-1212
@KAN-1212
Escenario: Añadir producto desde PLP
  # ... pasos
```

---

## Scenario Outline - CRÍTICO para mantenibilidad

### ❌ INCORRECTO - Features duplicados

```gherkin
# features/cart/add-product-fashion.feature
Escenario: Añadir producto de moda
  Cuando el usuario busca "zapatillas nike"
  # ... resto de pasos

# features/cart/add-product-electronics.feature  
Escenario: Añadir producto de electrónica
  Cuando el usuario busca "Ordenador Portátil"
  # ... resto de pasos (DUPLICADO - solo cambia el término)
```

### ✅ CORRECTO - Scenario Outline con Examples

```gherkin
# features/cart/add-product-from-plp.feature
@cart @plp
Característica: Añadir producto desde PLP

  Esquema del escenario: Añadir producto al carrito desde PLP
    Cuando el usuario busca "<término_búsqueda>"
    Y el usuario espera a que se carguen los resultados
    Entonces debería haber al menos 1 producto en los resultados
    Cuando el usuario hace clic en "Añadir" del primer producto
    Entonces el producto debería agregarse al carrito

    @KAN-1212 @fashion
    Ejemplos: Productos de moda
      | término_búsqueda |
      | zapatillas nike  |

    @KAN-1212 @electronics
    Ejemplos: Productos de electrónica
      | término_búsqueda  |
      | Ordenador Portátil |
```

### Ventajas del Scenario Outline

- ✅ Un solo lugar para mantener la lógica del escenario
- ✅ Fácil añadir nuevos casos (solo agregar línea en Examples)
- ✅ Tags específicos por grupo de ejemplos (@KAN-1212, @KAN-1212)
- ✅ Reduce duplicación de código Gherkin
- ✅ Facilita cambios en la lógica (un solo lugar vs N archivos)

### Cuándo usar Scenario Outline

- ✅ Escenarios con **mismos pasos** pero **datos diferentes**
- ✅ Múltiples tickets de Jira con **flujos idénticos**
- ✅ Testing de **categorías de productos** (moda, electrónica, hogar)
- ✅ Testing con **diferentes usuarios** (admin, guest, premium)
- ✅ **Validaciones de campos** con múltiples valores

### Cuándo NO usar Scenario Outline

- ❌ Escenarios con **lógica diferente** (aunque datos sean similares)
- ❌ Forzar la unificación cuando **no hay claridad** en los ejemplos
- ❌ Más de 10-15 ejemplos (considera dividir por categorías)

---

## Documentación de Features con Jira

```gherkin
# language: es
# Referencia: KAN-1212
# URL: https://plataformas.atlassian.net/browse/KAN-1212
# Pre-condiciones:
#   - Usuario no autenticado
#   - Base de datos en estado limpio
#   - Productos disponibles en stock

@KAN-1212 @cart @smoke @critical
Característica: Añadir producto desde PLP
  Como usuario del sitio web
  Quiero añadir productos al carrito desde la página de listado
  Para comprar rápidamente sin entrar al detalle

  Antecedentes:
    Dado el usuario está en la página principal de un sitio web
    Y el usuario acepta las cookies

  @plp @happy-path
  Escenario: Añadir primer producto al carrito desde PLP
    # Test Case: KAN-1212 - Paso 1
    Cuando el usuario busca "zapatillas nike"
    # Test Case: KAN-1212 - Paso 2
    Y el usuario espera a que se carguen los resultados
    # Test Case: KAN-1212 - Verificación 1
    Entonces debería haber al menos 1 producto en los resultados
    # Test Case: KAN-1212 - Paso 3
    Cuando el usuario hace clic en "Añadir" del primer producto
    # Test Case: KAN-1212 - Verificación 2
    Entonces el producto debería agregarse al carrito
    Y el contador del carrito debería mostrar 1 producto
```

---

## Idioma y Localización

### Configuración de Idioma

```gherkin
# language: es
Característica: Búsqueda de productos
  # ... escenarios en español
```

### Palabras Clave en Español

- **Característica**: Feature
- **Antecedentes**: Background
- **Escenario**: Scenario
- **Esquema del escenario**: Scenario Outline
- **Ejemplos**: Examples
- **Dado/Dada**: Given
- **Cuando**: When
- **Entonces**: Then
- **Y**: And
- **Pero**: But

---

## Tips de Escritura

### 1. Claridad sobre brevedad

```gherkin
# ⚠️ POCO CLARO
Cuando el usuario añade

# ✅ CLARO
Cuando el usuario hace clic en "Añadir" del primer producto
```

### 2. Usa comillas para datos importantes

```gherkin
Cuando el usuario busca "portátil"
Y el usuario hace clic en "Añadir al carrito"
```

### 3. Evita detalles técnicos

```gherkin
# ❌ INCORRECTO
Cuando envío una petición POST a "/api/cart" con payload {"productId": 123}

# ✅ CORRECTO
Cuando el usuario añade el producto al carrito
```

### 4. Un escenario debe contar una historia

```gherkin
Escenario: Usuario compra producto exitosamente
  Dado el usuario está en la página de productos
  Cuando el usuario busca "portátil"
  Y el usuario añade el primer resultado al carrito
  Y el usuario procede al checkout
  Y el usuario completa el pago
  Entonces debería ver la confirmación de compra
```

---

## Errores Comunes

### ❌ Error 1: Steps muy específicos

```gherkin
# ❌ MALO
Cuando hago clic en el botón "Añadir" con id "btn-add-123" del producto "MacBook Pro"

# ✅ BUENO
Cuando el usuario hace clic en "Añadir" del primer producto
```

### ❌ Error 2: Mezclar Given-When-Then

```gherkin
# ❌ MALO
Dado el usuario busca "portátil"  # ¡Es una acción, no un estado!

# ✅ BUENO
Cuando el usuario busca "portátil"
```

### ❌ Error 3: Escenarios demasiado largos

```gherkin
# ❌ MALO - 20+ pasos
Escenario: Flujo completo de compra
  # ... 25 pasos ...

# ✅ BUENO - Dividir en múltiples escenarios
Escenario: Añadir producto al carrito
Escenario: Proceder al checkout
Escenario: Completar pago
```

---

## Referencias

- **Documentación oficial**: [Cucumber Gherkin](https://cucumber.io/docs/gherkin/)
- **Best Practices**: [Cucumber Best Practices](https://cucumber.io/docs/bdd/better-gherkin/)
- **Ejemplos del proyecto**: Ver `features/`

---

**📌 Recuerda**: Gherkin debe ser **legible por todos** (QA, dev, PO) y **mantenible a largo plazo**.
