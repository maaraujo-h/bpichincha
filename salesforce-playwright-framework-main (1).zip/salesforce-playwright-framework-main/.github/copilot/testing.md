# 🧪 Testing Best Practices

---
applyTo: "features/**/*.feature, src/steps/**/*.ts, cucumber.js, playwright.config.ts"
---

## Tests Independientes

### ✅ Cada test debe ser independiente

```typescript
// ✅ CORRECTO - Test independiente con setup completo
Given('el usuario está en la página principal', async function () {
  await this.page.goto('/');
  
  // Limpiar estado previo
  await this.page.evaluate(() => localStorage.clear());
  await this.page.evaluate(() => sessionStorage.clear());
  
  // Aceptar cookies si aparecen
  const cookieBtn = this.page.locator('[data-testid="accept-cookies"]');
  if (await cookieBtn.isVisible()) {
    await cookieBtn.click();
  }
});

// ❌ INCORRECTO - Depende de estado previo
Then('el carrito debería tener 2 productos', async function () {
  // ¿De dónde vienen los 2 productos? 
  // ¡Depende de tests anteriores!
  const count = await cartPage.getProductCount();
  expect(count).toBe(2);
});
```

### Principios de Independencia

1. **No depender del orden de ejecución**
2. **Limpiar estado antes y después**
3. **Setup explícito en cada test**
4. **No compartir datos entre tests**

---

## Datos de Prueba

### Centralizar Datos de Test

```typescript
// src/utils/test-data.ts
export const TEST_DATA = {
  SEARCH_TERMS: {
    VALID: 'portátil',
    POPULAR: 'televisión',
    NO_RESULTS: 'xyzabc123456789',
    SPECIAL_CHARS: 'café ñoño',
  },
  USERS: {
    VALID: {
      email: 'test@example.com',
      password: 'Test123!',
    },
    ADMIN: {
      email: 'admin@example.com',
      password: 'Admin123!',
    },
  },
  PRODUCTS: {
    AVAILABLE: 'MacBook Pro',
    OUT_OF_STOCK: 'iPhone 16 Pro Max',
  },
} as const;
```

### Uso en Steps

```typescript
When('el usuario busca un producto válido', async function () {
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.search(TEST_DATA.SEARCH_TERMS.VALID);
});

When('el usuario busca un producto sin resultados', async function () {
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.search(TEST_DATA.SEARCH_TERMS.NO_RESULTS);
});
```

### Datos Dinámicos con Faker (opcional)

```typescript
import { faker } from '@faker-js/faker';

// Generar datos únicos por ejecución
const testUser = {
  email: faker.internet.email(),
  password: faker.internet.password({ length: 12 }),
  firstName: faker.person.firstName(),
  lastName: faker.person.lastName(),
};
```

---

## Assertions Claras

### ✅ Assertions con mensajes descriptivos

```typescript
// ✅ CORRECTO - Mensaje claro
Then('el carrito debería estar vacío', async function () {
  const cartPage = PageFactory.getCartPage(this, this.page);
  const itemCount = await cartPage.getItemCount();
  expect(itemCount, 'El carrito debería tener 0 items').toBe(0);
});

// ✅ CORRECTO - Assertion específica
Then('debería ver el mensaje de confirmación', async function () {
  const message = await this.page.locator('[data-testid="confirmation"]').textContent();
  expect(message, 'Mensaje de confirmación incorrecto').toContain('Pedido confirmado');
});

// ❌ INCORRECTO - Assertion vaga
Then('debería funcionar', async function () {
  expect(await this.page.locator('div').count()).toBeGreaterThan(0); 
  // ¿Qué verifica? ¿Qué "debería funcionar"?
});
```

### Tipos de Assertions

```typescript
// Igualdad
expect(actual).toBe(expected);
expect(actual).toEqual(expected); // Deep equality

// Comparaciones numéricas
expect(count).toBeGreaterThan(0);
expect(count).toBeGreaterThanOrEqual(1);
expect(count).toBeLessThan(100);

// Strings
expect(text).toContain('substring');
expect(text).toMatch(/regex/i);

// Booleanos
expect(isVisible).toBeTruthy();
expect(isEmpty).toBeFalsy();

// Arrays
expect(array).toHaveLength(5);
expect(array).toContain('item');

// Objetos
expect(obj).toHaveProperty('name');
expect(obj).toMatchObject({ name: 'test' });

// Playwright-specific
await expect(page.locator('[data-testid="element"]')).toBeVisible();
await expect(page.locator('[data-testid="element"]')).toHaveText('text');
await expect(page).toHaveURL(/search/);
await expect(page).toHaveTitle(/Products/);
```

---

## Cross-Browser Testing

### Configuración Multi-Browser

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    // Mobile
    {
      name: 'mobile-chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'mobile-safari',
      use: { ...devices['iPhone 13'] },
    },
  ],
});
```

### Ejecutar en Browser Específico

```bash
# Chromium
npm test -- --project=chromium

# Firefox
npm test -- --project=firefox

# WebKit
npm test -- --project=webkit

# Todos
npm test
```

---

## Parallel Execution

### Configuración de Paralelización

```javascript
// cucumber.js
module.exports = {
  default: {
    parallel: 3,      // Ejecuta 3 workers en paralelo
    retry: 2,         // Reintenta tests fallidos 2 veces
    retryTagFilter: '@flaky', // Solo reintentar tests con @flaky
  },
};
```

### Consideraciones de Paralelización

**✅ Tests aptos para paralelización**:
- Tests sin dependencias entre sí
- Tests con datos únicos (no compartidos)
- Tests que limpian su propio estado

**❌ Tests NO aptos para paralelización**:
- Tests que modifican base de datos compartida
- Tests que dependen de estado global
- Tests con dependencias de orden

---

## Test Categorization con Tags

### Estrategia de Tags

```gherkin
# Criticidad
@critical       # Tests críticos del sistema
@smoke          # Suite de smoke tests
@regression     # Suite completa de regresión

# Funcionalidad
@cart           # Tests de carrito
@search         # Tests de búsqueda
@authentication # Tests de login/registro

# Estado
@wip            # Work in progress
@skip           # Temporalmente deshabilitado
@flaky          # Test inestable (necesita revisión)

# Performance
@slow           # Tests lentos (>30s)

# Entorno
@staging-only   # Solo ejecutar en staging
@prod-safe      # Seguro para ejecutar en producción
```

### Ejecutar por Tags

```bash
# Solo tests críticos
npm test -- --tags "@critical"

# Tests de carrito y búsqueda
npm test -- --tags "@cart or @search"

# Smoke tests excluyendo WIP
npm test -- --tags "@smoke and not @wip"

# Solo un ticket específico
npm test -- --tags "@KAN-1212"
```

---

## Manejo de Tests Flaky

### Identificar y Documentar

```gherkin
@flaky @KAN-1212
Escenario: Test ocasionalmente falla
  # TODO: Investigar por qué falla intermitentemente
  # Posible causa: Race condition en carga de productos
  Cuando el usuario busca "portátil"
  # ...
```

### Estrategias Anti-Flaky

```typescript
// ✅ Esperas explícitas en lugar de timeouts fijos
await page.waitForSelector('[data-testid="product"]', { state: 'visible' });

// ✅ Retry automático para operaciones flaky
await retryOperation(async () => {
  await page.click('[data-testid="btn"]');
}, 3);

// ✅ Verificar estado antes de actuar
const isVisible = await element.isVisible();
if (isVisible) {
  await element.click();
}

// ❌ EVITAR - Timeouts fijos
await page.waitForTimeout(3000); // Causa flakiness
```

---

## Test Organization

### Estructura de Suite

```
features/
├── smoke/              # Tests de smoke críticos (5-10 min)
│   ├── critical-paths.feature
│   └── homepage.feature
├── regression/         # Suite completa de regresión (30+ min)
│   ├── cart/
│   ├── search/
│   └── checkout/
└── integration/        # Tests de integración con APIs
    └── api-integration.feature
```

### Ejecución por Suite

```bash
# Smoke tests
npm test -- features/smoke/**/*.feature

# Regression completa
npm test -- features/regression/**/*.feature

# Tests específicos de cart
npm test -- features/regression/cart/**/*.feature
```

---

## Reporting

### Configuración de Reportes

```javascript
// cucumber.js
module.exports = {
  default: {
    format: [
      'progress-bar',                          // Progress en terminal
      'html:cucumber-report/cucumber-report.html', // HTML report
      'json:cucumber-report/cucumber-report.json', // JSON para análisis
      'junit:cucumber-report/cucumber-report.xml', // JUnit para CI/CD
    ],
  },
};
```

### Generar Reportes

```bash
# Ejecutar tests y generar reportes
npm test

# Ver reporte HTML
# Abre: cucumber-report/cucumber-report.html
```

---

## CI/CD Integration

### GitHub Actions Ejemplo

```yaml
name: E2E Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Install Playwright
        run: npx playwright install --with-deps
      
      - name: Run smoke tests
        run: npm test -- --tags "@smoke"
      
      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: test-results
          path: cucumber-report/
```

---

## Maintenance Best Practices

### 1. Limpieza Regular

```bash
# Limpiar reportes antiguos
npm run clean

# Limpiar node_modules y reinstalar
rm -rf node_modules package-lock.json
npm install
```

### 2. Actualización de Dependencias

```bash
# Ver dependencias desactualizadas
npm outdated

# Actualizar Playwright
npm install @playwright/test@latest

# Actualizar todas las dependencias (con precaución)
npm update
```

### 3. Revisión de Tests Obsoletos

```bash
# Buscar tests con @skip
grep -r "@skip" features/

# Buscar tests con @wip
grep -r "@wip" features/

# Revisar y decidir: ¿eliminar o arreglar?
```

---

## Quality Metrics

### Métricas a Seguir

1. **Test Coverage**: % de funcionalidades cubiertas
2. **Pass Rate**: % de tests que pasan
3. **Flaky Rate**: % de tests inestables
4. **Execution Time**: Tiempo promedio de suite
5. **Mean Time to Detection (MTTD)**: Tiempo hasta detectar bugs
6. **Mean Time to Resolution (MTTR)**: Tiempo hasta arreglar tests

### Dashboard de Métricas (ejemplo)

```typescript
// Generar métricas simples
const metrics = {
  totalTests: 150,
  passed: 145,
  failed: 3,
  skipped: 2,
  flaky: 5,
  avgDuration: '25 min',
  passRate: '96.67%',
};

logger.info('Test Metrics:', metrics);
```

---

## Reutilización de Steps y Código Genérico

**⚠️ CRÍTICO**: Los steps definitions son **código compartido**.

### Reglas de Oro

1. **NUNCA incluyas IDs de tickets en logs o mensajes**:
   ```typescript
   // ❌ INCORRECTO
   logger.info('KAN-1212: Añadiendo producto');
   
   // ✅ CORRECTO
   logger.info('Añadiendo producto al carrito');
   ```

2. **Documenta tickets en comentarios**:
   ```typescript
   /**
    * Step Definitions para Carrito
    * Tickets relacionados: KAN-1212, KAN-1213
    */
   ```

3. **Piensa en reutilización**:
   ```typescript
   // ✅ CORRECTO - Genérico
   When('el usuario añade el primer producto al carrito', async function () {
     // Reutilizable en múltiples tickets
   });
   ```

---

## Referencias

- **Testing Best Practices**: [Playwright Best Practices](https://playwright.dev/docs/best-practices)
- **Cucumber Best Practices**: [Cucumber Docs](https://cucumber.io/docs/bdd/better-gherkin/)
- **Testing Pyramid**: [Martin Fowler - Test Pyramid](https://martinfowler.com/articles/practical-test-pyramid.html)

---

**📌 Recuerda**: Tests de calidad = software de calidad. Invierte en tests mantenibles, rápidos y confiables.
