# 🔄 Step Definitions

---

applyTo: "src/steps/**/*.ts, src/support/hooks.ts"

---

## Organización de Steps

### ❌ INCORRECTO - Steps nombrados por ticket o test específico

```Text
src/steps/
├── KAN-1212.steps.ts      # ❌ No usar ID de ticket
├── kan-1212.steps.ts      # ❌ No usar ID de ticket
└── test-login-1.steps.ts  # ❌ No usar nombre de test específico
```

### ✅ CORRECTO - Steps nombrados según Page Object o funcionalidad

```Text
src/steps/
├── common.steps.ts           # Steps comunes (navegación, cookies, etc.)
├── homepage.steps.ts         # Steps específicos de HomePage
├── search.steps.ts           # Steps de búsqueda (SearchResultsPage)
├── cart.steps.ts             # Steps de carrito (CartPage, SearchResultsPage)
├── product-detail.steps.ts   # Steps de detalle de producto (ProductDetailPage)
└── authentication.steps.ts   # Steps de login/registro (LoginPage)
```

---

## 🎯 Reglas de Naming de Steps

1. **Nombra según Page Object relacionado**: `cart.steps.ts` para `CartPage`, `SearchResultsPage`
2. **Agrupa steps por funcionalidad**: Un archivo puede contener steps de múltiples Page Objects si están relacionados funcionalmente
3. **Documenta tickets relacionados**: En JSDoc dentro del archivo: `@see KAN-1212, KAN-1213`
4. **No uses IDs de tickets en nombres**: Los tickets cambian, las funcionalidades permanecen

---

## Estructura de Steps

```typescript
/**
 * Step Definitions para búsqueda de productos
 * Referencia: KAN-1212
 */
import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PageFactory } from '../utils/page-factory';
import { logger } from '../utils/logger';

/**
 * GIVEN - Precondiciones
 */
Given('el usuario está en la página de búsqueda de {string}', async function (categoria: string) {
  const searchPage = PageFactory.getSearchResultsPage(this, this.page);
  await searchPage.navigateToCategory(categoria);
});

/**
 * WHEN - Acciones
 */
When('el usuario busca {string}', async function (searchTerm: string) {
  logger.info(`Buscando: ${searchTerm}`);
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.search(searchTerm);
});

When('el usuario filtra por precio entre {int} y {int} euros', async function (min: number, max: number) {
  const searchPage = PageFactory.getSearchResultsPage(this, this.page);
  await searchPage.filterByPrice(min, max);
});

/**
 * THEN - Verificaciones
 */
Then('debería ver resultados de búsqueda para {string}', async function (searchTerm: string) {
  const searchPage = PageFactory.getSearchResultsPage(this, this.page);
  const hasResults = await searchPage.hasResults();
  expect(hasResults).toBeTruthy();
  
  const currentUrl = this.page.url();
  expect(currentUrl).toContain(searchTerm.toLowerCase());
});

Then('debería haber al menos {int} producto(s) en los resultados', async function (minProducts: number) {
  const searchPage = PageFactory.getSearchResultsPage(this, this.page);
  const productCount = await searchPage.getProductCount();
  expect(productCount).toBeGreaterThanOrEqual(minProducts);
});

Then('todos los productos deberían contener {string} en su título', async function (keyword: string) {
  const searchPage = PageFactory.getSearchResultsPage(this, this.page);
  const titles = await searchPage.getAllProductTitles();
  
  titles.forEach(title => {
    expect(title.toLowerCase()).toContain(keyword.toLowerCase());
  });
});
```

---

## Mejores Prácticas de Steps

### 1. NUNCA dupliques steps - Revisa siempre antes de crear

```typescript
// ❌ INCORRECTO - Duplicación
// En search.steps.ts
When('el usuario busca {string}', async function (term: string) { ... });

// En cart.steps.ts
When('el usuario busca {string}', async function (term: string) { ... }); // ¡DUPLICADO!

// ✅ CORRECTO - Step único en common.steps.ts o search.steps.ts
When('el usuario busca {string}', async function (term: string) { ... });
```

**Cómo evitar duplicación**:

1. Busca en todos los archivos `.steps.ts` antes de crear un nuevo step
2. Usa `grep_search` o búsqueda en VS Code
3. Reutiliza steps existentes

### 2. Usa expresiones regulares para flexibilidad

```typescript
// Acepta "producto" o "productos"
Then('debería haber al menos {int} producto(s)', async function (count: number) { 
  // Implementación
});

// Acepta múltiples variaciones
When('el usuario hace clic en el botón {string}', async function (button: string) {
  // Implementación
});

// Regex para opcionalidad
Given(/^el usuario (está|esta) en la página principal$/, async function () {
  // Acepta "está" y "esta"
});
```

### 3. Parámetros tipados

```typescript
// ✅ CORRECTO - Tipos explícitos
When('el usuario filtra por precio {int}', async function (price: number) {
  // price es number, no string
  logger.info(`Filtrando por precio: ${price}`);
});

Then('debería ver {int} resultados', async function (count: number) {
  const actualCount = await searchPage.getProductCount();
  expect(actualCount).toBe(count);
});

// Tipos disponibles en Cucumber:
// {int}    - números enteros
// {float}  - números decimales
// {string} - texto entre comillas
// {word}   - palabra sin espacios
```

### 4. Usa PageFactory para obtener instancias

```typescript
// ✅ CORRECTO - Factory Pattern
When('el usuario busca {string}', async function (term: string) {
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.search(term);
});

// ❌ INCORRECTO - Crear instancia directamente
When('el usuario busca {string}', async function (term: string) {
  const homePage = new HomePage(this.page); // ¡No!
  await homePage.search(term);
});
```

### 5. Logging para debugging - SIN referencias a tickets

```typescript
// ❌ INCORRECTO - Logging con ID de ticket
When('el usuario busca {string}', async function (term: string) {
  logger.info(`KAN-1212: Ejecutando búsqueda: ${term}`); // ¡NO!
});

// ✅ CORRECTO - Logging genérico y reutilizable
When('el usuario busca {string}', async function (term: string) {
  logger.info(`Ejecutando búsqueda: ${term}`);
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.search(term);
});

// ❌ INCORRECTO - Error con ID de ticket
if (!hasProducts) {
  throw new Error('KAN-1212: No hay productos'); // ¡NO!
}

// ✅ CORRECTO - Error genérico
if (!hasProducts) {
  throw new Error('No hay productos disponibles para añadir al carrito');
}
```

**Razón**: Los steps son **código compartido** entre múltiples tickets. Nunca incluyas IDs de tickets en logs o errores.

### 6. Manejo de errores

```typescript
Then('el producto debería estar en el carrito', async function () {
  try {
    const cartPage = PageFactory.getCartPage(this, this.page);
    const inCart = await cartPage.hasProducts();
    expect(inCart, 'El producto no está en el carrito').toBeTruthy();
  } catch (error) {
    logger.error('Error verificando carrito', error);
    throw error;
  }
});
```

### 7. Reutiliza steps compuestos

```typescript
// Step reutilizable que llama a otros steps
Given('el usuario ha iniciado sesión como {string}', async function (userType: string) {
  await this.step('el usuario está en la página de login');
  await this.step(`el usuario introduce credenciales de ${userType}`);
  await this.step('el usuario hace clic en "Iniciar sesión"');
});

// Uso en feature:
// Dado el usuario ha iniciado sesión como "admin"
```

---

## Organización por Tipo de Step

### Given Steps (Precondiciones)

```typescript
/**
 * GIVEN - Establecen el estado inicial
 */
Given('el usuario está en la página principal', async function () {
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.navigate('/');
});

Given('el usuario está autenticado como {string}', async function (userType: string) {
  // Setup de autenticación
});

Given('el carrito está vacío', async function () {
  // Limpiar carrito
});
```

### When Steps (Acciones)

```typescript
/**
 * WHEN - Ejecutan acciones del usuario
 */
When('el usuario busca {string}', async function (term: string) {
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.search(term);
});

When('el usuario hace clic en {string}', async function (buttonText: string) {
  await this.page.click(`text="${buttonText}"`);
});

When('el usuario espera {int} segundos', async function (seconds: number) {
  await this.page.waitForTimeout(seconds * 1000);
});
```

### Then Steps (Verificaciones)

```typescript
/**
 * THEN - Verifican resultados esperados
 */
Then('debería ver el mensaje {string}', async function (message: string) {
  const isVisible = await this.page.isVisible(`text="${message}"`);
  expect(isVisible, `Mensaje "${message}" no visible`).toBeTruthy();
});

Then('la URL debería contener {string}', async function (urlPart: string) {
  const currentUrl = this.page.url();
  expect(currentUrl).toContain(urlPart);
});

Then('el elemento {string} debería estar visible', async function (selector: string) {
  await expect(this.page.locator(selector)).toBeVisible();
});
```

---

## Patrones Avanzados

### 1. Steps con Tablas de Datos

```gherkin
# En feature
Cuando el usuario rellena el formulario con:
  | campo    | valor              |
  | nombre   | Juan Pérez         |
  | email    | juan@example.com   |
  | teléfono | 123456789          |
```

```typescript
// En steps
When('el usuario rellena el formulario con:', async function (dataTable) {
  const data = dataTable.rowsHash(); // Convierte tabla a objeto
  const formPage = PageFactory.getFormPage(this, this.page);
  
  for (const [field, value] of Object.entries(data)) {
    await formPage.fillField(field, value as string);
  }
});
```

### 2. Steps con Doc Strings

```gherkin
# En feature
Cuando el usuario introduce el siguiente JSON:
  """
  {
    "name": "Test Product",
    "price": 99.99
  }
  """
```

```typescript
// En steps
When('el usuario introduce el siguiente JSON:', async function (docString: string) {
  const data = JSON.parse(docString);
  // Usar data
});
```

### 3. Steps Parametrizados Complejos

```typescript
// Acepta múltiples formatos
When(/^el usuario (hace clic|clickea|selecciona) en "(.*)"$/, 
  async function (action: string, elementText: string) {
  logger.info(`${action} en: ${elementText}`);
  await this.page.click(`text="${elementText}"`);
});
```

---

## Reutilización de Steps y Código Genérico

**⚠️ CRÍTICO**: Los steps definitions son **código compartido** que se reutiliza en múltiples features y tickets de Jira.

### Reglas de Oro

1. **NUNCA incluyas IDs de tickets en logs o mensajes de error**:

   ```typescript
   // ❌ INCORRECTO
   logger.info('KAN-1212: Añadiendo producto al carrito');
   throw new Error('KAN-1212: No hay productos disponibles');
   
   // ✅ CORRECTO
   logger.info('Añadiendo producto al carrito');
   throw new Error('No hay productos disponibles para añadir al carrito');
   ```

2. **Documenta tickets en comentarios, NO en código ejecutable**:

   ```typescript
   /**
    * Step Definitions para operaciones de Carrito
    * 
    * Tickets relacionados:
    * - KAN-1212: Añadir producto desde PLP
    * - KAN-1213: Eliminar producto del carrito
    * 
    * @see SearchResultsPage
    * @see CartPage
    */
   
   // ✅ Código sin referencias a tickets
   When('el usuario hace clic en {string} del primer producto', 
     async function (actionText: string) {
     logger.info(`Haciendo clic en "${actionText}" del primer producto`);
     // ... implementación genérica
   });
   ```

3. **Piensa en reutilización al escribir steps**:

   ```typescript
   // ❌ INCORRECTO - Demasiado específico
   When('el usuario completa el flujo de KAN-1212', async function () {
     // ...
   });
   
   // ✅ CORRECTO - Genérico y reutilizable
   When('el usuario añade el primer producto al carrito desde PLP', async function () {
     // Este step puede usarse en KAN-1212, KAN-1213, KAN-1214, etc.
   });
   ```

4. **Assertions con mensajes claros pero genéricos**:

   ```typescript
   // ❌ INCORRECTO
   expect(productCount, 'KAN-1212: Falló la verificación').toBeGreaterThan(0);
   
   // ✅ CORRECTO
   expect(productCount, 'Debería haber al menos 1 producto en los resultados').toBeGreaterThan(0);
   ```

---

## Anti-Patrones a Evitar

### ❌ 1. Lógica de negocio en Steps

```typescript
// ❌ INCORRECTO - Lógica compleja en step
When('el usuario procesa el pedido', async function () {
  const products = await getProducts();
  const total = products.reduce((sum, p) => sum + p.price, 0);
  const tax = total * 0.21;
  const finalTotal = total + tax;
  // ... más lógica ...
});

// ✅ CORRECTO - Delegar a Page Object o Utils
When('el usuario procesa el pedido', async function () {
  const checkoutPage = PageFactory.getCheckoutPage(this, this.page);
  await checkoutPage.processOrder();
});
```

### ❌ 2. Acceso directo al DOM

```typescript
// ❌ INCORRECTO - Manipular DOM directamente
When('el usuario hace clic en añadir', async function () {
  await this.page.click('#add-to-cart-btn-123'); // ¡No!
});

// ✅ CORRECTO - A través de Page Object
When('el usuario hace clic en añadir', async function () {
  const plp = PageFactory.getProductListPage(this, this.page);
  await plp.addToCart();
});
```

### ❌ 3. Steps demasiado específicos

```typescript
// ❌ INCORRECTO
When('el usuario hace clic en el botón azul de añadir al carrito del producto MacBook Pro', 
  async function () {
  // Demasiado específico
});

// ✅ CORRECTO
When('el usuario hace clic en {string} del primer producto', 
  async function (action: string) {
  // Genérico y reutilizable
});
```

### ❌ 4. Dependencias entre steps

```typescript
// ❌ INCORRECTO - Step depende de estado previo
Then('el carrito debería tener 2 productos', async function () {
  // ¿De dónde vienen los 2 productos?
});

// ✅ CORRECTO - Step independiente con setup
Given('el carrito tiene 2 productos', async function () {
  // Setup explícito
});

Then('el carrito debería tener {int} producto(s)', async function (count: number) {
  const cartPage = PageFactory.getCartPage(this, this.page);
  const actualCount = await cartPage.getProductCount();
  expect(actualCount).toBe(count);
});
```

---

## Testing y Debugging de Steps

### Logging de Steps

```typescript
When('el usuario busca {string}', async function (term: string) {
  logger.info(`[STEP] Búsqueda iniciada con término: "${term}"`);
  
  try {
    const homePage = PageFactory.getHomePage(this, this.page);
    await homePage.search(term);
    logger.info(`[STEP] Búsqueda completada`);
  } catch (error) {
    logger.error(`[STEP] Error en búsqueda`, error);
    throw error;
  }
});
```

### Screenshots en Steps Críticos

```typescript
Then('debería ver la confirmación de compra', async function () {
  try {
    const confirmationVisible = await this.page.isVisible('[data-testid="order-confirmation"]');
    expect(confirmationVisible).toBeTruthy();
  } catch (error) {
    // Capturar screenshot del fallo
    const screenshot = await this.page.screenshot();
    this.attach(screenshot, 'image/png');
    throw error;
  }
});
```

---

## Convenciones de Código

### Formato de Steps

```typescript
// ✅ CORRECTO - Formato consistente
Given('...', async function () { });
When('...', async function () { });
Then('...', async function () { });

// Usa 'async function' no arrow functions (para acceso a 'this')
```

### Imports Organizados

```typescript
// 1. Cucumber
import { Given, When, Then } from '@cucumber/cucumber';

// 2. Testing libraries
import { expect } from '@playwright/test';

// 3. Utils del proyecto
import { PageFactory } from '../utils/page-factory';
import { logger } from '../utils/logger';
import { TEST_DATA } from '../utils/test-data';
```

---

## Referencias

- **Cucumber Step Definitions**: [Cucumber Docs](https://cucumber.io/docs/cucumber/step-definitions/)
- **Cucumber Expressions**: [Cucumber Expressions](https://github.com/cucumber/cucumber-expressions)
- **Ejemplos del proyecto**: Ver `src/steps/`

---

**📌 Recuerda**: Steps deben ser **simples**, **reutilizables** y **sin lógica de negocio**. Son el puente entre Gherkin y Page Objects.
