# 💻 TypeScript Best Practices

---
applyTo: "src/**/*.ts, *.ts"
---

## Configuración de TypeScript

### tsconfig.json - Modo Estricto

```json
{
  "compilerOptions": {
    "strict": true,                  // Habilita todas las verificaciones estrictas
    "noImplicitAny": true,           // Error en tipos 'any' implícitos
    "strictNullChecks": true,        // Verificación estricta de null/undefined
    "noUnusedLocals": true,          // Error en variables locales no usadas
    "noUnusedParameters": true,      // Error en parámetros no usados
    "noImplicitReturns": true,       // Error si falta return en todas las rutas
    "noFallthroughCasesInSwitch": true
  }
}
```

---

## Tipado Estricto

### Interfaces

```typescript
/**
 * Interfaz para configuración de producto
 */
interface ProductConfig {
  id: string;
  name: string;
  price: number;
  inStock: boolean;
  category?: string; // Opcional
}

/**
 * Uso en métodos
 */
async filterProducts(config: ProductConfig): Promise<void> {
  logger.info(`Filtrando productos: ${config.name}`);
  // Implementación
}
```

### Types

```typescript
/**
 * Type para estados de orden
 */
type OrderStatus = 'pending' | 'processing' | 'completed' | 'cancelled';

/**
 * Type para roles de usuario
 */
type UserRole = 'admin' | 'user' | 'guest';

/**
 * Uso en métodos
 */
async getOrderStatus(orderId: string): Promise<OrderStatus> {
  // Implementación
  return 'completed';
}

async loginAs(role: UserRole): Promise<void> {
  // Solo acepta valores específicos
}
```

### Type Guards

```typescript
function isProductConfig(obj: any): obj is ProductConfig {
  return (
    typeof obj === 'object' &&
    typeof obj.id === 'string' &&
    typeof obj.name === 'string' &&
    typeof obj.price === 'number'
  );
}

// Uso
if (isProductConfig(data)) {
  await filterProducts(data); // TypeScript sabe que es ProductConfig
}
```

---

## Enums vs Const Objects

### ✅ Const Objects (PREFERIDO para constantes)

```typescript
// ✅ CORRECTO - Para constantes relacionadas
export const TIMEOUTS = {
  SHORT: 3000,
  MEDIUM: 10000,
  LONG: 25000,
  NAVIGATION: 30000,
} as const;

// Uso
await page.waitForSelector(selector, { timeout: TIMEOUTS.LONG });
```

**Ventajas**:
- Más simple
- Mejor para constantes numéricas
- Fácil de extender

### ✅ Enums (Para tipos enumerados)

```typescript
// ✅ CORRECTO - Para tipos enumerados
export enum UserRole {
  ADMIN = 'admin',
  USER = 'user',
  GUEST = 'guest',
}

// Uso
async loginAs(role: UserRole): Promise<void> {
  logger.info(`Login como: ${role}`);
}

// Llamada
await loginAs(UserRole.ADMIN);
```

**Ventajas**:
- Mejor para tipos/categorías
- Autocompletado en IDE
- Verificación de tipos en tiempo de compilación

---

## Async/Await

### ✅ Siempre usa async/await

```typescript
// ✅ CORRECTO - async/await limpio
async addProductToCart(productId: string): Promise<void> {
  await this.searchProduct(productId);
  await this.clickAddToCart();
  await this.verifyCartUpdate();
}

// ❌ INCORRECTO - No mezcles promises y async/await
async badExample(): Promise<void> {
  this.page.click('#btn').then(() => { // ¡No!
    return this.page.waitForSelector('#result');
  });
}
```

### Parallel Execution con Promise.all

```typescript
// ✅ CORRECTO - Ejecutar en paralelo cuando sea seguro
async loadPageData(): Promise<void> {
  const [products, categories, user] = await Promise.all([
    this.getProducts(),
    this.getCategories(),
    this.getUserData(),
  ]);
  
  logger.info(`Cargados: ${products.length} productos, ${categories.length} categorías`);
}
```

---

## Error Handling

### Try-Catch Específico

```typescript
// ✅ CORRECTO - Try-catch específico
async addToCart(): Promise<void> {
  try {
    await this.clickAddButton();
    await this.waitForConfirmation();
    logger.info('Producto añadido al carrito exitosamente');
  } catch (error) {
    logger.error('Error añadiendo al carrito', error);
    throw new Error(`No se pudo añadir al carrito: ${error}`);
  }
}
```

### Métodos con Fallback

```typescript
// ✅ CORRECTO - Fallback para selectores
async clickWithFallback(primarySelector: string, fallbackSelector: string): Promise<void> {
  try {
    await this.page.locator(primarySelector).click({ timeout: TIMEOUTS.SHORT });
    logger.debug(`Click exitoso con selector primario: ${primarySelector}`);
  } catch {
    logger.warn(`Selector primario falló, usando fallback: ${fallbackSelector}`);
    await this.page.locator(fallbackSelector).click();
  }
}
```

### Manejo de Errores con Tipos

```typescript
// ✅ CORRECTO - Error handling tipado
async safeExecute<T>(fn: () => Promise<T>, defaultValue: T): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    if (error instanceof Error) {
      logger.error(`Error ejecutando función: ${error.message}`);
    }
    return defaultValue;
  }
}

// Uso
const productCount = await this.safeExecute(
  () => page.locator('[data-testid="product"]').count(),
  0
);
```

---

## Comentarios y Documentación

### JSDoc Completo

```typescript
/**
 * Page Object para la página de resultados de búsqueda
 * 
 * @remarks
 * Esta clase maneja todas las interacciones con la página de resultados,
 * incluyendo filtrado, ordenamiento y navegación a productos.
 * 
 * @example
 * ```typescript
 * const searchPage = PageFactory.getSearchResultsPage(context, page);
 * await searchPage.filterByPrice(100, 500);
 * await searchPage.sortBy('price-asc');
 * ```
 */
export class SearchResultsPage extends BasePage {
  /**
   * Filtra productos por rango de precio
   * 
   * @param minPrice - Precio mínimo en euros
   * @param maxPrice - Precio máximo en euros
   * @throws {Error} Si los precios son inválidos
   * @returns {Promise<void>}
   * 
   * @example
   * ```typescript
   * await searchPage.filterByPrice(50, 200);
   * ```
   */
  async filterByPrice(minPrice: number, maxPrice: number): Promise<void> {
    if (minPrice > maxPrice) {
      throw new Error('El precio mínimo no puede ser mayor que el máximo');
    }
    // Implementación
  }
}
```

### Comentarios Inline

```typescript
// ✅ CORRECTO - Comentarios útiles
async addFirstProductToCart(): Promise<void> {
  // Esperar que la lista de productos se cargue completamente
  await this.waitForResults();
  
  // Hover para mostrar botón (solo visible en hover)
  const firstProduct = this.page.locator(this.selectors.productCard).first();
  await firstProduct.hover();
  
  // Click y verificar confirmación
  await firstProduct.locator(this.selectors.addToCartBtn).click();
  await this.waitForElement(this.selectors.cartConfirmation);
}
```

---

## Funciones Genéricas

### Reutilización con Genéricos

```typescript
// ✅ CORRECTO - Función genérica reutilizable
async getElementAttribute<T extends string>(
  selector: string, 
  attribute: string
): Promise<T | null> {
  return await this.page.locator(selector).getAttribute(attribute) as T | null;
}

// Uso
const href = await this.getElementAttribute<string>('a', 'href');
const ariaLabel = await this.getElementAttribute<string>('button', 'aria-label');
```

### Arrays Tipados

```typescript
// ✅ CORRECTO - Arrays con tipos explícitos
async getAllProductTitles(): Promise<string[]> {
  return await this.page.locator('[data-testid="product-title"]').allTextContents();
}

async getAllProducts(): Promise<ProductConfig[]> {
  const products: ProductConfig[] = [];
  // Lógica para obtener productos
  return products;
}
```

---

## Imports y Exports

### Organización de Imports

```typescript
// 1. Librerías externas (node_modules)
import { Page, Locator } from '@playwright/test';
import { expect } from '@playwright/test';

// 2. Imports internos (utils, pages)
import { BasePage } from './BasePage';
import { logger } from '../utils/logger';
import { TIMEOUTS } from '../utils/constants';

// 3. Types e interfaces
import type { ICustomWorld } from '../types/cucumber';
```

### Named Exports (PREFERIDO)

```typescript
// ✅ CORRECTO - Named exports
export class HomePage extends BasePage { }
export const TIMEOUTS = { /* ... */ };
export function formatPrice(price: number): string { }

// Uso
import { HomePage, TIMEOUTS, formatPrice } from './module';
```

### Default Exports (evitar en este proyecto)

```typescript
// ⚠️ EVITAR - Default exports dificultan refactoring
export default class HomePage extends BasePage { }

// Uso (nombre puede variar)
import HomePage from './HomePage'; // o
import Home from './HomePage';     // Inconsistente
```

---

## Null Safety

### Operadores de Null Safety

```typescript
// ✅ CORRECTO - Optional chaining
const title = product?.title?.toLowerCase();

// ✅ CORRECTO - Nullish coalescing
const productName = product.name ?? 'Producto sin nombre';

// ✅ CORRECTO - Non-null assertion (cuando estás seguro)
const title = await this.page.locator('h1').textContent()!;
```

### Validación de Null

```typescript
async getProductTitle(): Promise<string> {
  const title = await this.page.locator('[data-testid="title"]').textContent();
  
  if (title === null) {
    throw new Error('Título del producto no encontrado');
  }
  
  return title;
}

// O con default value
async getProductTitle(): Promise<string> {
  return await this.page.locator('[data-testid="title"]').textContent() || 'Sin título';
}
```

---

## Evitar 'any'

```typescript
// ❌ INCORRECTO - Uso de 'any'
async processData(data: any): Promise<void> {
  // Sin verificación de tipos
}

// ✅ CORRECTO - Tipo específico
async processData(data: ProductConfig): Promise<void> {
  logger.info(`Procesando: ${data.name}`);
}

// ✅ CORRECTO - Union types si puede ser varios tipos
async processData(data: ProductConfig | UserConfig): Promise<void> {
  if ('price' in data) {
    // Es ProductConfig
  } else {
    // Es UserConfig
  }
}
```

---

## Readonly Properties

```typescript
// ✅ CORRECTO - Propiedades inmutables
export class ProductListPage extends BasePage {
  private readonly selectors = {
    productCard: '[data-testid="product-card"]',
    addToCartBtn: '[data-testid="add-to-cart-btn"]',
  };
  
  // No se pueden modificar después de la asignación
}
```

---

## Convenciones de Naming

### Variables y Funciones

```typescript
// camelCase
const productCount = 10;
const userName = 'test';
async function getProductList(): Promise<void> { }
```

### Clases e Interfaces

```typescript
// PascalCase
class HomePage extends BasePage { }
interface ProductConfig { }
type OrderStatus = 'pending' | 'processing';
```

### Constantes

```typescript
// UPPER_SNAKE_CASE o camelCase (según contexto)
const MAX_RETRIES = 3;
const DEFAULT_TIMEOUT = 5000;

// O en objetos con 'as const'
export const TIMEOUTS = {
  SHORT: 3000,
  MEDIUM: 10000,
} as const;
```

### Private Members

```typescript
// Prefijo con '_' (opcional pero útil)
class ProductPage extends BasePage {
  private readonly _cache: Map<string, any> = new Map();
  
  private _initialized = false;
}
```

---

## Utility Types

```typescript
// Partial - Hace todas las propiedades opcionales
type PartialProduct = Partial<ProductConfig>;

// Pick - Selecciona propiedades específicas
type ProductSummary = Pick<ProductConfig, 'name' | 'price'>;

// Omit - Excluye propiedades específicas
type ProductWithoutId = Omit<ProductConfig, 'id'>;

// Record - Crea objeto con claves tipadas
type ProductMap = Record<string, ProductConfig>;
```

---

## Referencias

- **TypeScript Handbook**: [TypeScript Docs](https://www.typescriptlang.org/docs/handbook/intro.html)
- **TypeScript Best Practices**: [Microsoft TypeScript Guidelines](https://github.com/microsoft/TypeScript/wiki/Coding-guidelines)
- **Do's and Don'ts**: [TypeScript Do's and Don'ts](https://www.typescriptlang.org/docs/handbook/declaration-files/do-s-and-don-ts.html)

---

**📌 Recuerda**: TypeScript fuerte reduce bugs y mejora la mantenibilidad. Invierte en tipos correctos desde el inicio.
