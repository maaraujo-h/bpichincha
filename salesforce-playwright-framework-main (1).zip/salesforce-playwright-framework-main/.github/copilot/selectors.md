# 🎯 Selectores Robustos

---
applyTo: "src/pages/**/*.ts, src/steps/**/*.ts"
---

## Jerarquía de Preferencia de Selectores

1. **`data-testid`** - Más robusto y mantenible ⭐
2. **`getByRole`** - Accesibilidad nativa
3. **`getByText`** - Para contenido estático
4. **`getByLabel`** - Para formularios
5. **CSS Selector específico** - Con clases estables
6. **XPath** - Último recurso (evitar si es posible)

---

## Ejemplos de Selectores

### ✅ Nivel 1: data-testid (PREFERIDO)

```typescript
// ⭐ EXCELENTE - Selector específico para testing
await page.locator('[data-testid="add-to-cart-btn"]').click();
await page.locator('[data-testid="product-card"]').first();
await page.locator('[data-testid="search-input"]').fill('portátil');
```

**Ventajas**:
- Inmune a cambios de diseño/CSS
- Específico para testing
- Fácil de mantener
- Comunicación clara con desarrollo

### ✅ Nivel 2: getByRole (ACCESIBILIDAD)

```typescript
// ⭐ MUY BUENO - Usa roles ARIA nativos
await page.getByRole('button', { name: 'Añadir al carrito' }).click();
await page.getByRole('textbox', { name: 'Email' }).fill('user@example.com');
await page.getByRole('link', { name: 'Inicio' }).click();
await page.getByRole('heading', { name: 'Productos' }).isVisible();
```

**Ventajas**:
- Promueve accesibilidad
- Selector semántico
- Independiente de implementación

### ✅ Nivel 3: getByText (CONTENIDO ESTÁTICO)

```typescript
// ⭐ BUENO - Para texto que no cambia
await page.getByText('Iniciar sesión').click();
await page.getByText(/total:.*€/i).isVisible();
await page.getByText('Añadir al carrito', { exact: true }).click();
```

**Ventajas**:
- Intuitivo y legible
- Útil para links y botones con texto fijo

### ✅ Nivel 4: getByLabel (FORMULARIOS)

```typescript
// ⭐ BUENO - Para inputs con labels
await page.getByLabel('Correo electrónico').fill('user@example.com');
await page.getByLabel('Contraseña').fill('password123');
await page.getByLabel('Acepto términos y condiciones').check();
```

### ⚠️ Nivel 5: CSS Selector (CON PRECAUCIÓN)

```typescript
// ⚠️ ACEPTABLE - Solo con clases estables
await page.locator('.product-card__add-button').click();
await page.locator('button.btn-primary[type="submit"]').click();

// ✅ MEJOR - Combinar con data attributes
await page.locator('button[class*="add-to-cart"]').click();
```

### ❌ Nivel 6: Selectores Frágiles (EVITAR)

```typescript
// ❌ EVITAR - Estructura HTML frágil
await page.locator('div > div > button').click(); // Muy frágil

// ❌ EVITAR - Dependiente de posición
await page.locator('button:nth-child(3)').click();

// ❌ EVITAR - IDs dinámicos
await page.locator('#btn-123').click(); // ID puede cambiar

// ❌ EVITAR - Selectores muy largos
await page.locator('body > div.container > main > section:nth-child(2) > div > button').click();
```

---

## Estrategias de Selección

### 1. Combinar Selectores para Robustez

```typescript
export class ProductListPage extends BasePage {
  private readonly selectors = {
    // ✅ Estrategia primaria + fallback
    productCard: '[data-testid="product-card"], article.product',
    addToCartBtn: '[data-testid="add-to-cart"], button:has-text("Añadir")',
    
    // ✅ Selectores anidados para especificidad
    firstProductPrice: '[data-testid="product-card"]:first-child [data-testid="price"]',
    
    // ✅ Combinación de atributos
    submitButton: 'button[type="submit"][data-testid="submit-btn"]',
  };
}
```

### 2. Método con Múltiples Estrategias

```typescript
async clickAddToCart(): Promise<void> {
  // Intenta primero con data-testid
  try {
    await this.page.locator('[data-testid="add-to-cart-btn"]').click();
    return;
  } catch {}

  // Fallback con getByRole
  try {
    await this.page.getByRole('button', { name: /añadir|agregar/i }).click();
    return;
  } catch {}

  // Último recurso con selector CSS
  await this.page.locator('button.add-to-cart').click();
}
```

### 3. Selectores Contextuales

```typescript
// ✅ CORRECTO - Selector específico con contexto
async clickAddToCartForProduct(productName: string): Promise<void> {
  await this.page
    .locator(`[data-testid="product-card"]:has-text("${productName}")`)
    .locator('[data-testid="add-to-cart-btn"]')
    .click();
}

// ✅ CORRECTO - Encadenar locators
const productCard = this.page.locator('[data-testid="product-list"]')
  .locator('[data-testid="product-card"]')
  .first();
await productCard.click();
```

---

## Mejores Prácticas

### 1. Pide data-testid a Desarrollo

```html
<!-- ✅ IDEAL - Colaboración con desarrollo -->
<button data-testid="add-to-cart-btn">Añadir al carrito</button>
<input data-testid="search-input" placeholder="Buscar..." />
<div data-testid="product-card">...</div>
```

**Beneficios**:
- Tests más estables
- Cambios de CSS no rompen tests
- Comunicación clara entre QA y Dev

### 2. Usa Locators Encadenados para Precisión

```typescript
// ✅ CORRECTO - Más específico
await page
  .locator('[data-testid="product-list"]')
  .locator('[data-testid="product-card"]')
  .first()
  .click();

// ⚠️ MENOS PRECISO - Busca en toda la página
await page.locator('[data-testid="product-card"]').first().click();
```

### 3. Evita Selectores Frágiles

```typescript
// ❌ INCORRECTO - Muy frágil
await page.locator('body > div:nth-child(2) > div > button').click();

// ✅ CORRECTO - Robusto
await page.getByRole('button', { name: 'Buscar' }).click();
```

### 4. Usa Text Content con Regex para Flexibilidad

```typescript
// ✅ Acepta variaciones de texto
await page.getByText(/iniciar sesión|login/i).click();
await page.getByText(/precio.*€/i).isVisible();

// ✅ Búsqueda parcial con contains
await page.locator('button:has-text("Añadir")').click();
```

### 5. Selectores con Atributos Múltiples

```typescript
// ✅ Más específico combinando atributos
await page.locator('button[type="submit"][aria-label="Buscar"]').click();
await page.locator('input[name="email"][type="email"]').fill('test@example.com');
```

---

## Patrones de Selectores por Tipo de Elemento

### Botones

```typescript
// ⭐ MEJOR
await page.locator('[data-testid="submit-btn"]').click();

// ✅ BUENO
await page.getByRole('button', { name: 'Enviar' }).click();

// ⚠️ ACEPTABLE
await page.locator('button.btn-primary').click();
```

### Inputs

```typescript
// ⭐ MEJOR
await page.locator('[data-testid="email-input"]').fill('test@example.com');

// ✅ BUENO
await page.getByLabel('Correo electrónico').fill('test@example.com');

// ⚠️ ACEPTABLE
await page.locator('input[name="email"]').fill('test@example.com');
```

### Links

```typescript
// ⭐ MEJOR
await page.locator('[data-testid="home-link"]').click();

// ✅ BUENO
await page.getByRole('link', { name: 'Inicio' }).click();

// ⚠️ ACEPTABLE
await page.locator('a[href="/"]').click();
```

### Dropdowns

```typescript
// ⭐ MEJOR
await page.locator('[data-testid="category-select"]').selectOption('electronics');

// ✅ BUENO
await page.getByLabel('Categoría').selectOption('electronics');

// ⚠️ ACEPTABLE
await page.locator('select[name="category"]').selectOption('electronics');
```

### Checkboxes

```typescript
// ⭐ MEJOR
await page.locator('[data-testid="terms-checkbox"]').check();

// ✅ BUENO
await page.getByLabel('Acepto términos y condiciones').check();

// ⚠️ ACEPTABLE
await page.locator('input[type="checkbox"][name="terms"]').check();
```

---

## Debugging de Selectores

### 1. Verificar si Selector Existe

```typescript
const count = await page.locator('[data-testid="product"]').count();
logger.debug(`Elementos encontrados: ${count}`);

if (count === 0) {
  throw new Error('Selector no encontrado en la página');
}
```

### 2. Listar Todos los Selectores Similares

```typescript
// Listar todos los data-testid
const allTestIds = await page.locator('[data-testid]').all();
logger.debug(`Total elementos con data-testid: ${allTestIds.length}`);

// Listar todos los botones
const allButtons = await page.locator('button').all();
logger.debug(`Total botones: ${allButtons.length}`);
```

### 3. Inspeccionar Atributos del Elemento

```typescript
const element = page.locator('[data-testid="product"]').first();
const attributes = await element.evaluate((el) => ({
  id: el.id,
  class: el.className,
  text: el.textContent,
  visible: el.offsetParent !== null,
}));
logger.debug('Atributos del elemento:', attributes);
```

### 4. Usar Playwright Inspector

```typescript
// En tu código, añade:
await page.pause(); // Abre Playwright Inspector

// O desde terminal:
// $env:PWDEBUG=1; npm test
```

---

## Validación de Selectores con MCP

### Usando MCP de Playwright

```
👤 Prompt:
"Usando MCP de Playwright, navega a https://www.example.com/search-nwx/?s=portátil
y valida que el selector '[data-testid="product-card"]' existe"

🤖 Copilot:
1. Navega a la URL
2. Busca el selector en el DOM
3. Reporta si existe o sugiere alternativas
```

### Generar Selectores desde DOM Real

```
👤 Prompt:
"Inspecciona https://www.example.com/search-nwx/?s=portátil
y genera selectores robustos para:
- Tarjeta de producto
- Botón de añadir al carrito
- Precio del producto"

🤖 Copilot:
Usa MCP de Playwright para capturar DOM y generar selectores basados en:
1. data-testid (si existe)
2. roles ARIA
3. selectores CSS estables
```

---

## Anti-Patrones de Selectores

### ❌ 1. Selectores Dinámicos

```typescript
// ❌ INCORRECTO
await page.locator('#product-12345').click(); // ID dinámico
await page.locator('.product-card-xyz123').click(); // Clase con hash
```

### ❌ 2. Selectores Demasiado Genéricos

```typescript
// ❌ INCORRECTO - Puede seleccionar múltiples elementos
await page.locator('button').click(); // ¿Cuál botón?
await page.locator('div').first(); // ¿Cuál div?
```

### ❌ 3. Selectores con Posiciones Fijas

```typescript
// ❌ INCORRECTO - Frágil si cambia el orden
await page.locator('ul > li:nth-child(3)').click();
await page.locator('div:nth-of-type(5)').click();
```

### ❌ 4. XPath Complejo

```typescript
// ❌ INCORRECTO - Difícil de leer y mantener
await page.locator('//div[@class="container"]/div[2]/button[contains(text(), "Añadir")]').click();

// ✅ CORRECTO - Usa selectores Playwright nativos
await page.getByRole('button', { name: /añadir/i }).click();
```

---

## Convenciones de Naming

### En Page Objects

```typescript
private readonly selectors = {
  // Nombres descriptivos y consistentes
  productCard: '[data-testid="product-card"]',
  addToCartBtn: '[data-testid="add-to-cart-btn"]',
  searchInput: '[data-testid="search-input"]',
  
  // Sufijos estándar:
  // Btn - Botones
  // Input - Campos de texto
  // Select - Dropdowns
  // Checkbox - Checkboxes
  // Link - Enlaces
  // Card - Tarjetas/contenedores
  // List - Listas
};
```

---

## Testing de Selectores

### Script para Validar Selectores

```typescript
// test-selectors.ts
const selectors = {
  productCard: '[data-testid="product-card"]',
  addToCartBtn: '[data-testid="add-to-cart-btn"]',
  searchInput: '[data-testid="search-input"]',
};

for (const [name, selector] of Object.entries(selectors)) {
  const count = await page.locator(selector).count();
  console.log(`${name}: ${count > 0 ? '✅ OK' : '❌ FALLO'} (${count} elementos)`);
}
```

---

## Referencias

- **Playwright Locators**: [Playwright Docs - Locators](https://playwright.dev/docs/locators)
- **Best Practices**: [Playwright Best Practices](https://playwright.dev/docs/best-practices)
- **Accessibility**: [Playwright Accessibility](https://playwright.dev/docs/accessibility-testing)

---

**📌 Recuerda**: Los selectores robustos son la **base de tests estables**. Invierte tiempo en elegir buenos selectores desde el inicio.
