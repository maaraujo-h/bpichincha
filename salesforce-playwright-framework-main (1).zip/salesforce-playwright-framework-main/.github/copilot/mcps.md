# 🔌 Model Context Protocols (MCPs)

---
applyTo: ".vscode/mcp.json, src/pages/**/*.ts, features/**/*.feature, scripts/**/*.ts"
---

Este proyecto utiliza **MCPs oficiales** para mejorar la generación de código y automatización de tareas. Los MCPs están configurados en `.vscode/mcp.json`.

---

## 🎭 MCP de Playwright (Microsoft)

**Paquete**: `@microsoft/mcp-server-playwright`

### Capacidades Disponibles

1. **Navegación y Captura de DOM**
   - Navegar a URLs y capturar estructura HTML
   - Inspeccionar elementos en tiempo real
   - Generar snapshots accesibles de la página

2. **Generación de Selectores Robustos**
   - Análisis de elementos interactivos
   - Sugerencias de selectores por jerarquía (data-testid > role > text)
   - Validación de selectores contra DOM real

3. **Debugging Asistido**
   - Screenshots automáticos
   - Inspección de estado de elementos
   - Verificación de visibilidad y accesibilidad

### Uso con GitHub Copilot

**Ejemplo 1: Generar Page Object desde URL real**
```
👤 Prompt: 
"Usando el MCP de Playwright, navega a https://www.example.com/search-nwx/?s=portátil
y genera un Page Object para SearchResultsPage con selectores robustos"

🤖 Copilot:
1. Navega a la URL usando MCP
2. Captura snapshot del DOM
3. Identifica elementos clave (productos, botones, filtros)
4. Genera SearchResultsPage con:
   - Selectores robustos basados en DOM real
   - Métodos según elementos encontrados
   - Jerarquía de selectores (data-testid > role > class)
```

**Ejemplo 2: Validar y mejorar selectores**
```
👤 Prompt:
"Este selector no funciona: '.product-card button'. 
Usando MCP de Playwright, analiza la página y sugiere alternativas"

🤖 Copilot:
1. Navega a la página de productos
2. Inspecciona estructura de tarjetas de producto
3. Sugiere selectores alternativos:
   - [data-testid="add-to-cart-btn"]
   - button[aria-label*="Añadir"]
   - article button:has-text("Añadir")
```

**Ejemplo 3: Debugging de test fallido**
```
👤 Prompt:
"El test de búsqueda falla en el paso de esperar resultados.
Usa MCP de Playwright para analizar qué está pasando"

🤖 Copilot:
1. Navega a URL de búsqueda
2. Captura screenshot
3. Inspecciona selectores de resultados
4. Identifica problema (selector obsoleto, timeout corto, etc.)
5. Proporciona solución específica
```

---

## 🎫 MCP de Atlassian (Jira)

**Paquete**: `atlassian-mcp-server`

### Capacidades Disponibles

1. **Lectura de Test Cases**
   - Obtener detalles completos de issues (KAN-1212X)
   - Leer pasos de prueba estructurados
   - Extraer criterios de aceptación

2. **Gestión de Issues**
   - Crear issues automáticamente
   - Actualizar estados y comentarios
   - Buscar con JQL

3. **Integración con Tests**
   - Generar features de Gherkin desde tickets
   - Sincronizar resultados de ejecución
   - Crear reportes automáticos

### Configuración Jira

Los MCPs se configuran en `.vscode/mcp.json`. Para el MCP de Atlassian, la configuración se realiza mediante autenticación OAuth en el navegador (no requiere tokens manuales).

**Configuración en `.vscode/mcp.json`**:
```json
{
  "servers": {
    "atlassian/atlassian-mcp-server": {
      "type": "http",
      "url": "https://mcp.atlassian.com/v1/sse"
    }
  }
}
```

### Workflow Completo: De Ticket Jira a Test Automatizado

**Paso 1: Leer Test Case desde Jira**
```
👤 Prompt:
"Lee el test case KAN-1212 desde Jira y genera una implementación completa 
siguiendo las mejores prácticas de este proyecto"

🤖 Copilot ejecuta:
1. mcp_atlassian-mcp_getJiraIssue({ issueIdOrKey: "KAN-1212" })
2. Extrae información del ticket:
   - Título: "[MODA] - PLP - Añadir producto a la cesta"
   - Descripción: Pasos de prueba detallados
   - Criterios de aceptación
   - Pre-condiciones
   - Datos de prueba
```

**Paso 2: Generar Feature File**
```gherkin
# Copilot genera automáticamente:
# language: es
# Referencia: KAN-1212
# URL: https://plataformas.atlassian.net/browse/KAN-1212
@KAN-1212 @smoke @critical
Característica: Añadir producto desde página de listado de productos
  Como usuario del sitio web
  Quiero añadir productos al carrito desde la PLP
  Para realizar compras de forma rápida

  Antecedentes:
    Dado el usuario está en la página principal del sitio web
    Y el usuario acepta las cookies

  @plp @cart
  Escenario: Añadir primer producto al carrito desde PLP
    Cuando el usuario busca "zapatillas nike"
    Y el usuario hace clic en "Añadir" del primer producto
    Entonces el producto debería agregarse al carrito
    Y el contador del carrito debería mostrar 1 producto
```

**Paso 3: Generar Step Definitions**
```typescript
// Copilot genera automáticamente con mejores prácticas:

/**
 * Step Definitions para KAN-1212
 * Añadir producto desde PLP
 */
import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PageFactory } from '../utils/page-factory';
import { logger } from '../utils/logger';

When('el usuario hace clic en {string} del primer producto', async function (actionText: string) {
  logger.info(`Haciendo clic en "${actionText}" del primer producto`);
  const plp = PageFactory.getProductListPage(this, this.page);
  await plp.addFirstProductToCart();
});

Then('el producto debería agregarse al carrito', async function () {
  const plp = PageFactory.getProductListPage(this, this.page);
  const confirmed = await plp.isCartConfirmationVisible();
  expect(confirmed, 'Confirmación de carrito debería ser visible').toBeTruthy();
});
```

**Paso 4: Generar/Mejorar Page Object**
```typescript
// Copilot puede:
// 1. Usar MCP de Playwright para navegar a PLP real
// 2. Capturar selectores del DOM
// 3. Generar Page Object con selectores robustos

/**
 * Referencia: KAN-1212
 * Page Object para página de listado de productos (PLP)
 */
export class ProductListPage extends BasePage {
  // Selectores generados desde DOM real usando MCP Playwright
  private readonly selectors = {
    productCard: '[data-testid="product-card"], article',
    addToCartBtn: '[data-testid="add-to-cart"], button:has-text("Añadir")',
    cartConfirmation: '[data-testid="cart-confirmation"]',
  };

  async addFirstProductToCart(): Promise<void> {
    logger.info('Añadiendo primer producto al carrito');
    await this.waitForResults();
    
    const firstProduct = this.page.locator(this.selectors.productCard).first();
    await firstProduct.hover();
    await firstProduct.locator(this.selectors.addToCartBtn).click();
    
    await this.waitForElement(this.selectors.cartConfirmation);
  }
}
```

---

## 📋 Mejores Prácticas con MCPs

### 1. Siempre Verificar con MCP de Playwright

```
❌ INCORRECTO - Adivinar selectores:
"Genera un Page Object para la página de productos"

✅ CORRECTO - Verificar con MCP:
"Usando MCP de Playwright, navega a [URL] y genera Page Object 
con selectores verificados contra el DOM real"
```

### 2. Leer Tickets Completos de Jira

```
❌ INCORRECTO - Implementar sin contexto:
"Crea un test de búsqueda"

✅ CORRECTO - Usar MCP de Atlassian:
"Lee el ticket KAN-1212X desde Jira y genera implementación completa:
- Feature file con referencia al ticket
- Steps siguiendo las mejores prácticas
- Page Objects necesarios"
```

### 3. Validar Selectores Antes de Commitear

```
👤 Prompt:
"Usando MCP de Playwright, valida que todos los selectores en 
ProductListPage.ts funcionan correctamente en [URL]"

🤖 Copilot:
1. Navega a la URL
2. Intenta localizar cada selector
3. Reporta selectores que fallan
4. Sugiere alternativas robustas
```

### 4. Generar Documentación desde Jira

```
👤 Prompt:
"Lee los tickets KAN-1212, KAN-1213 y KAN-1214 y genera un 
TESTING-PLAN.md documentando la cobertura de tests"

🤖 Copilot genera:
- Tabla con tickets y su estado
- Features implementados vs pendientes
- Criterios de aceptación cumplidos
- Links a tickets de Jira
```

---

## 🎯 Comandos Rápidos para MCPs

### Comandos Jira (MCP Atlassian)

```
# Leer test case completo
"Lee el ticket KAN-1212 y muestra sus detalles"

# Buscar tickets relacionados
"Busca todos los tickets de tipo 'Test' en el proyecto KAN"

# Generar feature desde ticket
"Lee KAN-1212 y genera feature file completo con Gherkin"

# Crear comentario en ticket
"Añade un comentario al ticket KAN-1212 indicando que 
la automatización está completa"

# Buscar con JQL
"Busca en Jira: project = KAN AND type = Test AND status = 'To Do'"
```

### Comandos Playwright (MCP Microsoft)

```
# Navegar y analizar
"Navega a [URL] usando MCP y muestra estructura del DOM"

# Capturar screenshot
"Abre [URL] con MCP y toma screenshot de la página completa"

# Generar selectores
"Inspecciona [URL] y genera selectores robustos para 
el botón de añadir al carrito"

# Validar selectores existentes
"Usando MCP, verifica si el selector '.product-card' 
existe en [URL]"

# Debugging
"Navega a [URL], toma screenshot y muestra elementos clickables"
```

---

## 🔧 Troubleshooting MCPs

### Problema: MCP de Playwright no responde

```bash
# Verificar instalación
npx -y @microsoft/mcp-server-playwright --version

# Ver logs en VS Code
View > Output > GitHub Copilot
```

### Problema: MCP de Atlassian no puede conectar

**Solución**:
1. Verifica que `.vscode/mcp.json` tiene la configuración correcta del servidor HTTP
2. Intenta autenticarte de nuevo (GitHub Copilot te solicitará autenticación OAuth)
3. Verifica que tu cuenta de Atlassian tiene acceso a https://plataformas.atlassian.net
4. Revisa los logs de Copilot: View > Output > GitHub Copilot

```bash
# Probar conexión manualmente (abrirá autenticación OAuth en navegador)
npx -y atlassian-mcp-server
```

### Problema: Proxy bloqueando MCPs

Si necesitas configurar proxy para los MCPs, puedes añadir variables de entorno en `.vscode/mcp.json` dentro de cada servidor:

```json
{
  "servers": {
    "microsoft/playwright-mcp": {
      "type": "stdio",
      "command": "npx",
      "args": ["@playwright/mcp@latest"],
      "env": {
        "HTTP_PROXY": "http://tu-proxy:puerto",
        "HTTPS_PROXY": "http://tu-proxy:puerto",
        "NO_PROXY": "localhost,127.0.0.1"
      }
    }
  }
}
```

---

## 📚 Recursos MCPs

- **MCP de Playwright**: [GitHub - @microsoft/mcp-server-playwright](https://github.com/microsoft/mcp-servers)
- **MCP de Atlassian**: [NPM - atlassian-mcp-server](https://www.npmjs.com/package/atlassian-mcp-server)
- **Documentación MCPs**: Consulta `docs/MCP-GUIDE.md` en este proyecto

---

**📌 Nota**: Para usar MCPs efectivamente, asegúrate de tener la configuración correcta en `.vscode/mcp.json` y que los servidores MCP estén corriendo correctamente. La autenticación OAuth para Atlassian MCP se gestiona automáticamente al primer uso.
