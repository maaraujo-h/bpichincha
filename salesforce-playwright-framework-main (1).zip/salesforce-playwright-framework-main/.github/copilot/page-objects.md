# 📄 Page Object Model (POM)

---
applyTo: "src/pages/**/*.ts, src/utils/page-factory.ts"
---

## Jerarquía de Page Objects

```typescript
BasePage (abstracta)
  ├── HomePage
  ├── SearchResultsPage
  ├── ProductDetailPage
  └── CartPage
```

---

## Estructura de un Page Object

```typescript
/**
 * Referencia: KAN-1212
 * Page Object para la página de listado de productos (PLP)
 * 
 * @example
 * const plp = PageFactory.getProductListPage(context, page);
 * await plp.waitForResults();
 * await plp.addFirstProductToCart();
 */
import { Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { logger } from '../utils/logger';
import { TIMEOUTS } from '../utils/constants';

export class ProductListPage extends BasePage {
  // 1. SELECTORES - Centralizados y con nombres descriptivos
  private readonly selectors = {
    productCard: '[data-testid="product-card"]',
    productTitle: '[data-testid="product-title"]',
    productPrice: '[data-testid="product-price"]',
    addToCartBtn: '[data-testid="add-to-cart-btn"]',
    cartConfirmation: '[data-testid="cart-confirmation"]',
    loadingSpinner: '.loading-spinner',
  };

  constructor(page: Page) {
    super(page);
  }

  // 2. MÉTODOS DE NAVEGACIÓN
  async navigateToCategory(category: string): Promise<void> {
    logger.info(`Navegando a categoría: ${category}`);
    await this.navigate(`/categoria/${category}`);
    await this.waitForResults();
  }

  // 3. MÉTODOS DE ESPERA
  async waitForResults(): Promise<void> {
    logger.info('Esperando resultados de productos');
    await this.waitForElement(this.selectors.productCard, TIMEOUTS.LONG);
    await this.waitForLoadingToDisappear();
  }

  private async waitForLoadingToDisappear(): Promise<void> {
    await this.page.waitForSelector(this.selectors.loadingSpinner, {
      state: 'hidden',
      timeout: TIMEOUTS.MEDIUM,
    });
  }

  // 4. MÉTODOS DE ACCIÓN
  async addFirstProductToCart(): Promise<void> {
    logger.info('Añadiendo primer producto al carrito');
    
    // Esperar que haya productos
    await this.waitForResults();
    
    // Hacer hover para mostrar botón
    const firstProduct = this.page.locator(this.selectors.productCard).first();
    await firstProduct.hover();
    
    // Click en añadir
    await firstProduct.locator(this.selectors.addToCartBtn).click();
    
    // Verificar confirmación
    await this.waitForElement(this.selectors.cartConfirmation);
  }

  async filterByPrice(min: number, max: number): Promise<void> {
    logger.info(`Filtrando por precio: ${min}-${max}`);
    // Implementación del filtrado
  }

  // 5. MÉTODOS DE VERIFICACIÓN (retornan boolean)
  async isCartConfirmationVisible(): Promise<boolean> {
    try {
      await this.waitForElement(this.selectors.cartConfirmation, TIMEOUTS.SHORT);
      return true;
    } catch {
      return false;
    }
  }

  async hasProducts(): Promise<boolean> {
    const count = await this.getProductCount();
    return count > 0;
  }

  // 6. MÉTODOS DE OBTENCIÓN DE DATOS
  async getProductCount(): Promise<number> {
    await this.waitForResults();
    return await this.page.locator(this.selectors.productCard).count();
  }

  async getFirstProductTitle(): Promise<string> {
    await this.waitForResults();
    return await this.page.locator(this.selectors.productTitle).first().textContent() || '';
  }

  async getAllProductTitles(): Promise<string[]> {
    await this.waitForResults();
    return await this.page.locator(this.selectors.productTitle).allTextContents();
  }
}
```

---

## Mejores Prácticas de POM

### 1. Hereda de BasePage

```typescript
export class MyPage extends BasePage {
  constructor(page: Page) {
    super(page);
  }
}
```

**Beneficios**:
- Reutilización de métodos comunes (`waitForElement`, `navigate`, etc.)
- Consistencia en toda la suite
- Fácil mantenimiento

### 2. Centraliza selectores

```typescript
// ❌ INCORRECTO - Selectores dispersos
async addToCart(): Promise<void> {
  await this.page.click('#submit-btn');
  await this.page.waitForSelector('#submit-btn'); // Duplicado
}

// ✅ CORRECTO - Selectores centralizados
private readonly selectors = {
  submitBtn: '#submit-btn'
};

async addToCart(): Promise<void> {
  await this.click(this.selectors.submitBtn);
}
```

**Ventajas**:
- Cambios en un solo lugar
- Fácil identificar selectores usados
- Evita duplicación

### 3. Nombres descriptivos de métodos

```typescript
// ❌ INCORRECTO
async doAction(): Promise<void>
async click1(): Promise<void>

// ✅ CORRECTO
async addFirstProductToCart(): Promise<void>
async filterByPriceRange(min: number, max: number): Promise<void>
```

### 4. Retorna datos, no hagas assertions en Page Objects

```typescript
// ❌ INCORRECTO - Assertion en Page Object
async verifyTitle(): Promise<void> {
  expect(await this.getTitle()).toBe('Expected');
}

// ✅ CORRECTO - Retorna dato para assertion en Step
async getTitle(): Promise<string> {
  return await this.page.title();
}
```

**Razón**: Las assertions deben estar en Steps, no en Page Objects. Los POs solo proporcionan datos.

### 5. Agrupa métodos por categoría

Ordena métodos en este orden:

1. **Constructor**
2. **Métodos de navegación**
3. **Métodos de espera**
4. **Métodos de acción**
5. **Métodos de verificación** (retornan boolean)
6. **Métodos de obtención de datos** (getters)

### 6. Documenta con JSDoc

```typescript
/**
 * Añade el primer producto de la lista al carrito
 * 
 * @throws {Error} Si no hay productos disponibles
 * @returns {Promise<void>}
 * 
 * @example
 * await plp.addFirstProductToCart();
 */
async addFirstProductToCart(): Promise<void> {
  // Implementación
}
```

### 7. Usa Factory Pattern

```typescript
// En PageFactory
static getProductListPage(context: any, page: Page): ProductListPage {
  if (!context.productListPage) {
    context.productListPage = new ProductListPage(page);
  }
  return context.productListPage;
}

// En Steps
const plp = PageFactory.getProductListPage(this.context, this.page);
```

---

## BasePage - Métodos Comunes

```typescript
export abstract class BasePage {
  constructor(protected page: Page) {}

  /**
   * Navega a una URL relativa
   */
  protected async navigate(path: string): Promise<void> {
    await this.page.goto(path, { waitUntil: 'commit' });
  }

  /**
   * Espera a que un elemento esté visible
   */
  protected async waitForElement(selector: string, timeout?: number): Promise<void> {
    await this.page.waitForSelector(selector, {
      state: 'visible',
      timeout: timeout || TIMEOUTS.MEDIUM,
    });
  }

  /**
   * Hace clic en un elemento
   */
  protected async click(selector: string): Promise<void> {
    await this.page.click(selector);
  }

  /**
   * Rellena un campo de texto
   */
  protected async fill(selector: string, text: string): Promise<void> {
    await this.page.fill(selector, text);
  }

  /**
   * Obtiene el texto de un elemento
   */
  protected async getText(selector: string): Promise<string> {
    return await this.page.locator(selector).textContent() || '';
  }
}
```

---

## Organización de Métodos

### Ejemplo Completo de Page Object

```typescript
export class SearchResultsPage extends BasePage {
  // 1. SELECTORES
  private readonly selectors = {
    searchInput: '[data-testid="search-input"]',
    searchButton: '[data-testid="search-btn"]',
    resultsList: '[data-testid="results-list"]',
    productCard: '[data-testid="product-card"]',
    noResultsMsg: '[data-testid="no-results"]',
  };

  constructor(page: Page) {
    super(page);
  }

  // 2. NAVEGACIÓN
  async navigateToSearch(): Promise<void> {
    await this.navigate('/search');
  }

  // 3. ESPERAS
  async waitForResults(): Promise<void> {
    await this.waitForElement(this.selectors.resultsList);
  }

  // 4. ACCIONES
  async search(term: string): Promise<void> {
    await this.fill(this.selectors.searchInput, term);
    await this.click(this.selectors.searchButton);
    await this.waitForResults();
  }

  async filterByCategory(category: string): Promise<void> {
    // Implementación
  }

  // 5. VERIFICACIONES (boolean)
  async hasResults(): Promise<boolean> {
    const count = await this.getResultCount();
    return count > 0;
  }

  async isNoResultsMessageVisible(): Promise<boolean> {
    try {
      await this.waitForElement(this.selectors.noResultsMsg, TIMEOUTS.SHORT);
      return true;
    } catch {
      return false;
    }
  }

  // 6. GETTERS (datos)
  async getResultCount(): Promise<number> {
    return await this.page.locator(this.selectors.productCard).count();
  }

  async getFirstResultTitle(): Promise<string> {
    return await this.getText(this.selectors.productCard + ' h2');
  }
}
```

---

## Patrones Avanzados

### 1. Métodos con Retry

```typescript
async clickWithRetry(selector: string, retries: number = 3): Promise<void> {
  for (let i = 0; i < retries; i++) {
    try {
      await this.page.click(selector, { timeout: TIMEOUTS.SHORT });
      return;
    } catch (error) {
      if (i === retries - 1) throw error;
      logger.warn(`Retry ${i + 1}/${retries} para click en ${selector}`);
      await this.page.waitForTimeout(1000);
    }
  }
}
```

### 2. Métodos con Fallback de Selectores

```typescript
async clickAddToCart(): Promise<void> {
  const selectors = [
    '[data-testid="add-to-cart"]',
    'button:has-text("Añadir")',
    '.add-to-cart-btn',
  ];

  for (const selector of selectors) {
    try {
      await this.page.click(selector, { timeout: TIMEOUTS.SHORT });
      return;
    } catch {
      logger.debug(`Selector ${selector} no encontrado, intentando siguiente`);
    }
  }
  
  throw new Error('No se encontró el botón de añadir al carrito');
}
```

### 3. Métodos Genéricos

```typescript
async selectDropdownOption(dropdownSelector: string, optionText: string): Promise<void> {
  await this.click(dropdownSelector);
  await this.page.click(`text="${optionText}"`);
}

async uploadFile(fileInputSelector: string, filePath: string): Promise<void> {
  await this.page.setInputFiles(fileInputSelector, filePath);
}
```

---

## Anti-Patrones a Evitar

### ❌ 1. Lógica de negocio en Page Objects

```typescript
// ❌ INCORRECTO
async verifyProductAdded(): Promise<void> {
  const count = await this.getCartCount();
  expect(count).toBeGreaterThan(0); // ¡Assertion en PO!
}

// ✅ CORRECTO
async getCartCount(): Promise<number> {
  return await this.page.locator('[data-testid="cart-count"]').count();
}
```

### ❌ 2. Selectores hardcodeados múltiples veces

```typescript
// ❌ INCORRECTO
async clickButton(): Promise<void> {
  await this.page.click('#btn-submit');
}

async waitForButton(): Promise<void> {
  await this.page.waitForSelector('#btn-submit'); // Duplicado
}

// ✅ CORRECTO
private readonly selectors = {
  submitBtn: '#btn-submit'
};

async clickButton(): Promise<void> {
  await this.click(this.selectors.submitBtn);
}
```

### ❌ 3. Page Objects gigantes

```typescript
// ❌ INCORRECTO - 500+ líneas, 50+ métodos
export class MegaPage extends BasePage {
  // Demasiada responsabilidad
}

// ✅ CORRECTO - Dividir en componentes
export class HeaderComponent extends BasePage { }
export class FooterComponent extends BasePage { }
export class ProductListComponent extends BasePage { }
```

### ❌ 4. Acceso directo al Page en Steps

```typescript
// ❌ INCORRECTO - Acceso directo en Step
When('...', async function () {
  await this.page.click('#btn'); // ¡Saltando PO!
});

// ✅ CORRECTO - Siempre a través de PO
When('...', async function () {
  const homePage = PageFactory.getHomePage(this, this.page);
  await homePage.clickButton();
});
```

---

## Convenciones de Naming

### Archivos
- **PascalCase**: `HomePage.ts`, `SearchResultsPage.ts`
- **Sufijo "Page"**: Siempre terminar con `Page`

### Clases
```typescript
export class HomePage extends BasePage { }
export class SearchResultsPage extends BasePage { }
```

### Métodos
- **camelCase**: `addToCart()`, `getProductCount()`
- **Verbos descriptivos**: `add`, `get`, `wait`, `is`, `has`

### Selectores
- **camelCase**: `productCard`, `addToCartBtn`
- **Sufijos descriptivos**: `Btn`, `Input`, `List`, `Card`

---

## Testing de Page Objects

```typescript
// Para debugging/testing manual
async debugPageState(): Promise<void> {
  const state = {
    url: this.page.url(),
    title: await this.page.title(),
    productCount: await this.getProductCount(),
  };
  logger.debug('Estado de la página:', state);
}
```

---

## Referencias

- **Patrón POM**: [Martin Fowler - Page Object](https://martinfowler.com/bliki/PageObject.html)
- **Playwright Locators**: [Playwright Docs](https://playwright.dev/docs/locators)
- **Ejemplos del proyecto**: Ver `src/pages/`

---

**📌 Recuerda**: Page Objects deben ser **simples**, **reutilizables** y **fáciles de mantener**. No deben contener lógica de negocio ni assertions.
