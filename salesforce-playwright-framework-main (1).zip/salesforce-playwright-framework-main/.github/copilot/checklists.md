# ✅ Checklists de Desarrollo

---
applyTo: "**/*"

---

## 📝 Checklist Pre-Commit

Antes de hacer commit, verifica:

### Organización y Estructura

- [ ] **Feature file en subdirectorio funcional** (`features/cart/`, `features/search/`, etc.)
- [ ] **Feature file con nombre descriptivo** (`add-product-from-plp.feature`, NO `KAN-1212.feature`)
- [ ] **Steps nombrados según Page Object** (`cart.steps.ts`, NO `KAN-1212.steps.ts`)
- [ ] **Steps no duplicados** (busqué en todos los archivos antes de crear)

### Page Objects y Selectores

- [ ] **Page Objects heredan de BasePage**
- [ ] **Selectores centralizados** en objeto `selectors`
- [ ] **Uso de selectores robustos**: `data-testid` > `getByRole` > `has-text` > CSS
- [ ] **Selectores verificados con MCP Playwright** (cuando sea posible)

### Código y Calidad

- [ ] **Timeouts apropiados** según tipo de operación (TIMEOUTS.SHORT/MEDIUM/LONG)
- [ ] **Logging sin IDs de tickets** (`logger.info('Añadiendo producto')`, NO `'KAN-1212: ...'`)
- [ ] **Errores sin IDs de tickets** (`throw new Error('No hay productos')`, NO `'KAN-1212: ...'`)
- [ ] **JSDoc completo** en métodos públicos (con tickets relacionados en @see)
- [ ] **TypeScript estricto** (sin `any`, tipos explícitos)
- [ ] **Código formateado** (Prettier ejecutado: `npm run format`)
- [ ] **Sin errores de ESLint** (`npm run lint`)

### Tests y Documentación

- [ ] **Tests independientes** (no dependen de orden de ejecución)
- [ ] **Referencia a ticket** en comentarios del feature (`# Ticket: KAN-1212`)
- [ ] **Tags apropiados** incluyendo ID de ticket (`@KAN-1212 @cart @smoke`)
- [ ] **Tests pasando localmente** (todos los escenarios: `npm test`)

### MCPs y Verificación

- [ ] **Ticket leído desde Jira** (si aplica MCP Atlassian)
- [ ] **DOM verificado en sitio real** (si aplica MCP Playwright)
- [ ] **Documentación actualizada** (README, guides si es necesario)

---

## 🎯 Checklist de Feature File

### Estructura

- [ ] **Declaración de idioma** al inicio: `# language: es`
- [ ] **Comentarios con referencia** al ticket de Jira
- [ ] **Tags apropiados** en Feature y Escenarios
- [ ] **Descripción clara** en formato "Como... Quiero... Para..."
- [ ] **Antecedentes (Background)** si hay setup común

### Escenarios

- [ ] **Escenarios independientes** (no dependen entre sí)
- [ ] **Patrón Given-When-Then** respetado
- [ ] **Lenguaje de negocio** (no técnico)
- [ ] **Escenarios declarativos** (qué, no cómo)
- [ ] **Uso de Scenario Outline** cuando hay datos similares

### Calidad

- [ ] **Máximo 10-15 escenarios** por feature
- [ ] **Steps reutilizables** (no específicos del ticket)
- [ ] **Sin referencias a IDs de tickets** en los steps de Gherkin

---

## 📄 Checklist de Page Object

### Estructura Base

- [ ] **Hereda de BasePage**
- [ ] **Constructor recibe Page** de Playwright
- [ ] **JSDoc completo** en la clase

### Selectores

- [ ] **Selectores centralizados** en objeto `selectors`
- [ ] **Nombres descriptivos** (camelCase + sufijo)
- [ ] **Jerarquía de selectores**: data-testid > role > text > CSS
- [ ] **Sin selectores hardcodeados** en métodos

### Métodos

- [ ] **Métodos agrupados** por categoría (navegación, espera, acción, verificación, datos)
- [ ] **Nombres descriptivos** (verbos + sustantivos)
- [ ] **Retornan datos**, NO hacen assertions
- [ ] **Async/await** siempre
- [ ] **Try-catch** en operaciones críticas
- [ ] **Logging apropiado** (sin IDs de tickets)
- [ ] **JSDoc en métodos públicos**

---

## 🔄 Checklist de Step Definitions

### Organización

- [ ] **Archivo nombrado** según Page Object o funcionalidad
- [ ] **NO nombrado** con ID de ticket
- [ ] **Imports organizados** (Cucumber > Testing > Utils)
- [ ] **JSDoc con tickets relacionados** (en comentarios)

### Steps

- [ ] **NUNCA duplicados** (buscar antes de crear)
- [ ] **Parámetros tipados** ({int}, {string}, etc.)
- [ ] **Uso de PageFactory** para obtener instancias
- [ ] **Logging sin IDs de tickets**
- [ ] **Errores sin IDs de tickets**
- [ ] **Try-catch apropiado**

### Assertions

- [ ] **Assertions en Steps**, NO en Page Objects
- [ ] **Mensajes claros** en assertions
- [ ] **expect() de Playwright** para elementos del DOM

---

## 🎯 Checklist de Selectores

### Selección de Selector

- [ ] **Preferencia por data-testid** si existe
- [ ] **Fallback con getByRole** si no hay data-testid
- [ ] **Evitar selectores frágiles** (nth-child, estructura HTML)
- [ ] **Evitar IDs dinámicos**

### Verificación

- [ ] **Selector validado** en página real
- [ ] **MCP Playwright usado** para verificar (si es posible)
- [ ] **Selector funciona** en diferentes estados de página

---

## 💻 Checklist de TypeScript

### Tipado

- [ ] **Sin 'any'** (usar tipos específicos)
- [ ] **Interfaces/Types definidos** para objetos complejos
- [ ] **Parámetros tipados** explícitamente
- [ ] **Return types explícitos** en funciones

### Código

- [ ] **Async/await** consistente (no mezclar con .then())
- [ ] **Null safety** (optional chaining, nullish coalescing)
- [ ] **Readonly** en propiedades inmutables
- [ ] **Named exports** (no default exports)

---

## ⚡ Checklist de Performance

### Navegación

- [ ] **waitUntil apropiado** (commit/domcontentloaded, NO networkidle)
- [ ] **Timeouts según operación**
- [ ] **Sin waitForTimeout** (usar esperas condicionales)

### Selectores

- [ ] **Locators reutilizados** cuando sea posible
- [ ] **Scope limitado** (locators encadenados)
- [ ] **Sin búsquedas innecesarias**

### Ejecución

- [ ] **Operaciones independientes** en paralelo (Promise.all)
- [ ] **Sin esperas innecesarias**

---

## 🐛 Checklist de Debugging

### Logging

- [ ] **Logger importado** y usado
- [ ] **Niveles apropiados** (error, warn, info, debug)
- [ ] **Mensajes descriptivos**
- [ ] **Sin información sensible** en logs

### Screenshots

- [ ] **Screenshot en fallos** (configurado en hooks)
- [ ] **Screenshots de debugging** eliminados antes de commit

### Debugging Tools

- [ ] **Breakpoints eliminados** antes de commit
- [ ] **console.log eliminados** antes de commit
- [ ] **page.pause() eliminados** antes de commit

---

## 🧪 Checklist de Testing

### Tests

- [ ] **Tests independientes** (limpian su estado)
- [ ] **Datos de test centralizados** (TEST_DATA)
- [ ] **Tags apropiados** (@smoke, @critical, @KAN-1212X)
- [ ] **Tests pasan localmente**

### Assertions

- [ ] **Assertions claras** con mensajes
- [ ] **expect() de Playwright** para elementos DOM
- [ ] **Verificaciones específicas** (no vagas)

---

## 📊 Checklist de CI/CD

### Antes de Push

- [ ] **Tests locales pasan**
- [ ] **Lint sin errores**
- [ ] **Build exitoso** (si aplica)
- [ ] **No hay archivos temporales** en staging

### Después de Push

- [ ] **Pipeline de CI pasa**
- [ ] **Verificar resultados** en CI/CD
- [ ] **Revisar reportes** generados

---

## 🔗 Checklist de Documentación

### Código

- [ ] **JSDoc en clases** públicas
- [ ] **JSDoc en métodos** públicos
- [ ] **Comentarios útiles** (no obvios)
- [ ] **TODOs documentados** si quedan pendientes

### Proyecto

- [ ] **README actualizado** si es necesario
- [ ] **CHANGELOG actualizado** con cambios importantes
- [ ] **Documentación en docs/** actualizada

---

## 🎓 Checklist de Pull Request

### Antes de Crear PR

- [ ] **Todos los checklists anteriores** completados
- [ ] **Branch actualizado** con main/develop
- [ ] **Commits con mensajes claros**
- [ ] **Sin archivos innecesarios** (node_modules, .env, etc.)

### Descripción del PR

- [ ] **Título descriptivo**
- [ ] **Referencias a tickets** de Jira (KAN-1212X)
- [ ] **Descripción de cambios**
- [ ] **Screenshots/videos** si aplica
- [ ] **Instrucciones de testing** si es necesario

### Revisión

- [ ] **Self-review completado**
- [ ] **Tests nuevos añadidos** para nueva funcionalidad
- [ ] **Tests existentes actualizados** si es necesario

---

## 📚 Referencias Rápidas

### Comandos Útiles

```bash
# Formatear código
npm run format

# Lint
npm run lint

# Ejecutar tests
npm test

# Ejecutar tests con tag específico
npm test -- --tags "@KAN-1212"

# Ejecutar con navegador visible
$env:HEADLESS="false"; npm test

# Debug con Playwright Inspector
$env:PWDEBUG=1; npm test
```

### Archivos Clave

- `features/` - Feature files (Gherkin)
- `src/pages/` - Page Objects
- `src/steps/` - Step Definitions
- `src/utils/constants.ts` - Timeouts y constantes
- `src/utils/test-data.ts` - Datos de prueba
- `playwright.config.ts` - Configuración Playwright
- `cucumber.js` - Configuración Cucumber

---

**📌 Tip**: Imprime este checklist y tenlo a mano mientras desarrollas. Con el tiempo, estos puntos se volverán segunda naturaleza.
