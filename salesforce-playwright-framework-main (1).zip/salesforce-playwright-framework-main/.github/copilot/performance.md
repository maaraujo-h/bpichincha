# ⚡ Performance y Timeouts

---
applyTo: "src/**/*.ts, playwright.config.ts, cucumber.js"
---

## Configuración de Timeouts

### Constantes Centralizadas

```typescript
// src/utils/constants.ts
export const TIMEOUTS = {
  // Operaciones rápidas (verificaciones simples)
  SHORT: 3000,      // 3 segundos
  
  // Operaciones normales (clicks, fills)
  MEDIUM: 10000,    // 10 segundos
  
  // Operaciones complejas (búsquedas, filtros)
  LONG: 25000,      // 25 segundos
  
  // Navegación de páginas
  NAVIGATION: 30000, // 30 segundos
} as const;
```

---

## Uso de Timeouts

### Por Tipo de Operación

```typescript
// ✅ CORRECTO - Timeout apropiado según operación
async waitForSearchResults(): Promise<void> {
  await this.page.waitForSelector(
    '[data-testid="search-results"]',
    { timeout: TIMEOUTS.LONG } // Búsqueda puede tardar
  );
}

async clickButton(): Promise<void> {
  await this.page.click(
    'button',
    { timeout: TIMEOUTS.SHORT } // Click es rápido
  );
}

async navigateToPage(url: string): Promise<void> {
  await this.page.goto(url, {
    timeout: TIMEOUTS.NAVIGATION // Navegación necesita más tiempo
  });
}

// ❌ INCORRECTO - Timeout fijo para todo
await this.page.waitForSelector('selector', { timeout: 30000 }); // ¡No hardcodear!
```

---

## Optimizaciones de Navegación

### WaitUntil Strategies

```typescript
// ✅ CORRECTO - 'commit' para iniciar navegación rápida
async navigate(url: string): Promise<void> {
  await this.page.goto(url, {
    waitUntil: 'commit', // Inicia navegación sin esperar carga completa
    timeout: TIMEOUTS.NAVIGATION
  });
}

// ✅ CORRECTO - 'domcontentloaded' para páginas SPA
async navigateToSPA(url: string): Promise<void> {
  await this.page.goto(url, {
    waitUntil: 'domcontentloaded', // DOM listo, pero recursos pueden cargar
    timeout: TIMEOUTS.NAVIGATION
  });
}

// ⚠️ USO OCASIONAL - 'load' para páginas con recursos importantes
async navigateWithResources(url: string): Promise<void> {
  await this.page.goto(url, {
    waitUntil: 'load', // Espera a que todos los recursos se carguen
    timeout: TIMEOUTS.NAVIGATION
  });
}

// ❌ EVITAR - 'networkidle' es muy lento
await this.page.goto(url, { 
  waitUntil: 'networkidle' // ¡Evitar! Espera a que no haya red activa
});
```

**Comparación de waitUntil**:

| Estrategia | Tiempo | Cuándo usar |
|------------|--------|-------------|
| `commit` | ⚡ Rápido | Navegación inicial, tests rápidos |
| `domcontentloaded` | ⚡⚡ Medio | SPAs, páginas con lazy loading |
| `load` | ⚡⚡⚡ Lento | Páginas con recursos críticos |
| `networkidle` | ❌ Muy lento | Evitar, puede ser impredecible |

---

## Auto-waiting de Playwright

### Playwright Espera Automáticamente

```typescript
// ✅ CORRECTO - Playwright espera automáticamente
async fillForm(): Promise<void> {
  // No necesitas waitForSelector antes de cada acción
  await this.page.fill('[name="email"]', 'user@example.com');
  await this.page.fill('[name="password"]', 'password123');
  await this.page.click('button[type="submit"]');
  // Playwright verifica automáticamente:
  // - Elemento existe
  // - Elemento visible
  // - Elemento habilitado
  // - Elemento estable (no se mueve)
}

// ❌ INCORRECTO - Esperas innecesarias
async fillFormBad(): Promise<void> {
  await this.page.waitForSelector('[name="email"]'); // Innecesario
  await this.page.fill('[name="email"]', 'user@example.com');
  await this.page.waitForTimeout(1000); // ¡Nunca usar waitForTimeout!
  await this.page.fill('[name="password"]', 'password123');
}
```

### Cuándo SÍ usar esperas explícitas

```typescript
// ✅ CORRECTO - Esperar a que elemento desaparezca
async waitForLoadingToDisappear(): Promise<void> {
  await this.page.waitForSelector('.loading-spinner', {
    state: 'hidden',
    timeout: TIMEOUTS.MEDIUM,
  });
}

// ✅ CORRECTO - Esperar a que elemento esté adjunto al DOM
async waitForElement(selector: string): Promise<void> {
  await this.page.waitForSelector(selector, {
    state: 'attached',
    timeout: TIMEOUTS.MEDIUM,
  });
}

// ✅ CORRECTO - Esperar condición personalizada
async waitForProductCount(minCount: number): Promise<void> {
  await this.page.waitForFunction(
    (min) => document.querySelectorAll('[data-testid="product"]').length >= min,
    minCount,
    { timeout: TIMEOUTS.LONG }
  );
}
```

---

## Optimización de Selectores

### Selectores Eficientes

```typescript
// ✅ RÁPIDO - Selector específico
await page.locator('[data-testid="submit-btn"]').click();

// ⚠️ LENTO - Selector muy genérico que busca en todo el DOM
await page.locator('button').first().click();

// ✅ OPTIMIZADO - Limitar scope de búsqueda
const form = page.locator('[data-testid="login-form"]');
await form.locator('button[type="submit"]').click();
```

### Reutilizar Locators

```typescript
// ✅ CORRECTO - Reutilizar locator
async getProductInfo(): Promise<{ title: string; price: string }> {
  const product = this.page.locator('[data-testid="product"]').first();
  
  const title = await product.locator('[data-testid="title"]').textContent() || '';
  const price = await product.locator('[data-testid="price"]').textContent() || '';
  
  return { title, price };
}

// ❌ INEFICIENTE - Buscar múltiples veces
async getProductInfoBad(): Promise<{ title: string; price: string }> {
  const title = await this.page.locator('[data-testid="product"]').first()
    .locator('[data-testid="title"]').textContent() || '';
  const price = await this.page.locator('[data-testid="product"]').first()
    .locator('[data-testid="price"]').textContent() || ''; // Busca de nuevo
  
  return { title, price };
}
```

---

## Paralelización

### Ejecución Paralela Segura

```typescript
// ✅ CORRECTO - Operaciones independientes en paralelo
async loadPageData(): Promise<void> {
  const [productCount, categoryCount, userInfo] = await Promise.all([
    this.getProductCount(),
    this.getCategoryCount(),
    this.getUserInfo(),
  ]);
  
  logger.info(`Cargados: ${productCount} productos, ${categoryCount} categorías`);
}

// ❌ INCORRECTO - Secuencial cuando podría ser paralelo
async loadPageDataSlow(): Promise<void> {
  const productCount = await this.getProductCount();
  const categoryCount = await this.getCategoryCount(); // Espera innecesaria
  const userInfo = await this.getUserInfo(); // Espera innecesaria
}
```

### Cucumber Parallel Workers

```javascript
// cucumber.js
module.exports = {
  default: {
    parallel: 3, // Ejecuta 3 workers en paralelo
    retry: 2,    // Reintenta tests fallidos 2 veces
  },
};
```

---

## Evitar Waits Fijos

### ❌ Nunca uses waitForTimeout

```typescript
// ❌ INCORRECTO - Wait fijo (flaky, lento)
await this.page.waitForTimeout(3000);
await this.page.click('button');

// ✅ CORRECTO - Wait dinámico basado en condiciones
await this.page.waitForSelector('button', { state: 'visible' });
await this.page.click('button');
```

### Alternativas a waitForTimeout

```typescript
// En lugar de: await page.waitForTimeout(5000);

// ✅ Esperar elemento visible
await page.waitForSelector('[data-testid="element"]', { state: 'visible' });

// ✅ Esperar navegación
await page.waitForURL('**/search?q=*');

// ✅ Esperar condición personalizada
await page.waitForFunction(() => window.dataLoaded === true);

// ✅ Esperar respuesta de API
await page.waitForResponse(response => 
  response.url().includes('/api/products') && response.status() === 200
);
```

---

## Network Optimization

### Bloquear Recursos Innecesarios

```typescript
// playwright.config.ts - Bloquear imágenes, fuentes, etc.
use: {
  // Bloquear tipos de recursos que no necesitas
  // SOLO si los tests no dependen de estos recursos
  launchOptions: {
    args: [
      '--disable-images',
      '--disable-fonts',
    ],
  },
}
```

### Interceptar Requests

```typescript
// Bloquear requests a analytics/tracking
await page.route('**/*', (route) => {
  const url = route.request().url();
  if (url.includes('analytics') || url.includes('tracking')) {
    route.abort();
  } else {
    route.continue();
  }
});
```

---

## Caching y State Reuse

### Reutilizar Authentication State

```typescript
// Guardar estado de autenticación
const context = await browser.newContext();
await context.page().goto('/login');
await context.page().fill('[name="email"]', 'user@example.com');
await context.page().fill('[name="password"]', 'password');
await context.page().click('button[type="submit"]');

// Guardar cookies/storage
await context.storageState({ path: 'auth.json' });

// Reutilizar en otros tests
const newContext = await browser.newContext({
  storageState: 'auth.json' // Carga estado guardado
});
```

---

## Métricas de Performance

### Medir Tiempos de Ejecución

```typescript
async measurePerformance<T>(
  name: string, 
  fn: () => Promise<T>
): Promise<T> {
  const start = Date.now();
  try {
    const result = await fn();
    const duration = Date.now() - start;
    logger.info(`${name} completado en ${duration}ms`);
    return result;
  } catch (error) {
    const duration = Date.now() - start;
    logger.error(`${name} falló después de ${duration}ms`, error);
    throw error;
  }
}

// Uso
await this.measurePerformance('Búsqueda de productos', async () => {
  await this.search('portátil');
});
```

### Web Vitals con Playwright

```typescript
async getWebVitals(): Promise<void> {
  const metrics = await this.page.evaluate(() => {
    return {
      // Core Web Vitals
      LCP: performance.getEntriesByType('largest-contentful-paint')[0]?.startTime,
      FID: performance.getEntriesByType('first-input')[0]?.processingStart,
      CLS: 0, // Requiere cálculo más complejo
    };
  });
  
  logger.info('Web Vitals:', metrics);
}
```

---

## Configuración de Browser

### Opciones de Rendimiento

```typescript
// playwright.config.ts
use: {
  // Desactivar animaciones para tests más rápidos
  viewport: { width: 1280, height: 720 },
  
  // Reducir timeout global
  actionTimeout: 10000,
  navigationTimeout: 30000,
  
  // Screenshot solo en fallos
  screenshot: 'only-on-failure',
  
  // Video solo en retry
  video: 'retain-on-failure',
  
  // Trace solo en fallos
  trace: 'retain-on-failure',
}
```

---

## Best Practices Summary

### ✅ DO

- Usa `commit` o `domcontentloaded` para navegación
- Usa `TIMEOUTS` constants según tipo de operación
- Aprovecha auto-waiting de Playwright
- Ejecuta operaciones independientes en paralelo
- Reutiliza locators cuando sea posible
- Mide performance de operaciones críticas

### ❌ DON'T

- ❌ No uses `waitForTimeout` (flaky)
- ❌ No uses `networkidle` (muy lento)
- ❌ No uses timeouts fijos hardcodeados
- ❌ No hagas esperas innecesarias
- ❌ No ejecutes operaciones secuencialmente si pueden ser paralelas
- ❌ No busques elementos múltiples veces

---

## Referencias

- **Playwright Performance**: [Playwright Best Practices](https://playwright.dev/docs/best-practices)
- **Web Vitals**: [Web Vitals Guide](https://web.dev/vitals/)

---

**📌 Recuerda**: Tests rápidos = feedback rápido = mejor productividad. Optimiza sin sacrificar estabilidad.
