# 🐛 Logging y Debugging

---
applyTo: "src/**/*.ts, .vscode/launch.json, src/utils/logger.ts"
---

## Sistema de Logging

### Niveles de Log

```typescript
import { logger } from '../utils/logger';

// Niveles disponibles (de menos a más verbose)
logger.error('Error crítico', error);    // Errores que rompen ejecución
logger.warn('Advertencia');              // Advertencias no críticas
logger.info('Información general');      // Flujo normal de ejecución
logger.debug('Información de debugging'); // Detalles técnicos
```

### Uso Estratégico de Logging

```typescript
export class ProductListPage extends BasePage {
  async addFirstProductToCart(): Promise<void> {
    logger.info('Iniciando proceso de añadir al carrito');
    
    try {
      logger.debug('Esperando productos');
      await this.waitForResults();
      
      logger.debug('Haciendo hover en primer producto');
      await this.hoverFirstProduct();
      
      logger.debug('Haciendo clic en botón añadir');
      await this.clickAddButton();
      
      logger.info('Producto añadido exitosamente');
    } catch (error) {
      logger.error('Error añadiendo producto al carrito', error);
      throw error;
    }
  }
}
```

---

## Debugging de Tests Cucumber

### Configuraciones Disponibles (.vscode/launch.json)

El proyecto incluye **4 configuraciones de debugging**:

1. **🥒 Debug Cucumber - Current Feature**: Debuggea el feature abierto actualmente
2. **🥒 Debug Cucumber - Specific Tag**: Debuggea escenarios con un tag específico
3. **🎭 Debug Playwright Inspector**: Usa Playwright Inspector para debugging visual
4. **🥒 Debug All Features**: Debuggea todos los features (sin paralelización)

---

## Debugging Paso a Paso

### 1. Debug del Feature Actual (Más Común)

```
1. Abre el archivo .feature que quieres debuggear
2. Pon breakpoints en tus step definitions (.ts en src/steps/)
3. Presiona F5 o Run > Start Debugging
4. Selecciona: "🥒 Debug Cucumber - Current Feature"
5. El navegador se abrirá visible (HEADLESS=false)
6. La ejecución se detendrá en tus breakpoints
```

### 2. Debug por Tag Específico

```
1. Edita .vscode/launch.json y cambia el tag:
   "--tags", "@KAN-1212"
2. Pon breakpoints en tus steps
3. Presiona F5 > Selecciona "🥒 Debug Cucumber - Specific Tag"
4. Solo se ejecutarán escenarios con ese tag
```

### 3. Debug con Playwright Inspector (Visual)

```
1. Presiona F5 > Selecciona "🎭 Debug Playwright Inspector"
2. Se abre Playwright Inspector con:
   - Selector picker (inspeccionar elementos)
   - Step-by-step controls
   - Console para ejecutar comandos
   - Screenshot viewer
3. Puedes pausar, avanzar paso a paso, y explorar el DOM
```

### 4. Debug desde Terminal

```powershell
# Con Playwright Inspector
$env:PWDEBUG=1; npm test -- features/cart/add-product-from-plp.feature

# Con navegador visible (sin inspector)
$env:HEADLESS="false"; npm test -- --tags "@KAN-1212"

# Con más logging
$env:DEBUG="pw:api"; npm test -- features/cart/add-product-from-plp.feature
```

---

## Breakpoints Estratégicos

### En Step Definitions

```typescript
// ✅ CORRECTO - Breakpoints en lugares clave
When('el usuario busca {string}', async function (searchTerm: string) {
  logger.info(`Buscando: ${searchTerm}`);
  
  const homePage = PageFactory.getHomePage(this, this.page);
  
  // 🔴 BREAKPOINT AQUÍ para inspeccionar antes de la acción
  await homePage.search(searchTerm);
  
  // 🔴 BREAKPOINT AQUÍ para verificar después de la acción
  logger.info('Búsqueda completada');
});
```

### En Page Objects

```typescript
// En Page Objects
async search(term: string): Promise<void> {
  logger.info(`Ejecutando búsqueda: ${term}`);
  
  // 🔴 BREAKPOINT AQUÍ para ver selectores
  await this.page.fill(this.selectors.searchInput, term);
  
  // 🔴 BREAKPOINT AQUÍ para verificar navegación
  await this.page.click(this.selectors.searchButton);
  
  await this.waitForNavigation();
}
```

---

## Debugging Avanzado con Playwright

### Pausar Ejecución

```typescript
// Pausa con Playwright Inspector
await this.page.pause(); // Abre inspector interactivo
```

### Inspeccionar Elementos en Runtime

```typescript
const element = await this.page.locator('[data-testid="product"]');

// Información del elemento
console.log('Element count:', await element.count());
console.log('Is visible:', await element.isVisible());
console.log('Text content:', await element.textContent());

// Atributos del elemento
const attributes = await element.evaluate((el) => ({
  id: el.id,
  class: el.className,
  text: el.textContent,
  visible: el.offsetParent !== null,
}));
console.log('Atributos:', attributes);
```

### Screenshots en Punto Específico

```typescript
// Capturar screenshot para debugging
await this.page.screenshot({ path: 'debug-screenshot.png' });

// Screenshot de elemento específico
await this.page.locator('[data-testid="product"]').screenshot({ 
  path: 'product-screenshot.png' 
});
```

### Evaluar JavaScript en Browser

```typescript
// Evaluar código en el contexto del navegador
const resultado = await this.page.evaluate(() => {
  return {
    title: document.title,
    url: window.location.href,
    cookiesCount: document.cookie.split(';').length,
    localStorage: Object.keys(localStorage).length,
  };
});
console.log('Estado del navegador:', resultado);
```

---

## Tips de Debugging

### 1. Usa page.pause() para Inspección Interactiva

```typescript
// En cualquier punto del test
await this.page.pause(); // Abre Playwright Inspector
// Puedes:
// - Inspeccionar DOM
// - Probar selectores
// - Ver console logs
// - Tomar screenshots
// - Continuar paso a paso
```

### 2. Logging Condicional

```typescript
if (process.env.DEBUG_MODE === 'true') {
  logger.debug('Selectores encontrados:', await this.page.locator('button').count());
  logger.debug('URL actual:', this.page.url());
  logger.debug('Title:', await this.page.title());
}
```

### 3. Screenshots Automáticos en Fallos

```typescript
// src/support/hooks.ts (ya configurado)
After(async function (scenario) {
  if (scenario.result?.status === 'failed') {
    const screenshot = await this.page.screenshot();
    this.attach(screenshot, 'image/png');
    logger.error(`Scenario falló: ${scenario.pickle.name}`);
  }
});
```

### 4. Traces para Análisis Post-Mortem

```typescript
// playwright.config.ts (ya configurado)
use: {
  trace: 'retain-on-failure', // Genera trace solo en fallos
}

// Ver trace después de ejecución:
// npx playwright show-trace trace.zip
```

### 5. Debugging de Selectores

```typescript
// Verifica si selector existe
const exists = await this.page.locator('[data-testid="product"]').count() > 0;
logger.debug(`Selector exists: ${exists}`);

// Lista todos los selectores similares
const all = await this.page.locator('[data-testid]').all();
logger.debug(`Total testid elements: ${all.length}`);

// Muestra texto de todos los elementos
const texts = await this.page.locator('[data-testid="product-title"]').allTextContents();
logger.debug('Todos los títulos:', texts);
```

---

## Console Logs del Browser

### Capturar Console Logs

```typescript
// En hooks o setup
Before(async function () {
  this.page.on('console', (msg) => {
    const type = msg.type();
    const text = msg.text();
    
    if (type === 'error') {
      logger.error(`Browser console error: ${text}`);
    } else if (type === 'warning') {
      logger.warn(`Browser console warning: ${text}`);
    } else {
      logger.debug(`Browser console [${type}]: ${text}`);
    }
  });
});
```

---

## Network Debugging

### Monitorear Requests

```typescript
// Capturar todas las requests
this.page.on('request', (request) => {
  logger.debug(`Request: ${request.method()} ${request.url()}`);
});

// Capturar responses
this.page.on('response', (response) => {
  if (!response.ok()) {
    logger.warn(`Response failed: ${response.status()} ${response.url()}`);
  }
});

// Esperar request específica
await this.page.waitForRequest(
  (request) => request.url().includes('/api/products')
);

// Esperar response específica
const response = await this.page.waitForResponse(
  (response) => response.url().includes('/api/products') && response.ok()
);
const data = await response.json();
logger.debug('API Response:', data);
```

---

## Debugging de Timeouts

### Identificar Timeouts

```typescript
try {
  await this.page.waitForSelector('[data-testid="product"]', { 
    timeout: TIMEOUTS.LONG 
  });
} catch (error) {
  // Debugging: ¿Qué selectores SÍ existen?
  const allElements = await this.page.locator('*').count();
  logger.error(`Timeout esperando selector. Total elementos en página: ${allElements}`);
  
  // Listar selectores similares
  const similar = await this.page.locator('[data-testid]').all();
  logger.error(`Selectores con data-testid encontrados: ${similar.length}`);
  
  // Screenshot del estado actual
  await this.page.screenshot({ path: 'timeout-debug.png' });
  
  throw error;
}
```

---

## Debugging de Assertions

### Assertions con Mensajes Claros

```typescript
// ✅ CORRECTO - Mensaje descriptivo
Then('debería haber productos', async function () {
  const plp = PageFactory.getProductListPage(this, this.page);
  const count = await plp.getProductCount();
  
  expect(count, `Se esperaban productos pero se encontraron ${count}`).toBeGreaterThan(0);
});

// Debugging extra si falla
if (count === 0) {
  const url = this.page.url();
  logger.error(`No hay productos. URL actual: ${url}`);
  await this.page.screenshot({ path: 'no-products.png' });
}
```

---

## Debugging de Hooks

### Logging en Hooks

```typescript
// src/support/hooks.ts
Before(async function (scenario) {
  logger.info(`▶️ Iniciando: ${scenario.pickle.name}`);
  logger.debug(`Tags: ${scenario.pickle.tags.map(t => t.name).join(', ')}`);
});

After(async function (scenario) {
  const status = scenario.result?.status;
  const duration = scenario.result?.duration || 0;
  
  logger.info(`${status === 'passed' ? '✅' : '❌'} Finalizado: ${scenario.pickle.name} (${duration}ms)`);
  
  if (status === 'failed') {
    logger.error(`Error: ${scenario.result?.message}`);
    
    // Screenshot del fallo
    const screenshot = await this.page.screenshot();
    this.attach(screenshot, 'image/png');
  }
});
```

---

## Herramientas de Debugging

### Playwright Inspector

```bash
# Abrir inspector para un test específico
$env:PWDEBUG=1; npm test -- features/cart/add-product-from-plp.feature
```

**Características**:
- 🔍 Selector picker interactivo
- ⏯️ Controles step-by-step
- 📷 Screenshots en cada paso
- 🖥️ Console para ejecutar código

### Playwright Trace Viewer

```bash
# Ver trace de ejecución fallida
npx playwright show-trace test-results/trace.zip
```

**Características**:
- 📊 Timeline de ejecución
- 📸 Screenshots en cada acción
- 🌐 Network requests
- 📝 Console logs
- 🎯 Selectores usados

### VS Code Debugger

```json
// .vscode/launch.json (ya configurado)
{
  "type": "node",
  "request": "launch",
  "name": "🥒 Debug Cucumber - Current Feature",
  "program": "${workspaceFolder}/node_modules/@cucumber/cucumber/bin/cucumber.js",
  "args": ["${file}"],
  "env": {
    "HEADLESS": "false"
  }
}
```

---

## Checklist de Debugging

### Cuando un test falla

1. ✅ **Revisa el error message**: ¿Qué dice exactamente?
2. ✅ **Revisa screenshots**: ¿Qué se ve en la página?
3. ✅ **Revisa logs**: ¿Qué pasos se ejecutaron?
4. ✅ **Revisa selectores**: ¿Existen en el DOM?
5. ✅ **Revisa timeouts**: ¿Es suficiente tiempo?
6. ✅ **Reproduce manualmente**: ¿Funciona en browser normal?
7. ✅ **Ejecuta con PWDEBUG=1**: Debugging interactivo
8. ✅ **Revisa network**: ¿Falló alguna API call?

---

## Referencias

- **Playwright Debugging**: [Playwright Debug Guide](https://playwright.dev/docs/debug)
- **Playwright Inspector**: [Inspector Docs](https://playwright.dev/docs/inspector)
- **Trace Viewer**: [Trace Viewer Guide](https://playwright.dev/docs/trace-viewer)

---

**📌 Recuerda**: Un buen sistema de logging y debugging ahorra horas de investigación. Invierte en logs claros y herramientas de debugging.
