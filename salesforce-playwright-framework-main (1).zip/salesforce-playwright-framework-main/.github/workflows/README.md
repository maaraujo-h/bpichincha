# Configuración de GitHub Actions

Esta carpeta contiene los workflows de CI/CD para el proyecto.

## 🚀 Workflows Disponibles

### `e2e-tests.yml`

Ejecuta las pruebas E2E en cada push o pull request.

**Triggers:**

- Push a `main` o `develop`
- Pull Requests hacia `main`
- Ejecución manual desde GitHub Actions

**Pasos:**

1. Checkout del código
2. Instalación de Node.js y dependencias
3. Instalación de navegadores de Playwright
4. Ejecución de tests
5. Carga de reportes y artefactos

### `copilot-setup-steps.yml`

Verifica que el entorno para Copilot + Playwright Agents está listo.

**Pasos:**

1. Checkout del código
2. Instalación de Node.js y dependencias
3. Instalación de navegador Chromium de Playwright
4. Verificación del servidor MCP de Playwright Test
5. Type-check del proyecto
6. Build opcional (si existe script `build`)

## 🔐 Secrets Requeridos

Configura estos secrets en GitHub (Settings → Secrets → Actions):

| Secret | Descripción | Requerido |
|--------|-------------|-----------|

| `SALESFORCE_USERNAME` | Usuario de servicio de Salesforce para automatización | Sí |
| `SALESFORCE_PASSWORD` | Contraseña del usuario de servicio | Sí |
| `XRAY_CLIENT_ID` | Client ID de una API Key de Xray Cloud (Jira) | No — habilita la importación automática de resultados a Xray |
| `XRAY_CLIENT_SECRET` | Client Secret de la misma API Key de Xray Cloud | No — habilita la importación automática de resultados a Xray |

### Cómo añadir secrets

1. Ve a tu repositorio en GitHub
2. Settings → Secrets and variables → Actions
3. Click en "New repository secret"
4. Añade cada secret con su valor

### Trazabilidad Jira/Xray

- Los escenarios `.feature` se etiquetan manualmente con el ID del ticket/test de Jira
  (ej. `@KAN-1212`) para trazabilidad documental.
- Si configuras `XRAY_CLIENT_ID`/`XRAY_CLIENT_SECRET` (API Key de Xray Cloud), el job
  `test` del workflow `e2e-tests.yml` importa automáticamente `cucumber-report.json`
  como una Test Execution en Xray al finalizar cada ejecución (ver el paso
  "Import results to Xray Cloud (Jira)"). Si los secrets no están definidos, este
  paso se omite automáticamente sin romper el pipeline.
- Antes de que la importación sea totalmente efectiva, los `Scenario` del `.feature`
  deben corresponder a un Test existente en Xray (por convención, usando el tag
  `@KAN-1212` como clave del Test en Xray).

## 📊 Artefactos Generados

Después de cada ejecución, se generan:

- **Test Results**: Reportes de Cucumber (HTML, JSON, XML)
- **Playwright Report**: Reporte visual de Playwright
- **Screenshots**: Solo en fallos (30 días de retención)
- **Videos**: Solo en fallos (7 días de retención)
- **Traces**: Solo en fallos (7 días de retención)

## 🔧 Personalización

### Ejecutar en múltiples navegadores

Edita la matriz en `e2e-tests.yml`:

```yaml
strategy:
  matrix:
    browser: [chromium, firefox, webkit]
```

### Cambiar Node.js version

```yaml
- name: Setup Node.js
  uses: actions/setup-node@v4
  with:
    node-version: '20'  # Cambiar aquí
```

### Ejecutar solo tests con tag específico

```yaml
- name: Run E2E Tests
  run: npm test -- --tags "@smoke"
```

## 🎯 Ejecución Manual

Para ejecutar manualmente:

1. Ve a Actions en GitHub
2. Selecciona "E2E Tests - Playwright BDD"
3. Click en "Run workflow"
4. Selecciona la rama
5. Click en "Run workflow"

## 📈 Ver Resultados

Los resultados se publican automáticamente como:

- ✅ Checks en Pull Requests
- 📊 Comentarios con resumen de tests
- 📁 Artefactos descargables

## 🐛 Troubleshooting

### Tests fallan en CI pero funcionan localmente

- Verificar variables de entorno
- Verificar secrets de GitHub
- Revisar logs detallados en Actions

### Timeout en instalación de dependencias

Aumentar el timeout:

```yaml
jobs:
  test:
    timeout-minutes: 90  # Aumentar aquí
```

### No se generan artefactos

Verificar que los paths existen:

```yaml
path: |
  cucumber-report/  # Debe existir después de tests
  screenshots/      # Se crea si hay fallos
```

---

**Última actualización**: Noviembre 2025
