﻿# GitHub Copilot Instructions - Playwright BDD POM Template

---

## applyTo: "\*\*" # Se aplica a todos los archivos del proyecto

Este proyecto sigue un estándar de excelencia en automatización de pruebas E2E. Todas las contribuciones y código generado deben adherirse estrictamente a estas directrices.

## Estructura de Documentación

La documentación de GitHub Copilot está organizada en **módulos especializados** para facilitar el mantenimiento y la carga contextual. Cada módulo tiene un ámbito de aplicación específico definido con `applyTo`.

Nota: Este proyecto estandariza el uso del inglés para los archivos de características Gherkin y archivos de código en typescript. Todos los nuevos archivos o los archivos actualizados deben usar `# language: en` y pasos en inglés.

### [Model Context Protocols (MCPs)](./copilot/mcps.md)

**Aplica a**: `.vscode/mcp.json`, `src/pages/**/*.ts`, `features/**/*.feature`, `scripts/**/*.ts`  
**Cuándo consultar**: Cuando trabajes con:

- Integración de Jira (leer tickets, crear issues)
- Análisis de páginas web reales con Playwright
- Generación de selectores desde DOM real
- Debugging asistido con MCP de Playwright
- Validación de selectores contra sitios en producción
- Workflow completo: Ticket Jira Feature Steps Page Object
- Troubleshooting de MCPs

### [Arquitectura del Proyecto](./copilot/architecture.md)

**Aplica a**: `**/*` (toda la estructura del proyecto), `docs/**/*.md`  
**Cuándo consultar**: Cuando trabajes con:

- Estructura de directorios del proyecto
- Patrones de diseño (POM, Factory, Template Method)
- Principios SOLID aplicados al proyecto
- Organización de features, pages, steps
- Separación de responsabilidades (Features/Steps/Pages/Utils)
- Single Responsibility Principle (SRP)
- Factory Pattern para Page Objects

### [Cucumber BDD y Gherkin](./copilot/gherkin-bdd.md)

**Aplica a**: `features/**/*.feature`, `cucumber.js`  
**Cuándo consultar**: Cuando trabajes con:

- Archivos `.feature` (Gherkin)
- Organización de escenarios
- Creación de nuevos features
- Uso de tags y Background
- Scenario Outline vs escenarios duplicados
- Organización por dominio funcional (NO por ticket ID)
- Estructura de features (Given-When-Then)
- Tags estratégicos (@smoke, @critical, @KAN-1212X)
- Lenguaje declarativo vs imperativo

### [Page Object Model (POM)](./copilot/page-objects.md)

**Aplica a**: `src/pages/**/*.ts`, `src/utils/page-factory.ts`  
**Cuándo consultar**: Cuando trabajes con:

- Archivos en `src/pages/`
- Creación de nuevos Page Objects
- Modificación de Page Objects existentes
- Interacción con elementos del DOM
- Herencia de BasePage
- Centralización de selectores
- Organización de métodos (navegación, espera, acción, verificación, datos)
- Factory Pattern (PageFactory)
- JSDoc y documentación

### [Step Definitions](./copilot/step-definitions.md)

**Aplica a**: `src/steps/**/*.ts`, `src/support/hooks.ts`  
**Cuándo consultar**: Cuando trabajes con:

- Archivos en `src/steps/`
- Implementación de steps de Gherkin
- Conexión entre Features y Page Objects
- Assertions de tests
- Organización por funcionalidad (NO por ticket ID)
- Evitar duplicación de steps (CRÍTICO)
- Logging sin referencias a tickets
- Uso de PageFactory
- Parámetros tipados ({int}, {string})

### [Selectores Robustos](./copilot/selectors.md)

**Aplica a**: `src/pages/**/*.ts`, `src/steps/**/*.ts`  
**Cuándo consultar**: Cuando trabajes con:

- Localización de elementos en el DOM
- Depuración de selectores fallidos
- Mejora de estabilidad de tests
- Validación de selectores con MCP
- Jerarquía de selectores: `data-testid` > `getByRole` > `getByText` > CSS
- Estrategias de fallback
- Selectores frágiles a evitar
- Uso de regex para flexibilidad

### [TypeScript Best Practices](./copilot/typescript.md)

**Aplica a**: `src/**/*.ts`, `*.ts` (archivos TypeScript del proyecto)  
**Cuándo consultar**: Cuando trabajes con:

- Cualquier archivo `.ts`
- Definición de interfaces y types
- Manejo de errores
- Tipado estricto
- Configuración strict de TypeScript
- Interfaces vs Types
- Async/await (NO mezclar con .then())
- Null safety y optional chaining
- JSDoc para documentación

### [Performance y Timeouts](./copilot/performance.md)

**Aplica a**: `src/**/*.ts`, `playwright.config.ts`, `cucumber.js`  
**Cuándo consultar**: Cuando trabajes con:

- Tests lentos o con timeouts
- Configuración de esperas
- Optimización de navegación
- Paralelización de tests
- TIMEOUTS.SHORT/MEDIUM/LONG/NAVIGATION
- waitUntil: commit vs domcontentloaded vs networkidle
- Auto-waiting de Playwright
- Optimizaciones de navegación

### [Debugging y Logging](./copilot/debugging.md)

**Aplica a**: `src/**/*.ts`, `.vscode/launch.json`, `src/utils/logger.ts`  
**Cuándo consultar**: Cuando trabajes con:

- Tests fallidos
- Depuración de selectores
- Configuración de debugging en VS Code
- Análisis de screenshots y traces
- 4 configuraciones de debugging (.vscode/launch.json)
- Debugging paso a paso con VS Code
- Playwright Inspector usage
- Logging estratégico (sin IDs de tickets)
- Screenshots automáticos en fallos

### [Testing Best Practices](./copilot/testing.md)

**Aplica a**: `features/**/*.feature`, `src/steps/**/*.ts`, `cucumber.js`, `playwright.config.ts`  
**Cuándo consultar**: Cuando trabajes con:

- Ejecución de tests
- CI/CD y pipelines
- Tests flaky o inestables
- Cross-browser testing
- Tests independientes (limpian su estado)
- Datos de prueba centralizados (TEST_DATA)
- Parallel execution
- CI/CD integration (GitHub Actions)
- Métricas de calidad

### [Checklists y Referencias](./copilot/checklists.md)

**Aplica a**: `**/*` (pre-commit review para todos los archivos)  
**Cuándo consultar**: Cuando trabajes con:

- Pre-commit review
- Pull Request creation
- Code review
- Documentación del proyecto
- Checklist pre-commit completo
- Checklists por tipo de archivo (Feature, Page Object, Steps, etc.)
- Comandos útiles
- Referencias a documentación externa

---

## Reglas Globales

Estas reglas se aplican **SIEMPRE**, independientemente del contexto:

### 1. **Organización por Funcionalidad, NO por Ticket**

```
 CORRECTO:
features/cart/add-product-from-plp.feature
src/steps/cart.steps.ts
src/pages/CartPage.ts

 INCORRECTO:
features/KAN-1212.feature
src/steps/KAN-1212.steps.ts
```

**Razón**: Los tickets cambian, las funcionalidades permanecen. El código debe ser reutilizable.

### 2. **NUNCA Duplicar Steps**

Antes de crear un nuevo step:

1. Busca en **TODOS** los archivos de steps existentes
2. Si existe uno similar, reutilízalo
3. Si necesitas uno nuevo, hazlo genérico para futuro reuso

```typescript
//  CORRECTO - Step genérico reutilizable
When('el usuario busca {string}', async function (term: string) { ... });

//  INCORRECTO - Step específico de un ticket
When('el usuario ejecuta búsqueda de KAN-1212', async function () { ... });
```

### 3. **Logging sin IDs de Tickets**

```typescript
//  CORRECTO
logger.info("Añadiendo producto al carrito");

//  INCORRECTO
logger.info("KAN-1212: Añadiendo producto al carrito");
```

**Razón**: Los steps son código compartido. Un mismo step puede ser usado por múltiples tickets.

### 4. **Selectores Robustos - Jerarquía de Preferencia**

1. `[data-testid="element"]` - Más robusto
2. `getByRole('button', { name: 'Click' })` - Accesibilidad nativa
3. `getByText('Search')` - Para contenido estático
4. `.specific-class` - Con clases estables
5. `xpath` - ÚLTIMO RECURSO (evitar)

### 5. **Timeouts Apropiados**

```typescript
import { TIMEOUTS } from "../utils/constants";

{
  timeout: TIMEOUTS.SHORT;
} // 3s - Operaciones rápidas
{
  timeout: TIMEOUTS.MEDIUM;
} // 10s - Operaciones normales
{
  timeout: TIMEOUTS.LONG;
} // 25s - Operaciones complejas
{
  timeout: TIMEOUTS.NAVIGATION;
} // 30s - Navegación
```

### 6. **Page Objects Retornan Datos, NO Hacen Assertions**

```typescript
//  CORRECTO - Page Object retorna dato
async getProductCount(): Promise<number> {
  return await this.page.locator('[data-testid="product"]').count();
}

//  INCORRECTO - Page Object hace assertion
async verifyProductCount(expected: number): Promise<void> {
  expect(await this.getProductCount()).toBe(expected); // ¡NO!
}
```

**Assertions siempre en Steps**, nunca en Page Objects.

### 7. **TypeScript Estricto**

- NO usar `any` (usar tipos específicos)
- Return types explícitos en funciones
- Parámetros tipados
- Null safety con optional chaining (`?.`)

```typescript
//  CORRECTO
async getTitle(): Promise<string | null> {
  return await this.page.locator('h1').textContent();
}

//  INCORRECTO
async getTitle(): Promise<any> { // ¡NO usar any!
  return await this.page.locator('h1').textContent();
}
```

### 8. **Uso de MCPs para Verificación**

Cuando sea posible:

- **MCP de Playwright**: Verifica selectores contra páginas reales
- **MCP de Atlassian**: Lee tickets de Jira antes de implementar

```
 Prompt para Copilot:
"Usando MCP de Playwright, navega a [URL] y genera Page Object
con selectores verificados contra el DOM real"

"Lee el ticket KAN-1212 desde Jira y genera implementación completa"
```

---

## Quick Start para Nuevas Implementaciones

### Workflow Recomendado:

1. **Leer Ticket de Jira** (si aplica)

   ```
   "Lee el ticket KAN-1212X desde Jira usando MCP de Atlassian"
   ```

2. **Crear/Actualizar Feature File**
   - Consultar: [gherkin-bdd.md](./copilot/gherkin-bdd.md)
   - Ubicación: `features/[dominio]/[funcionalidad].feature`
   - Usar Scenario Outline si hay casos similares

3. **Crear/Actualizar Page Object**
   - Consultar: [page-objects.md](./copilot/page-objects.md)
   - Verificar selectores con MCP de Playwright
   - Ubicación: `src/pages/[NombrePage].ts`

4. **Implementar Steps**
   - Consultar: [step-definitions.md](./copilot/step-definitions.md)
   - **BUSCAR STEPS EXISTENTES PRIMERO**
   - Ubicación: `src/steps/[funcionalidad].steps.ts`

5. **Ejecutar Tests**

   ```powershell
   npm test -- --tags "@KAN-1212X"
   ```

6. **Debug si es necesario**
   - Consultar: [debugging.md](./copilot/debugging.md)
   - F5 > " Debug Cucumber - Specific Tag"

7. **Verificar Checklist**
   - Consultar: [checklists.md](./copilot/checklists.md)

---

## Comandos Útiles

```powershell
# Ejecutar tests
npm test                                    # Todos los tests
npm test -- --tags "@smoke"                 # Solo smoke tests
npm test -- --tags "@KAN-1212"              # Test específico
npm test -- features/cart/*.feature         # Feature específico

# Debug
$env:HEADLESS="false"; npm test             # Con navegador visible
$env:PWDEBUG=1; npm test                    # Con Playwright Inspector

# Calidad de código
npm run format                              # Formatear código
npm run lint                                # Lint
```

---

## Referencias Externas

### Documentación Oficial

- [Playwright Best Practices](https://playwright.dev/docs/best-practices) <!-- markdownlint-disable-line MD034 -->
- [Cucumber Best Practices](https://cucumber.io/docs/bdd/better-gherkin/) <!-- markdownlint-disable-line MD034 -->
- [Page Object Model Pattern](https://martinfowler.com/bliki/PageObject.html) <!-- markdownlint-disable-line MD034 -->
- [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html) <!-- markdownlint-disable-line MD034 -->

### Documentación del Proyecto

- `docs/ARCHITECTURE.md` - Arquitectura detallada
- `docs/MCP-WORKFLOW-GUIDE.md` - Guía completa de MCPs
- `docs/DEBUG-TUTORIAL.md` - Tutorial de debugging paso a paso
- `docs/QUICKSTART.md` - Inicio rápido para nuevos desarrolladores

### Ejemplos de Referencia

- Features: `features/search/product-search.feature`, `features/cart/add-product-from-plp.feature`
- Steps: `src/steps/common.steps.ts`, `src/steps/cart.steps.ts`
- Pages: `src/pages/BasePage.ts`, `src/pages/HomePage.ts`
- Utils: `src/utils/constants.ts`, `src/utils/page-factory.ts`, `src/utils/logger.ts`

---

## Principios Fundamentales

1. **DRY (Don't Repeat Yourself)** - Reutiliza steps, centraliza selectores, usa PageFactory
2. **SOLID** - Single Responsibility, Open/Closed, Liskov Substitution, Interface Segregation, Dependency Inversion
3. **Mantenibilidad** - Código autodocumentado, JSDoc completo, nombres descriptivos
4. **Robustez** - Selectores estables, timeouts apropiados, manejo de errores, tests independientes

---

**Última actualización**: 12 de Noviembre de 2025  
**Versión**: 2.0.0 (Modularizado)  
**Mantenedor**: QA Team
