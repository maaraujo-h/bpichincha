/**
 * Configuración de Cucumber para BDD
 */
module.exports = {
  /**
   * Perfil por defecto: lee todas las subcarpetas y obedece a la consola.
   * Uso: npm test (ejecuta todo) o npm test -- --tags "@prospect"
   */
  default: {
    // Archivos de features (el ** busca de forma recursiva en cualquier subcarpeta)
    paths: ['features/**/*.feature', '!features/**/_*.feature'],
    
    // Configuración de steps
    require: ['src/steps/**/*.ts', 'src/support/**/*.ts'],
    
    // Configuración de TypeScript
    requireModule: ['ts-node/register'],
    
    // Formato de salida
    format: [
      'progress-bar',
      'html:cucumber-report/cucumber-report.html',
      'json:cucumber-report/cucumber-report.json',
      'junit:cucumber-report/cucumber-report.xml',
    ],
    
    // Configuración de ejecución paralela
    parallel: 1, 
    
    // Retry en caso de fallo
    retry: 0,
    
    // Timeout para cada step (en milisegundos)
    timeout: 60000, // 60 segundos
    
    // Formato de snippets
    snippetInterface: 'async-await',
  },

  /**
   * Perfil completo: ejecuta todos los escenarios sin filtro de tags.
   * Uso: npm run test:full
   */
  full: {
    paths: ['features/**/*.feature', '!features/**/_*.feature'],
    require: ['src/steps/**/*.ts', 'src/support/**/*.ts'],
    requireModule: ['ts-node/register'],
    format: [
      'progress-bar',
      'html:cucumber-report/cucumber-report.html',
      'json:cucumber-report/cucumber-report.json',
      'junit:cucumber-report/cucumber-report.xml',
    ],
    parallel: 1,
    retry: 0,
    timeout: 60000,
    snippetInterface: 'async-await',
  },
};
