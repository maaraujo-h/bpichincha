import { defineConfig, devices } from '@playwright/test';
import dotenv from 'dotenv';
import { BROWSER_CONFIG } from './src/config/browser.config';
import { RUNTIME_CONFIG } from './src/config/runtime.config';
import { TIMEOUTS } from './src/utils/constants';

dotenv.config();

export default defineConfig({
  testDir: './specs', //testDir: './features',
  timeout: RUNTIME_CONFIG.timeout,
  expect: {
    timeout: TIMEOUTS.MEDIUM,
  },
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : 1,
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'test-results/results.json' }],
  ],
  use: {
    baseURL: RUNTIME_CONFIG.baseURL,
    proxy: RUNTIME_CONFIG.proxy,
    trace: RUNTIME_CONFIG.traceOnFailure ? 'on-first-retry' : 'off',
    screenshot: RUNTIME_CONFIG.screenshotOnFailure ? 'only-on-failure' : 'off',
    video: RUNTIME_CONFIG.videoOnFailure ? 'retain-on-failure' : 'off',
    locale: BROWSER_CONFIG.locale,
    timezoneId: 'Europe/Madrid',
    viewport: BROWSER_CONFIG.viewport,
    navigationTimeout: TIMEOUTS.NAVIGATION,
    actionTimeout: TIMEOUTS.SHORT,
    ignoreHTTPSErrors: true,
  },
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        headless: RUNTIME_CONFIG.headless,
        launchOptions: {
          args: [...BROWSER_CONFIG.launchArgs],
        },
        userAgent: BROWSER_CONFIG.userAgent,
      },
    },
  ],
});
