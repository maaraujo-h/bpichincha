import fs from 'fs';
import path from 'path';
import 'dotenv/config';

/**
 * Interfaz que define la estructura esperada de la respuesta
 * de la API REST de Jira para una incidencia (Issue).
 */
interface AdfNode {
  type: string;
  text?: string;
  content?: AdfNode[];
}

interface JiraIssueResponse {
  fields: {
    summary: string;
    description: AdfNode | null;
  };
}

function adfToText(node: AdfNode | null): string {
  if (!node) return '';
  if (node.type === 'text') return node.text ?? '';
  return (node.content ?? []).map(adfToText).join(node.type === 'paragraph' ? '\n' : '');
}

/**
 * Extrae la información de una Historia de Usuario desde la API de Jira Cloud
 * y la almacena localmente en formato Markdown dentro de la carpeta oculta `.requirements`.
 * @param issueId Identificador clave de la incidencia en Jira (ej. 'KAN-1212')
 * @returns Ruta absoluta del archivo Markdown generado con los requisitos
 */
export async function extractJiraIssue(issueId: string): Promise<string> {
  const domain = process.env.JIRA_DOMAIN;
  const email = process.env.JIRA_EMAIL;
  const token = process.env.JIRA_API_TOKEN;

  if (!domain || !email || !token) throw new Error('Faltan credenciales de Jira en el archivo .env');

  const url = `https://${domain}/rest/api/3/issue/${issueId}`;
  const authHeader = `Basic ${Buffer.from(`${email}:${token}`).toString('base64')}`;

  console.log(`Extrayendo información de ${issueId}...`);

  let response: Response;
  try {
    response = await fetch(url, {
      method: 'GET',
      headers: { 'Authorization': authHeader, 'Accept': 'application/json' }
    });
  } catch (err) {
    throw new Error(`Error de red al conectar con Jira: ${(err as Error).message}`);
  }

  if (!response.ok) throw new Error(`Error en Jira API: ${response.status} ${response.statusText}`);

  let data: JiraIssueResponse;
  try {
    const raw = await response.json();
    if (!raw?.fields) throw new Error('Respuesta inesperada: falta el campo "fields"');
    data = raw as JiraIssueResponse;
  } catch (err) {
    throw new Error(`Error al parsear la respuesta de Jira: ${(err as Error).message}`);
  }

  const descriptionText = adfToText(data.fields.description);

  const markdownContent = `
# Historia de Usuario: ${issueId} - ${data.fields.summary}
## Descripción
${descriptionText || '_Sin descripción_'}
  `;

  const outputDir = path.join(process.cwd(), '.requirements');
  fs.mkdirSync(outputDir, { recursive: true });
  
  const filePath = path.join(outputDir, `${issueId}-requirements.md`);
  fs.writeFileSync(filePath, markdownContent.trim());
  
  console.log(`Requisitos guardados en: ${filePath}`);
  return filePath;
}