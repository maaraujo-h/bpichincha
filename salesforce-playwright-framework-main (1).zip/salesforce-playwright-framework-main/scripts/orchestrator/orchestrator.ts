import * as fs from 'fs';
import * as path from 'path';
import 'dotenv/config';
import Anthropic from '@anthropic-ai/sdk';
import { extractJiraIssue } from './jira-extractor';

if (!process.env.ANTHROPIC_API_KEY) {
  console.error('Error: Falta ANTHROPIC_API_KEY en el archivo .env');
  process.exit(1);
}

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const MODEL_NAME = 'claude-3-5-sonnet-20241022';

async function callAgent(systemPrompt: string, userContent: string): Promise<string> {
  const response = await anthropic.messages.create({
    model: MODEL_NAME,
    max_tokens: 4000,
    system: systemPrompt,
    messages: [{ role: 'user', content: userContent }]
  });

  return response.content[0].type === 'text' ? response.content[0].text : '';
}

async function runPipeline() {
  const args = process.argv.slice(2);
  const inputArg = args.find(arg => !arg.startsWith('--'));
  const isCopilotMode = args.includes('--copilot');

  if (!inputArg) {
    console.error('Error: Debes proporcionar un archivo spec o un ticket de Jira.');
    process.exit(1);
  }

  try {
    let contextFilePath = '';
    const isLocalFile = fs.existsSync(inputArg);

    console.log(`===================================================`);
    if (isLocalFile) {
      contextFilePath = path.resolve(inputArg);
      console.log(`INICIANDO ORQUESTADOR DESDE SPEC LOCAL: ${inputArg}`);
    } else {
      console.log(`INICIANDO ORQUESTADOR DESDE JIRA TICKET: ${inputArg}`);
      contextFilePath = await extractJiraIssue(inputArg);
    }
    console.log(`===================================================\n`);

    // MODO ASISTIDO (Con bandera --copilot): Aplica el freno para el IDE
    if (isCopilotMode) {
      console.log(`[Modo Asistido] Contexto preparado correctamente en:`);
      console.log(`   ${contextFilePath}`);
      console.log(`\nEl orquestador se detiene aquí. Usa este archivo en el chat de tu editor con Copilot/Cursor.`);
      process.exit(0);
    }

    // MODO AUTOMÁTICO (Sin bandera): Ejecuta las fases con la API de Anthropic
    const requirementContent = fs.readFileSync(contextFilePath, 'utf-8');

    // FASE 1: Planificación (Test Planner Agent)
    console.log(`[Fase 1/2] Ejecutando Test Planner Agent...`);
    const plannerAgentPath = path.resolve('.github/agents/playwright-test-planner.agent.md');
    const plannerInstructions = fs.existsSync(plannerAgentPath) 
      ? fs.readFileSync(plannerAgentPath, 'utf-8') 
      : 'Eres un QA Expert. Genera un archivo Gherkin (.feature) limpio y estructurado.';

    let gherkinResult: string;
    try {
      gherkinResult = await callAgent(
        plannerInstructions, 
        `Genera el archivo .feature basándote en este requerimiento:\n\n${requirementContent}`
      );
    } catch (err) {
      throw new Error(`[Fase 1] Fallo en Test Planner Agent: ${(err as Error).message}`);
    }

    const featureDir = path.resolve('features/generated');
    fs.mkdirSync(featureDir, { recursive: true });
    
    const featureSlug = path.basename(inputArg, path.extname(inputArg)).replace(/[^a-zA-Z0-9-_]/g, '-');
    const featureFileName = `${featureSlug}-${Date.now()}.feature`;
    const outputFeaturePath = path.join(featureDir, featureFileName);
    fs.writeFileSync(outputFeaturePath, gherkinResult, 'utf-8');
    console.log(`[Fase 1] Archivo .feature guardado en: ${outputFeaturePath}\n`);

    // FASE 2: Generación de POM y Steps (Test Generator Agent)
    console.log(`[Fase 2/2] Ejecutando Test Generator Agent...`);
    const generatorAgentPath = path.resolve('.github/agents/playwright-test-generator.agent.md');
    const generatorInstructions = fs.existsSync(generatorAgentPath) 
      ? fs.readFileSync(generatorAgentPath, 'utf-8') 
      : 'Eres un Senior Automation Engineer. Genera el código Page Object Model y Step Definitions en TypeScript usando Playwright y Cucumber.';

    let codeResult: string;
    try {
      codeResult = await callAgent(
        generatorInstructions,
        `Basándote en este archivo Gherkin:\n\n${gherkinResult}\n\nGenera el código TypeScript para el Page Object (en src/pages/) y las Step Definitions (en src/steps/) respetando los estándares del framework.`
      );
    } catch (err) {
      throw new Error(`[Fase 2] Fallo en Test Generator Agent: ${(err as Error).message}`);
    }

    const outputCodePath = path.resolve('features/generated/implementation-output.md');
    fs.writeFileSync(outputCodePath, codeResult, 'utf-8');
    console.log(`[Fase 2] Código de implementación guardado en: ${outputCodePath}`);
    console.log(`Pipeline de planificación y generación completado con éxito.`);

  } catch (error) {
    console.error(`\nError crítico en el orquestador:`, error);
    process.exit(1);
  }
}

runPipeline();