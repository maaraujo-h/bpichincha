/**
 * Tipos personalizados para el contexto global de Cucumber.
 */
import { Page, Browser, BrowserContext } from '@playwright/test';
import { LoginFlowPage } from '../pages/loginFlowPage';
import { ClientFilePage } from '../pages/clientFilePage';
import { CommercialFlowPage } from '../pages/commercialFlowPage';
import { QuotationFlowPage } from '../pages/quotationFlowPage';

declare module '@cucumber/cucumber' {
  interface World {
    // Instancias disponibles en cada escenario.
    page: Page;
    browser: Browser;
    context: BrowserContext;

    // Page Objects asignados por PageFactory.
    loginFlowPage?: LoginFlowPage;
    clientFilePage?: ClientFilePage;
    commercialFlowPage?: CommercialFlowPage;
    quotationFlowPage?: QuotationFlowPage;

    // Método auxiliar para adjuntar evidencias al reporte.
    attach: (data: string | Buffer, mediaType: string) => void;
  }
}
