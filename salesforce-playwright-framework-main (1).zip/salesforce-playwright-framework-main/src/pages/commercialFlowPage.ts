import { Locator, Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { TIMEOUTS } from '../utils/constants';
import { logger } from '../utils/logger';

export class CommercialFlowPage extends BasePage {
  // Inicializa el Page Object con la página activa.
  constructor(page: Page) {
    super(page);
  }

  // ──────── Flujo Comercial - Creación de Prospecto ──────────────────
  // Abre el menú principal del flujo comercial.
  async clickCommercialFlowMenu(menuName: string): Promise<void> {
    logger.info(`Clicking on commercial menu: ${menuName}`);
    await this.page.locator('one-appnav, .slds-context-bar').first()
      .waitFor({ state: 'visible', timeout: TIMEOUTS.MEDIUM })
      .catch(() => {});

    const navCandidates = [
      this.page.getByRole('link', { name: new RegExp(menuName, 'i') }).first(),
      this.page.locator(`one-app-nav-bar-item-root a[title="${menuName}"]`).first(),
      this.page.locator(`one-appnav a[data-label*="${menuName}" i]`).first(),
    ];
    await this.clickFirstVisibleLocator(navCandidates, TIMEOUTS.MEDIUM);
    await this.waitForPageLoad();
  }

  // Abre el formulario de creación de prospecto.
  async clickCreateProspectButton(buttonTitle: string): Promise<void> {
    logger.info(`Clicking create prospect button: ${buttonTitle}`);

    const newBtnCandidates = [
      this.page.getByRole('button', { name: new RegExp(buttonTitle, 'i') }).first(),
      this.page.locator(`a.forceActionLink[title="${buttonTitle}"]`).first(),
      this.page.locator('li[data-target-selection-name*="Lead.New"] a').first(),
      this.page.locator('a[title="Nuevo"], button[name="New"]').first()
    ];
    
    // Forzamos el click
    let clicked = false;
    for (const locator of newBtnCandidates) {
      const isVisible = await locator
        .waitFor({ state: 'visible', timeout: 1500 })
        .then(() => true)
        .catch(() => false);
      if (isVisible) {
        await locator.click({ force: true });
        clicked = true;
        break;
      }
    }

    if (!clicked) {
      logger.warn(`Could not cleanly find "${buttonTitle}", trying generic button`);
      await this.page.getByRole('button', { name: /nuevo|new|crear/i }).first().click().catch(() => {});
    }

    await this.waitForPageLoad();

    // Espera de forma activa por el modal (waitFor con timeout propio)
    await this.handleRecordTypeSelection('General');
  }

  // Selecciona el tipo de registro cuando muestra el modal.
  async handleRecordTypeSelection(recordTypeName: string = 'General'): Promise<void> {
    logger.info(`Checking for Record Type modal to select: ${recordTypeName}`);
    const modalContainer = this.page.locator('.forceChangeRecordType');

    try {
      await modalContainer.waitFor({ state: 'visible', timeout: 5000 });
      logger.info(`Record type modal detected. Selecting option: ${recordTypeName}`);
      
      const labelOption = modalContainer.locator('label.slds-radio').filter({ hasText: recordTypeName });
      await labelOption.waitFor({ state: 'visible', timeout: 3000 });
      
      const radioInput = labelOption.locator('input[type="radio"]');
      await radioInput.click({ force: true });

      const nextBtn = modalContainer.locator('.forceChangeRecordTypeFooter').getByRole('button', { name: 'Siguiente' });
      await nextBtn.waitFor({ state: 'visible', timeout: 3000 });
      await nextBtn.click();
      
      // Esperamos al contenedor global del formulario en lugar de un input en específico
      const formContainer = this.page.locator('.actionBody, force-record-edit-form, .slds-modal__container').first();
      await formContainer.waitFor({ state: 'visible', timeout: 10000 });
      logger.info('Transitioned to form successfully.');
    } catch (error) {
      logger.info(`No record type modal detected, proceeding to form...`);
    }
  }

  // Comprueba si el formulario de creación de prospecto está visible.
  async isCreateProspectFormVisible(): Promise<boolean> {
    return this.isAnyLocatorVisible([
      this.page.locator('.slds-modal__container, force-record-edit-form, records-lwc-detail-panel').first(),
      this.page.getByRole('dialog').first(),
    ], TIMEOUTS.SHORT);
  }

  // Selecciona el tipo de identificación del prospecto.
  async selectProspectIdentificationType(idType: string): Promise<void> {
    logger.info(`Selecting identification type: ${idType}`);

    const fieldCandidates = [
      // Selectores nativos
      this.page.locator('button[aria-label*="Tipo de Identificación" i]').first(),
      this.page.locator('lightning-combobox[data-field-name*="Tipo_Identificacion" i] button').first(), // Intenta ajustar el nombre del campo interno si lo sabes
      this.page.locator('button:has-text("Tipo de Identificación")').first(),
      
      // Selectores genéricos por accesibilidad y etiquetas
      this.page.getByRole('combobox', { name: /tipo de identificaci[oó]n/i }).first(),
      this.page.getByLabel(/tipo de identificaci[oó]n/i).first(),
      
      // Selectores estructurales (cuando el Shadow DOM es molesto)
      this.page.locator('lightning-combobox').filter({ hasText: /Tipo de Identificación/i }).locator('button').first(),
      this.page.locator('div').filter({ hasText: /^Tipo de Identificación$/ }).locator('button').first()
    ];

    // Clic en el campo para desplegar las opciones, con espera real del modal
    let clicked = false;
    for (const locator of fieldCandidates) {
      const isVisible = await locator
        .waitFor({ state: 'visible', timeout: 2000 })
        .then(() => true)
        .catch(() => false);
      if (isVisible) {
        await locator.click({ force: true }); // Forzamos el click por si hay un elemento invisible bloqueando
        clicked = true;
        break;
      }
    }

    if (!clicked) {
      throw new Error('No se pudo encontrar ni hacer clic en el campo "Tipo de Identificación". Revisa si el formulario cargó completamente.');
    }

    // Espera activamente a que la lista desplegable renderice la opción
    await this.clickFirstVisibleLocator(this.dropdownOptionCandidates(idType), TIMEOUTS.MEDIUM);
  }

  // Completa la identificación del prospecto.
  async fillProspectIdentification(identification: string): Promise<void> {
    logger.info(`Filling prospect identification: ${identification}`);
    const candidates = [
      this.page.getByLabel(/n[úu]mero de identificaci[oó]n/i),
      this.page.getByRole('textbox', { name: /identificaci[oó]n/i }),
      this.page.locator('input[name="BC_NumeroIdentificacion__c"]')
    ];
    await this.fillFirstVisibleLocator(candidates, identification, TIMEOUTS.MEDIUM);
  }

  // Completa el nombre del prospecto.
  async fillProspectFirstName(firstName: string): Promise<void> {
    logger.info(`Filling first name: ${firstName}`);
    const candidates = [
      this.page.getByLabel(/primer nombre/i),
      this.page.getByRole('textbox', { name: /primer nombre/i }),
      this.page.locator('input[name*="FirstName" i]')
    ];
    await this.fillFirstVisibleLocator(candidates, firstName, TIMEOUTS.MEDIUM);
  }

  // Completa el segundo nombre del prospecto.
  async fillProspectSecondName(secondName: string): Promise<void> {
    logger.info(`Filling second name: ${secondName}`);
    const candidates = [
      this.page.getByLabel(/segundo nombre/i),
      this.page.locator('input[name*="MiddleName" i]')
    ];
    await this.fillFirstVisibleLocator(candidates, secondName, TIMEOUTS.MEDIUM);
  }

  // Completa el primer apellido del prospecto.
  async fillProspectFirstLastName(lastName: string): Promise<void> {
    logger.info(`Filling first last name: ${lastName}`);
    const candidates = [
      this.page.getByLabel(/primer apellido/i),
      this.page.locator('input[name*="LastName" i]')
    ];
    await this.fillFirstVisibleLocator(candidates, lastName, TIMEOUTS.MEDIUM);
  }

  // Completa el segundo apellido del prospecto.
  async fillProspectSecondLastName(secondLastName: string): Promise<void> {
    logger.info(`Filling second last name: ${secondLastName}`);
    const candidates = [
      this.page.getByLabel(/segundo apellido/i),
      this.page.locator('input[name*="SecondLastName" i]')
    ];
    await this.fillFirstVisibleLocator(candidates, secondLastName, TIMEOUTS.MEDIUM);
  }

  // Completa el teléfono del prospecto.
  async fillProspectPhone(phone: string): Promise<void> {
    logger.info(`Filling prospect phone: ${phone}`);
    const candidates = [
      this.page.getByLabel(/tel[ée]fono/i),
      this.page.locator('input[name="Phone"]')
    ];
    await this.fillFirstVisibleLocator(candidates, phone, TIMEOUTS.MEDIUM);
  }

  // Completa el correo electrónico del prospecto.
  async fillProspectEmail(email: string): Promise<void> {
    logger.info(`Filling prospect email: ${email}`);
    const candidates = [
      this.page.getByLabel(/correo/i),
      this.page.locator('input[name="Email"]')
    ];
    await this.fillFirstVisibleLocator(candidates, email, TIMEOUTS.MEDIUM);
  }

  // Selecciona la línea de negocio del prospecto.
  async selectProspectBusinessLine(businessLine: string): Promise<void> {
    logger.info(`Selecting business line: ${businessLine}`);
    const fieldCandidates = [
      this.page.getByRole('combobox', { name: /l[ií]nea de negocio/i }),
      this.page.getByLabel(/l[ií]nea de negocio/i),
    ];
    await this.clickFirstVisibleLocator(fieldCandidates, TIMEOUTS.MEDIUM).catch(() => {});
    await this.clickFirstVisibleLocator(this.dropdownOptionCandidates(businessLine), TIMEOUTS.MEDIUM);
  }

  // Completa el broker o sponsor del prospecto con una opción dinámica.
  async fillProspectBroker(defaultBroker: string = "BANCOS E INSTITUCIONES FINANCIERAS"): Promise<void> {
    logger.info('Filling prospect broker with a random dynamic selection');
    
    // 1. Encontrar el input del Broker
    const candidates = [
      this.page.getByLabel(/broker|sponsor|intermediario/i),
      this.page.getByRole('textbox', { name: /broker|sponsor/i }),
      this.page.locator('input[placeholder*="Broker" i]')
    ];
    
    const inputLocator = await this.getFirstVisibleLocator(candidates, TIMEOUTS.MEDIUM);
    if (!inputLocator) {
      throw new Error('No se encontró el campo Broker / Sponsor visible.');
    }

    // 2. Lista de opciones válidas para alternar de forma aleatoria en cada ejecución
    const availableBrokers = [
      defaultBroker,
      "BANCOS E INSTITUCIONES FINANCIERAS",
      "SOSBROKER",
      "SERVIBROKER S.A.",
      "INTELBROKER S.A."
    ];

    // Seleccionar un broker de forma aleatoria del arreglo
    const randomBroker = availableBrokers[Math.floor(Math.random() * availableBrokers.length)];
    logger.info(`Broker seleccionado aleatoriamente para esta ejecución: "${randomBroker}"`);

    // 3. Escribir el término seleccionado
    await inputLocator.click();
    await inputLocator.fill('');
    await inputLocator.fill(randomBroker);

    // 4. Esperar de forma activa a que se despliegue las coincidencias
    //  y luego intentar seleccionar el resultado
    const items = this.page.locator('div.dropdown ul li, .slds-listbox__item');
    await items.first().waitFor({ state: 'visible', timeout: TIMEOUTS.MEDIUM }).catch(() => {});
    const count = await items.count();

    if (count > 0) {
      const targetItem = items.filter({ hasText: new RegExp(randomBroker.substring(0, 3), 'i') }).first();
      if (await targetItem.isVisible().catch(() => false)) {
        await targetItem.click({ force: true });
      } else {
        await items.first().click({ force: true });
      }
      logger.info(`Broker "${randomBroker}" seleccionado de la lista con éxito.`);
    } else {
      await inputLocator.press('Enter');
      logger.warn(`No se desplegó lista visual, se presionó Enter para el valor "${randomBroker}".`);
    }
  }

  // Completa la prima estimada del prospecto.
  async fillProspectEstimatedPremium(premium: string): Promise<void> {
    logger.info(`Filling estimated premium: ${premium}`);
    const candidates = [
      this.page.getByLabel(/prima estimada|prima/i),
      this.page.getByRole('textbox', { name: /prima/i }),
      this.page.locator('input[name*="prima" i]')
    ];
    await this.fillFirstVisibleLocator(candidates, premium, TIMEOUTS.MEDIUM);
  }

  // Completa los días de vigencia del prospecto.
  async fillProspectValidityDays(days: string): Promise<void> {
    logger.info(`Filling validity days: ${days}`);
    const candidates = [
      this.page.getByLabel(/d[ií]as de vigencia|vigencia/i),
      this.page.getByRole('textbox', { name: /vigencia/i }),
      this.page.locator('input[name*="vigencia" i]')
    ];
    await this.fillFirstVisibleLocator(candidates, days, TIMEOUTS.MEDIUM);
  }

  // Selecciona un ramo y lo mueve al listado de seleccionados.
  async selectRandomBranchAndMoveToSelected(defaultBranch: string = "FIDELIDAD"): Promise<void> {
    logger.info(`Selecting branch and moving to selected (with random option support)`);

    // 1. Lista de opciones de ramos disponibles
    const availableBranches = [
      defaultBranch,
      "VIDA COLECTIVO",
      "ACCIDENTES PERSONALES",
      "INCENDIO Y LINEAS ALIADAS",
      "TRANSPORTE",
      "ROBO",
      "EQUIPO ELECTRONICO",
      "ROTURA DE MAQUINARIA",
      "RESPONSABILIDAD CIVIL",
      "RIESGOS ESPECIALES",
      "VIDA INDIVIDUAL",
      "TODO RIESGO PARA CONTRATISTAS",
      "FIDELIDAD",
      "MULTI RIESGO",
      "ASISTENCIA MEDICA"
    ];

    // Seleccionar un ramo al azar en cada ejecución
    const randomBranch = availableBranches[Math.floor(Math.random() * availableBranches.length)];
    logger.info(`Ramo seleccionado aleatoriamente para esta ejecución: "${randomBranch}"`);

    // PASO 2: Buscar y hacer clic en la opción dentro de la lista de "Opciones"
    const branchCandidates = [
      this.page.getByRole('option', { name: randomBranch, exact: true }).first(),
      this.page.locator(`[role="listbox"] [role="option"]:has-text("${randomBranch}")`).first(),
      this.page.locator(`li:has-text("${randomBranch}")`).first(),
      this.page.getByText(randomBranch, { exact: true }).first()
    ];

    let optionClicked = false;
    for (const locator of branchCandidates) {
      const isVisible = await locator
        .waitFor({ state: 'visible', timeout: 2000 })
        .then(() => true)
        .catch(() => false);
      if (isVisible) {
        await locator.scrollIntoViewIfNeeded();
        await locator.click({ force: true });
        optionClicked = true;
        break;
      }
    }

    if (!optionClicked) {
      logger.warn(`Could not find branch option "${randomBranch}" to click.`);
    }

    // PASO 3: Hacer clic en el botón de la flecha hacia la derecha
    const moveRightBtnCandidates = [
      this.page.locator('button[title*="Mover selección a Seleccionado" i]').first(),
      this.page.locator('button[title*="Mover selección a Elegidos" i]').first(),
      this.page.locator('button[title*="Move selection to Chosen" i]').first(),
      this.page.locator('lightning-dual-listbox button').first()
    ];

    await this.clickFirstVisibleLocator(moveRightBtnCandidates, TIMEOUTS.SHORT).catch(() => {
      logger.warn('Right arrow button not found or could not be clicked.');
    });
  }

  // Guarda el prospecto usando el botón visible.
  async saveRecord(buttonName: string): Promise<void> {
    logger.info(`Saving prospect with button: ${buttonName}`);
    const candidates = [
      this.page.getByRole('button', { name: new RegExp(`^${buttonName}$`, 'i') }).first(),
      this.page.locator('records-form-footer button[name="SaveEdit"]').first(),
      this.page.locator('.slds-modal__footer button.slds-button_brand').first()
    ];
    await this.clickFirstVisibleLocator(candidates, TIMEOUTS.MEDIUM);
    await this.waitForPageLoad();
  }

  // Verifica si el prospecto se creó correctamente.
  async isProspectCreatedSuccessfully(): Promise<boolean> {
    logger.info('Verifying if prospect was created successfully');

    // 1. Interceptar activamente cualquier error o validación
    const errorToast = this.page.locator('.slds-notify_toast.slds-theme_error, .slds-notify_toast.slds-theme_warning, .toastMessage, .fieldLevelError, .pageLevelErrors').first();

    const hasErrorToast = await errorToast
      .waitFor({ state: 'visible', timeout: 3000 })
      .then(() => true)
      .catch(() => false);
    if (hasErrorToast) {
      const errorMsg = await errorToast.textContent();
      throw new Error(`Salesforce bloqueó el guardado por validación: ${errorMsg?.trim()}`);
    }

    // 2. Buscar indicadores visuales de éxito en la interfaz
    return this.isAnyLocatorVisible([
      this.page.getByText(/prospecto creado|registrado correctamente|éxito/i),
      this.page.locator('force-toast .slds-notify_toast.slds-theme_success').first(),
    ], TIMEOUTS.LONG);
  }

  // Verifica si se redirigió a la ficha del prospecto creado.
  async isRedirectedToCreatedProspectScreen(): Promise<boolean> {
    logger.info('Verifying automatic redirection to the created prospect screen');
    
    // 1. Interceptar errores primero por si acaso
    const errorToast = this.page.locator('.slds-notify_toast.slds-theme_error, .slds-notify_toast.slds-theme_warning, .toastMessage').filter({ hasText: /Advertencia|Error/i }).first();
    const hasErrorToast = await errorToast
      .waitFor({ state: 'visible', timeout: 3000 })
      .then(() => true)
      .catch(() => false);
    if (hasErrorToast) {
      const errorMsg = await errorToast.textContent();
      throw new Error(`Salesforce bloqueó el guardado: ${errorMsg?.trim()}`);
    }
    
    // 2. Espera dinámica real por redirección
    await this.page.waitForURL(
      (url) => url.toString().includes('/lightning/r/'),
      { timeout: TIMEOUTS.LONG }
    ).catch(() => {});

    // 3. Validar con más flexibilidad en la URL y los textos de la UI de Prospectos/Leads
    const url = this.page.url();
    const isCorrectUrl = url.includes('/lightning/r/Lead/') || url.includes('/lightning/r/Account/') || url.includes('/lightning/r/');

    const isUIReady = await this.isAnyLocatorVisible([
      this.page.locator('.slds-page-header__title, records-record-layout-block').first(),
      this.page.getByText(/Detalles del Prospecto|Prospecto|Lead|Detalles|Details/i).first(),
      this.page.locator('records-entity-label[slot="entityLabel"]').first(),
    ], TIMEOUTS.MEDIUM);

    return isCorrectUrl || isUIReady;
  }

  // Devuelve las opciones posibles para seleccionar una entrada del desplegable.
  private dropdownOptionCandidates(value: string): Locator[] {
    return [
      this.page.getByRole('option', { name: new RegExp(`^${value}$`, 'i') }),
      this.page.getByRole('option', { name: new RegExp(value, 'i') }),
      this.page.locator(`[data-value="${value}"]`).first(),
      this.page.getByText(new RegExp(`^${value}$`, 'i')).first(),
    ];
  }

  // ───────────── Creación de Oportunidad─────────────────────
  // Abre el formulario de creación de oportunidad.
  async clickCreateOpportunityButton(buttonTitle: string): Promise<void> {
    logger.info(`Clicking create opportunity button: ${buttonTitle}`);

    const newBtnCandidates = [
      this.page.getByRole('button', { name: new RegExp(buttonTitle, 'i') }).first(),
      this.page.locator(`a.forceActionLink[title="${buttonTitle}"]`).first(),
      this.page.locator('li[data-target-selection-name*="Opportunity.New"] a').first(),
      this.page.locator('a[title="Nuevo"], button[name="New"]').first()
    ];
    
    let clicked = false;
    for (const locator of newBtnCandidates) {
      const isVisible = await locator
        .waitFor({ state: 'visible', timeout: 1500 })
        .then(() => true)
        .catch(() => false);
      if (isVisible) {
        await locator.click({ force: true });
        clicked = true;
        break;
      }
    }

    if (!clicked) {
      logger.warn(`Could not cleanly find "${buttonTitle}", trying generic button`);
      await this.page.getByRole('button', { name: /nuevo|new|crear/i }).first().click().catch(() => {});
    }

    await this.waitForPageLoad();
    await this.handleRecordTypeSelection('General'); 
  }

  // Busca y selecciona un prospecto existente para la oportunidad.
  async searchAndSelectProspect(searchTerm: string): Promise<void> {
    logger.info(`Searching for prospect: ${searchTerm}`);
    
    // 1. Llenar el campo de búsqueda
    const searchCandidates = [
      this.page.getByLabel(/buscar.*prospecto|search.*prospect|identificaci[oó]n/i),
      this.page.getByRole('combobox', { name: /prospecto|prospect/i }),
      this.page.getByPlaceholder(/buscar/i),
      this.page.locator('input[placeholder*="Buscar" i], input[placeholder*="Search" i]')
    ];
    await this.fillFirstVisibleLocator(searchCandidates, searchTerm, TIMEOUTS.MEDIUM);

    // 2. Esperar a que se rendericen resultados y esperamos a que aparezca la primera opción.
    await this.page.locator('.slds-listbox__item, [role="option"], lightning-base-combobox-item')
      .first()
      .waitFor({ state: 'visible', timeout: TIMEOUTS.MEDIUM })
      .catch(() => {});
  }

  // Pulsa el botón de selección o la primera opción disponible.
  async clickSelectButton(buttonName: string): Promise<void> {
    logger.info(`Clicking select button: ${buttonName}`);
    
    // Si es un botón explícito de "Seleccionar"
    const btnCandidates = [
      this.page.getByRole('button', { name: new RegExp(buttonName, 'i') }),
      this.page.locator(`button[title="${buttonName}" i]`)
    ];
    
    const isClicked = await this.clickFirstVisibleLocator(btnCandidates, TIMEOUTS.SHORT).then(() => true).catch(() => false);
    
    // Si no hay botón y es un Dropdown autocompletable
    if (!isClicked) {
      logger.info('Select button not found, attempting to click the first dropdown option');
      const optionCandidates = [
        this.page.locator('.slds-listbox__item').first(),
        this.page.getByRole('option').first(),
        this.page.locator('lightning-base-combobox-item').first()
      ];
      await this.clickFirstVisibleLocator(optionCandidates, TIMEOUTS.MEDIUM);
    }
  }

  // Verifica que la oportunidad se haya creado correctamente.
  async isOpportunityCreatedSuccessfully(expectedMessage: string = "La oportunidad ha sido creada correctamente."): Promise<boolean> {
    logger.info(`Verifying if opportunity was created successfully with message: ${expectedMessage}`);

    // 1. Interceptar de forma prioritaria si se muestra un mensaje de error o validación en pantalla
    const errorToast = this.page.locator('.slds-notify_toast.slds-theme_error, .slds-notify_toast.slds-theme_warning').first();
    const hasErrorToast = await errorToast
      .waitFor({ state: 'visible', timeout: 1500 })
      .then(() => true)
      .catch(() => false);
    if (hasErrorToast) {
      const errorMsg = await errorToast.textContent();
      throw new Error(`Salesforce bloqueó el guardado: ${errorMsg?.trim()}`);
    }

    // 2. Buscar el mensaje de éxito explícito en los componentes
    const isMessageVisible = await this.isAnyLocatorVisible([
      this.page.getByText(expectedMessage),
      this.page.locator('force-toast .slds-notify_toast.slds-theme_success').filter({ hasText: expectedMessage }).first(),
      this.page.locator('.toastMessage').filter({ hasText: expectedMessage }).first(),
    ], 3000).catch(() => false);

    const currentUrl = this.page.url();
    const hasRedirected = currentUrl.includes('SDP_OpportunityLead__c') || currentUrl.includes('/lightning/r/');

    return isMessageVisible || hasRedirected;
  }

  // Verifica si se redirigió a la ficha de la oportunidad creada.
  async isRedirectedToCreatedOpportunityScreen(): Promise<boolean> {
    logger.info('Verifying automatic redirection to the created opportunity screen');
    
    // 1. Espera dinámica real por redirección, con un timeout extendido
    try {
      await this.page.waitForURL((url) => {
        const href = url.toString();
        return href.includes('SDP_OpportunityLead__c') || 
               href.includes('/lightning/r/') || 
               href.includes('Opportunity');
      }, { timeout: 15000 });
      logger.info(`URL redirected successfully to: ${this.page.url()}`);
    } catch (error) {
      logger.warn(`Redirection took too long or URL pattern is different. Current URL: ${this.page.url()}`);
    }
    
    // 2. Verificación de elementos visibles en la UI que indiquen que estamos en la pantalla de detalle de oportunidad
    const isUIReady = await this.isAnyLocatorVisible([
      this.page.locator('records-entity-label').filter({ hasText: /Oportunidad/i }),
      this.page.getByText(/Oportunidad/i).first(),
      this.page.locator('.slds-page-header__title').first(),
      this.page.locator('force-record-layout-block').first() // Selector estándar de detalle de registro en LWC
    ], TIMEOUTS.MEDIUM);

    // 3. Verificación final
    const currentUrl = this.page.url();
    const isCorrectUrl = currentUrl.includes('SDP_OpportunityLead__c') || 
                         currentUrl.includes('/lightning/r/') || 
                         currentUrl.includes('Opportunity');

    return isCorrectUrl || isUIReady;
  }

  // Extrae el mensaje visible de notificación mostrado.
  async getNotificationMessage(): Promise<string> {
    logger.info('Capturing notification message from Salesforce UI');

    // Ampliar la lista de selectores para abarcar clases estándar y personalizadas de Salesforce
    const notificationLocators = [
      this.page.locator('.slds-notify_toast .toastMessage').first(),
      this.page.locator('.toastMessage').first(),
      this.page.locator('.slds-notify__content').first(),
      this.page.locator('div[role="status"], div[role="alert"]').first(),
      this.page.locator('.slds-text-color_success, .slds-notify_success').first()
    ];

    let message = '';
    for (const locator of notificationLocators) {
      const isVisible = await locator
        .waitFor({ state: 'visible', timeout: 2000 })
        .then(() => true)
        .catch(() => false);
      if (isVisible) {
        const text = await locator.textContent();
        if (text && text.trim().length > 0) {
          message = text.trim();
          break;
        }
      }
    }

    // Fallback: Si el mensaje flotante no se lee por clases, revisa si hay algún texto visible de éxito general
    if (!message) {
      const fallbackText = await this.page.locator('body').textContent();
      if (fallbackText && fallbackText.includes('La oportunidad ha sido creada correctamente.')) {
        message = 'La oportunidad ha sido creada correctamente.';
      }
    }

    logger.info(`Captured message: "${message}"`);
    return message;
  }
}