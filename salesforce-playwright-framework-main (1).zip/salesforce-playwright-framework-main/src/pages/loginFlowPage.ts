import { Page } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { BasePage } from './BasePage';
import { TIMEOUTS, URLS } from '../utils/constants';
import { logger } from '../utils/logger';
import { RUNTIME_CONFIG } from '../config/runtime.config';

/**
 * Page Object para la pantalla de Inicio de Salesforce (home login).
 * Estrategia de selectores: data-testid > rol > texto > CSS.
 */
export class LoginFlowPage extends BasePage {
  private readonly selectors = {
    usernameByCss: '#username, input[name="username"], input[type="email"]',
    passwordByCss: '#password, input[name="pw"], input[type="password"], input[name*="password" i], input[id*="password" i], input[autocomplete="current-password"]',
    loginButtonByCss: '#Login, input[type="submit"][value*="Log In"], input[type="submit"][value*="Sandbox"]',
    continueButtonByCss: '#mydomainContinue',
    lightningHeaderByCss: 'div.slds-global-header, one-appnav',
    lightningMainByCss: 'one-app, [role="main"], div[role="main"]',
    otpInputByCss:
      'input[autocomplete="one-time-code"], input[name*="otp" i], input[id*="otp" i], input[name*="verification" i], input[id*="verification" i]',
  };

  // Inicializa el Page Object con la página activa de Playwright.
  constructor(page: Page) {
    super(page);
  }

  // Abre la pantalla de Inicio de Salesforce.
  async navigateToHomeEntry(): Promise<void> {
    await this.navigate(URLS.SALESFORCE_HOME_ENTRY);
    await this.waitForPageLoad();
  }

  // Inicia sesión usando las credenciales definidas en el entorno.
  async loginWithConfiguredCredentials(allowManualOtp: boolean = false): Promise<void> {
    const username = process.env.SALESFORCE_USERNAME;
    const password = process.env.SALESFORCE_PASSWORD;

    if (!username || !password) {
      throw new Error('Missing SALESFORCE_USERNAME or SALESFORCE_PASSWORD environment variables');
    }

    const landing = await this.waitForLanding();
    if (landing === 'home') {
      logger.info('Salesforce session already authenticated');
      return;
    }

    await this.fillUsername(username);

    // Algunas variantes de inicio de sesión de Salesforce muestran el nombre de usuario + contraseña en la 
    // primera pantalla, mientras que otras requieren una acción de "Continuar" antes de mostrar la contraseña.
    const passwordInitiallyVisible = await this.isPasswordInputVisible();
    if (passwordInitiallyVisible) {
      await this.fillPassword(password);
      await this.clickPrimaryAction();
    } else {
      await this.clickPrimaryAction();
      await this.waitForPageLoad();

      const hasPasswordInput = await this.waitForPasswordInput();
      if (hasPasswordInput) {
        await this.fillPassword(password);
        await this.clickPrimaryAction();
      } else {
        const isHomeAfterContinue = await this.isLightningHomeVisible();
        if (isHomeAfterContinue) {
          logger.info('Salesforce session became authenticated after continue action');
        } else if (allowManualOtp || await this.isDelegatedAuthScreen()) {
          logger.warn('Delegated auth/OTP screen detected. Waiting for manual authentication completion...');
          await this.waitForManualOtpCompletion();
          await this.navigateToHomeEntry();
        } else {
          const currentUrl = this.page.url();
          throw new Error(`Password input was not detected after username step. URL: ${currentUrl}`);
        }
      }
    }

    await this.waitForPageLoad();

    let isHomeAfterLogin = await this.isLightningHomeVisible();
    if (!isHomeAfterLogin) {
      if (allowManualOtp && await this.isOtpChallengeVisible()) {
        logger.warn('Login did not land on Lightning home (OTP/MFA screen likely). Waiting for manual completion...');
        await this.waitForManualOtpCompletion();
        await this.navigateToHomeEntry();
        await this.waitForPageLoad();
        isHomeAfterLogin = await this.isLightningHomeVisible();
      } else if (await this.isOtpChallengeVisible()) {
        throw new Error(
          'Salesforce requested OTP/MFA. Reuse a valid storage state (SALESFORCE_STORAGE_STATE_PATH) to keep automation stable.'
        );
      } else {
        const currentUrl = this.page.url();
        const title = await this.page.title().catch(() => 'unknown');
        throw new Error(
          `Salesforce login did not reach Lightning Home and no OTP challenge was detected. URL: ${currentUrl}. Title: ${title}`
        );
      }
    }

    if (RUNTIME_CONFIG.saveSalesforceStorageState && isHomeAfterLogin) {
      await this.saveStorageState();
    }
  }

  // Ejecuta un intento de login con credenciales proporcionadas por el test.
  async attemptLoginWithCredentials(username: string, password: string): Promise<void> {
    logger.info(`Attempting login with provided credentials for user: ${username}`);
    
    // Reutilizamos métodos privados existentes
    await this.fillUsername(username);

    // Manejamos la misma lógica de los pasos 1 o 2
    const passwordInitiallyVisible = await this.isPasswordInputVisible();
    if (passwordInitiallyVisible) {
      await this.fillPassword(password);
      await this.clickPrimaryAction();
    } else {
      await this.clickPrimaryAction();
      await this.waitForPageLoad();
      
      const hasPasswordInput = await this.waitForPasswordInput();
      if (hasPasswordInput) {
        await this.fillPassword(password);
        await this.clickPrimaryAction();
      } else {
        throw new Error('Password input was not detected after username step in failed login test.');
      }
    }

    await this.waitForPageLoad();
  }

  // Detecta si se muestra un mensaje de error de acceso.
  async isLoginErrorVisible(): Promise<boolean> {
    logger.info('Checking for login error message visibility');
    
    // Salesforce suele usar el ID #error para su mensaje de credenciales inválidas
    const errorCandidates = [
      this.page.locator('#error').first(),
      this.page.locator('.loginError').first(),
      this.page.getByTestId('error').first(),
      this.page.getByRole('alert').filter({ hasText: /check your username|revisa tu nombre de usuario|contraseña/i }).first()
    ];

    return await this.isAnyLocatorVisible(errorCandidates, TIMEOUTS.SHORT);
  }

  // Espera a que la vista inicial se resuelva como login o como home.
  async waitForLanding(): Promise<'login' | 'home'> {
    const resolved = await Promise.race([
      this.isLoginPageVisible().then((isVisible) => (isVisible ? 'login' : null)),
      this.isLightningHomeVisible().then((isVisible) => (isVisible ? 'home' : null)),
      this.page.waitForTimeout(TIMEOUTS.MEDIUM).then(() => null),
    ]);

    if (resolved === 'login' || resolved === 'home') {
      return resolved;
    }

    const currentUrl = this.page.url();
    if (currentUrl.includes('/lightning/')) {
      return 'home';
    }
    return 'login';
  }

  // Comprueba si la pantalla actual corresponde al formulario de login.
  async isLoginPageVisible(): Promise<boolean> {
    const usernameByTestId = await this.getFirstVisibleLocatorNow([
      this.page.getByTestId('username'),
      this.page.getByTestId('login-username'),
    ]);
    if (usernameByTestId) {
      return true;
    }

    const usernameByRole = this.page.getByRole('textbox', { name: /username|email/i }).first();
    if (await usernameByRole.isVisible().catch(() => false)) {
      return true;
    }

    const usernameByLabel = this.page.getByLabel(/username|email|nombre de usuario|correo/i).first();
    if (await usernameByLabel.isVisible().catch(() => false)) {
      return true;
    }

    const loginByText = this.page.getByText(/log in|iniciar sesi[oó]n/i).first();
    if (await loginByText.isVisible().catch(() => false)) {
      return true;
    }

    const usernameByCss = this.page.locator(this.selectors.usernameByCss).first();
    return await usernameByCss.isVisible().catch(() => false);
  }

  // Comprueba si la pantalla actual corresponde al HomePage.
  async isLightningHomeVisible(): Promise<boolean> {
    const currentUrl = this.page.url();
    if (currentUrl.includes('/lightning/') && !currentUrl.includes('/_ui/identity/verification/')) {
      return true;
    }

    const headerByTestId = this.page.getByTestId('global-header').first();
    if (await headerByTestId.isVisible().catch(() => false)) {
      return true;
    }

    const headerByRole = this.page.getByRole('banner').first();
    if (await headerByRole.isVisible().catch(() => false)) {
      return true;
    }

    const headerByCss = this.page.locator(this.selectors.lightningHeaderByCss).first();
    if (await headerByCss.isVisible().catch(() => false)) {
      return true;
    }

    const appLauncherByRole = this.page.getByRole('button', { name: /app launcher|lanzador de aplicaciones/i }).first();
    if (await appLauncherByRole.isVisible().catch(() => false)) {
      return true;
    }

    const mainByCss = this.page.locator(this.selectors.lightningMainByCss).first();
    return await mainByCss.isVisible().catch(() => false);
  }

  // Comprueba si el campo de usuario está visible en la pantalla actual.
  async isUsernameInputVisible(): Promise<boolean> {
    const byTestId = await this.getFirstVisibleLocatorNow([
      this.page.getByTestId('username'),
      this.page.getByTestId('login-username'),
    ]);
    if (byTestId) {
      return true;
    }

    const byRole = this.page.getByRole('textbox', { name: /username|email/i }).first();
    if (await byRole.isVisible().catch(() => false)) {
      return true;
    }

    const byLabel = this.page.getByLabel(/username|email|nombre de usuario|correo/i).first();
    if (await byLabel.isVisible().catch(() => false)) {
      return true;
    }

    const byText = this.page.getByText(/nombre de usuario|username|email/i).first();
    if (await byText.isVisible().catch(() => false)) {
      return true;
    }

    const byCss = this.page.locator(this.selectors.usernameByCss).first();
    return await byCss.isVisible().catch(() => false);
  }

  // Comprueba si el campo de contraseña está visible en la pantalla actual.
  async isPasswordInputVisible(): Promise<boolean> {
    const byTestId = await this.getFirstVisibleLocatorNow([
      this.page.getByTestId('password'),
      this.page.getByTestId('login-password'),
    ]);
    if (byTestId) {
      return true;
    }

    const byRole = this.page.getByRole('textbox', { name: /password|contrase[nñ]a/i }).first();
    if (await byRole.isVisible().catch(() => false)) {
      return true;
    }

    const byLabel = this.page.getByLabel(/password|contrase[nñ]a/i).first();
    if (await byLabel.isVisible().catch(() => false)) {
      return true;
    }

    const byCss = this.page.locator(this.selectors.passwordByCss).first();
    return await byCss.isVisible().catch(() => false);
  }

  // Espera brevemente a que aparezca el campo de contraseña.
  async waitForPasswordInput(): Promise<boolean> {
    const maxAttempts = 4;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      if (await this.isPasswordInputVisible()) {
        return true;
      }
      await this.page.waitForTimeout(TIMEOUTS.SHORT);
    }
    return false;
  }

  // Verifica si existe una acción principal de login o continuar.
  async isPrimaryActionVisible(): Promise<boolean> {
    const loginActionByTestId = await this.getFirstVisibleLocatorNow([
      this.page.getByTestId('login-button'),
      this.page.getByTestId('submit-login'),
      this.page.getByTestId('continue-button'),
    ]);
    if (loginActionByTestId) {
      return true;
    }

    const loginActionByRole = this.page.getByRole('button', { name: /log in|continue|iniciar sesi[oó]n/i }).first();
    if (await loginActionByRole.isVisible().catch(() => false)) {
      return true;
    }

    const loginActionByText = this.page.getByText(/log in|continue|iniciar sesi[oó]n/i).first();
    if (await loginActionByText.isVisible().catch(() => false)) {
      return true;
    }

    const loginActionByCss = this.page
      .locator(`${this.selectors.loginButtonByCss}, ${this.selectors.continueButtonByCss}`)
      .first();
    return await loginActionByCss.isVisible().catch(() => false);
  }

  // Detecta si la pantalla actual corresponde a OTP o MFA.
  async isOtpChallengeVisible(): Promise<boolean> {
    if (this.page.url().includes('/_ui/identity/verification/')) {
      return true;
    }

    const otpByCss = this.page.locator(this.selectors.otpInputByCss).first();
    if (await otpByCss.isVisible().catch(() => false)) {
      return true;
    }

    const otpByRole = this.page
      .getByRole('textbox', { name: /verification|verificaci[oó]n|security code|c[oó]digo|authenticator|otp|mfa/i })
      .first();
    if (await otpByRole.isVisible().catch(() => false)) {
      return true;
    }

    const otpByLabel = this.page
      .getByLabel(/verification|verificaci[oó]n|security code|c[oó]digo|authenticator|otp|mfa/i)
      .first();
    if (await otpByLabel.isVisible().catch(() => false)) {
      return true;
    }

    const otpByText = this.page
      .getByText(/verification code|c[oó]digo de verificaci[oó]n|security code|authenticator|one[- ]time passcode|mfa/i)
      .first();
    return await otpByText.isVisible().catch(() => false);
  }

  // Devuelve la URL actual de la landing para dejarla registrada.
  async getLandingUrl(): Promise<string> {
    const url = await this.getCurrentUrl();
    logger.debug(`Salesforce landing URL: ${url}`);
    return url;
  }

  // Registra un resumen del estado de la landing detectada.
  async logLandingSummary(): Promise<void> {
    const landing = await this.waitForLanding();
    const url = await this.getLandingUrl();
    logger.info(`Salesforce landing detected: ${landing} (${url})`);
  }

  // Completa el campo de usuario usando el selector que esté visible.
  private async fillUsername(username: string): Promise<void> {
    const usernameByTestId = await this.getFirstVisibleLocatorNow([
      this.page.getByTestId('username'),
      this.page.getByTestId('login-username'),
    ]);
    if (usernameByTestId) {
      await usernameByTestId.fill(username);
      return;
    }

    const usernameByRole = this.page.getByRole('textbox', { name: /username|email/i }).first();
    if (await usernameByRole.isVisible().catch(() => false)) {
      await usernameByRole.fill(username);
      return;
    }

    const usernameByLabel = this.page.getByLabel(/username|email|nombre de usuario|correo/i).first();
    if (await usernameByLabel.isVisible().catch(() => false)) {
      await usernameByLabel.fill(username);
      return;
    }

    const usernameByCss = this.page.locator(this.selectors.usernameByCss).first();
    await usernameByCss.fill(username);
  }

  // Completa el campo de contraseña usando el selector que esté visible.
  private async fillPassword(password: string): Promise<void> {
    const byTestId = await this.getFirstVisibleLocatorNow([
      this.page.getByTestId('password'),
      this.page.getByTestId('login-password'),
    ]);
    if (byTestId) {
      await byTestId.fill(password);
      return;
    }

    const byRole = this.page.getByRole('textbox', { name: /password|contrase[nñ]a/i }).first();
    if (await byRole.isVisible().catch(() => false)) {
      await byRole.fill(password);
      return;
    }

    const byLabel = this.page.getByLabel(/password|contrase[nñ]a/i).first();
    if (await byLabel.isVisible().catch(() => false)) {
      await byLabel.fill(password);
      return;
    }

    const byCss = this.page.locator(this.selectors.passwordByCss).first();
    if (await byCss.isVisible().catch(() => false)) {
      await byCss.fill(password);
      return;
    }

    const currentUrl = this.page.url();
    throw new Error(`Password input is not visible on current page. URL: ${currentUrl}`);
  }

  // Detecta si la pantalla pertenece a un flujo de autenticación delegada.
  private async isDelegatedAuthScreen(): Promise<boolean> {
    const currentUrl = this.page.url();
    const looksLikeDelegatedHost =
      !currentUrl.includes('lightning.force.com') &&
      !currentUrl.includes('my.salesforce.com') &&
      !currentUrl.includes('force.com');

    if (looksLikeDelegatedHost) {
      return true;
    }

    const delegatedAuthText = this.page
      .getByText(/sign in with|single sign-on|sso|microsoft|okta|adfs|identity provider|choose account/i)
      .first();

    return await delegatedAuthText.isVisible().catch(() => false);
  }

  // Pulsa la acción principal del formulario de login o continue.
  private async clickPrimaryAction(): Promise<void> {
    const byTestId = await this.getFirstVisibleLocatorNow([
      this.page.getByTestId('login-button'),
      this.page.getByTestId('submit-login'),
      this.page.getByTestId('continue-button'),
    ]);
    if (byTestId) {
      await byTestId.click();
      return;
    }

    const byRole = this.page.getByRole('button', { name: /log in|continue|iniciar sesi[oó]n/i }).first();
    if (await byRole.isVisible().catch(() => false)) {
      await byRole.click();
      return;
    }

    const byText = this.page.getByText(/log in|continue|iniciar sesi[oó]n/i).first();
    if (await byText.isVisible().catch(() => false)) {
      await byText.click();
      return;
    }

    const byCss = this.page.locator(`${this.selectors.loginButtonByCss}, ${this.selectors.continueButtonByCss}`).first();
    await byCss.click();
  }

  // Guarda el storage state autenticado para reutilizarlo en otros escenarios.
  private async saveStorageState(): Promise<void> {
    const storagePath = path.resolve(RUNTIME_CONFIG.salesforceStorageStatePath);
    fs.mkdirSync(path.dirname(storagePath), { recursive: true });
    await this.page.context().storageState({ path: storagePath });
    logger.info(`Saved Salesforce storage state: ${storagePath}`);
  }

  // Espera a que finalice el flujo manual de OTP antes de continuar.
  private async waitForManualOtpCompletion(): Promise<void> {
    await this.page
      .locator('one-app, [role="main"], div[role="main"], div.slds-global-header, one-appnav, div.slds-global-header_container')
      .first()
      .waitFor({ state: 'visible', timeout: RUNTIME_CONFIG.manualOtpTimeoutMs });
  }
}
