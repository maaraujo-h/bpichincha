import { Locator, Page } from '@playwright/test';
import { logger } from '../utils/logger';
import { TIMEOUTS } from '../utils/constants';

/**
 * Clase Base para todos los Page Objects
 * Implementa métodos comunes y las mejores prácticas de POM
 */
export class BasePage {
  // Recibe la instancia que reutilizará el Page Object.
  constructor(protected page: Page) {}

  // Comprueba si un locator se vuelve visible esperando de verdad.
  private async isVisibleWithRealWait(locator: Locator, timeout: number): Promise<boolean> {
    return locator
      .waitFor({ state: 'visible', timeout })
      .then(() => true)
      .catch(() => false);
  }

  // Devuelve el primer locator visible sin esperar activamente.
  protected async getFirstVisibleLocatorNow(candidates: Locator[]): Promise<Locator | null> {
    for (const candidate of candidates) {
      const locator = candidate.first();
      if (await locator.isVisible().catch(() => false)) {
        return locator;
      }
    }

    return null;
  }

  protected async getFirstVisibleLocator(
    candidates: Locator[],
    timeout: number = TIMEOUTS.SHORT
  ): Promise<Locator | null> {
    const perCandidateTimeout = Math.max(250, Math.floor(timeout / candidates.length));

    for (const candidate of candidates) {
      const locator = candidate.first();
      if (await this.isVisibleWithRealWait(locator, perCandidateTimeout)) {
        return locator;
      }
    }

    return null;
  }

  // Comprueba si al menos uno de los locators candidatos se vuelve visible.
  protected async isAnyLocatorVisible(
    candidates: Locator[],
    timeout: number = TIMEOUTS.SHORT
  ): Promise<boolean> {
    const visibleLocator = await this.getFirstVisibleLocator(candidates, timeout);
    return visibleLocator !== null;
  }

  // Hace clic en el primer locator visible de la lista.
  protected async clickFirstVisibleLocator(
    candidates: Locator[],
    timeout: number = TIMEOUTS.SHORT
  ): Promise<void> {
    const locator = await this.getFirstVisibleLocator(candidates, timeout);

    if (!locator) {
      throw new Error('Unable to find a visible locator to click');
    }

    await locator.click();
  }

  // Rellena el primer locator visible y editable de la lista.
  protected async fillFirstVisibleLocator(
    candidates: Locator[],
    value: string,
    timeout: number = TIMEOUTS.SHORT
  ): Promise<void> {
    const perCandidateTimeout = Math.max(250, Math.floor(timeout / candidates.length));

    for (const candidate of candidates) {
      const locator = candidate.first();
      const isVisible = await this.isVisibleWithRealWait(locator, perCandidateTimeout);

      if (!isVisible) {
        continue;
      }

      try {
        await locator.fill(value);
        return;
      } catch {
        // Si el locator no es editable, seguimos buscando en los demás candidatos.
      }
    }

    throw new Error('Unable to find a visible editable locator to fill');
  }

  // Devuelve los textos visibles del primer locator encontrado.
  protected async getVisibleTexts(
    candidates: Locator[],
    timeout: number = TIMEOUTS.SHORT
  ): Promise<string[]> {
    const locator = await this.getFirstVisibleLocator(candidates, timeout);

    if (!locator) {
      return [];
    }

    const texts = await locator.allTextContents().catch(() => [] as string[]);
    return texts.map((text) => text.trim()).filter(Boolean);
  }

  // Navega a una URL específica con un tiempo de espera optimizado.
  async navigate(url: string): Promise<void> {
    logger.info(`Navigating to: ${url}`);
    const maxAttempts = 2;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        await this.page.goto(url, {
          waitUntil: 'commit',
          timeout: TIMEOUTS.NAVIGATION,
        });
        return;
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const isTransientNavigationError =
          message.includes('net::ERR_ABORTED') || message.includes('frame was detached');

        if (!isTransientNavigationError || attempt === maxAttempts) {
          throw error;
        }

        logger.warn(`Transient navigation error, retrying (${attempt}/${maxAttempts}): ${message}`);
      }
    }
  }

  // Espera a que un elemento CSS esté visible.
  async waitForElement(selector: string, timeout: number = TIMEOUTS.MEDIUM): Promise<void> {
    logger.debug(`Waiting for element: ${selector}`);
    await this.page.waitForSelector(selector, { state: 'visible', timeout });
  }

  // Hace clic en un elemento usando su selector CSS.
  async click(selector: string): Promise<void> {
    logger.debug(`Clicking on: ${selector}`);
    await this.waitForElement(selector);
    await this.page.click(selector);
  }

  //  Rellena un campo de texto usando su selector CSS.
  async fill(selector: string, text: string): Promise<void> {
    logger.debug(`Filling field ${selector} with: ${text}`);
    await this.waitForElement(selector);
    await this.page.fill(selector, text);
  }

  // Obtiene el texto de un elemento visible.
  async getText(selector: string): Promise<string> {
    logger.debug(`Getting text from: ${selector}`);
    await this.waitForElement(selector);
    const text = await this.page.textContent(selector);
    return text || '';
  }

  // Comprueba si un elemento es visible con un timeout corto.
  async isVisible(selector: string): Promise<boolean> {
    logger.debug(`Checking visibility of: ${selector}`);
    try {
      await this.page.waitForSelector(selector, { 
        state: 'visible', 
        timeout: TIMEOUTS.SHORT 
      });
      return true;
    } catch {
      return false;
    }
  }

 // Desplaza la vista hasta un elemento.
  async scrollToElement(selector: string): Promise<void> {
    logger.debug(`Scrolling to: ${selector}`);
    await this.page.locator(selector).scrollIntoViewIfNeeded();
  }

  // Espera a que el DOM termine de cargar.
  async waitForPageLoad(): Promise<void> {
    logger.debug('Waiting for DOM to load');
    await this.page.waitForLoadState('domcontentloaded');
  }

  // Toma una captura de pantalla de la página.
  async takeScreenshot(name: string): Promise<void> {
    const path = `screenshots/${name}-${Date.now()}.png`;
    logger.info(`Capturing screenshot: ${path}`);
    await this.page.screenshot({ path, fullPage: true });
  }

  // Obtiene el título actual de la página.
  async getTitle(): Promise<string> {
    const title = await this.page.title();
    logger.debug(`Page title: ${title}`);
    return title;
  }

  // Obtiene la URL actual del navegador.
  async getCurrentUrl(): Promise<string> {
    const url = this.page.url();
    logger.debug(`Current URL: ${url}`);
    return url;
  }

  // Pulsa una tecla del teclado.
  async pressKey(key: string): Promise<void> {
    logger.debug(`Pressing key: ${key}`);
    await this.page.keyboard.press(key);
  }

  // Espera un tiempo fijo solo cuando no hay una alternativa mejor.
  async wait(milliseconds: number): Promise<void> {
    logger.warn(`Using waitForTimeout (${milliseconds}ms) - consider an alternative`);
    await this.page.waitForTimeout(milliseconds);
  }

  // Pasa el cursor sobre un elemento.
  async hover(selector: string): Promise<void> {
    logger.debug(`Hovering on: ${selector}`);
    await this.waitForElement(selector);
    await this.page.locator(selector).hover();
  }

  // Selecciona una opción de un desplegable.
  async selectOption(selector: string, value: string): Promise<void> {
  logger.debug(`Selecting option "${value}" in: ${selector}`);
    await this.waitForElement(selector);
    await this.page.selectOption(selector, value);
  }

  // Cuenta cuántos elementos coinciden con un selector.
  async getElementCount(selector: string): Promise<number> {
    const count = await this.page.locator(selector).count();
  logger.debug(`Elements found with selector ${selector}: ${count}`);
    return count;
  }

  // Verifica si un elemento está habilitado.
  async isEnabled(selector: string): Promise<boolean> {
    try {
      await this.waitForElement(selector, TIMEOUTS.SHORT);
      return await this.page.locator(selector).isEnabled();
    } catch {
      return false;
    }
  }

  // Limpia el localStorage para aislar los escenarios.
  async clearLocalStorage(): Promise<void> {
    logger.debug('Clearing localStorage');
    if (this.page.isClosed()) {
      logger.warn('Skipping localStorage cleanup because page is already closed');
      return;
    }
    await this.page.evaluate(() => {
      window.localStorage.clear();
    });
  }

  // Limpia el sessionStorage para aislar los escenarios.
  async clearSessionStorage(): Promise<void> {
  logger.debug('Clearing sessionStorage');
  if (this.page.isClosed()) {
    logger.warn('Skipping sessionStorage cleanup because page is already closed');
    return;
  }
  await this.page.evaluate(() => {
    sessionStorage.clear();
  });
}
}
