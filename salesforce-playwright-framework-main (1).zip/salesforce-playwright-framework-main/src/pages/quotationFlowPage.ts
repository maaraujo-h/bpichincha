import { Page, Locator } from '@playwright/test';
import { BasePage } from './BasePage';
import { logger } from '../utils/logger';
import { TIMEOUTS } from '../utils/constants';

export class QuotationFlowPage extends BasePage {
  // Inicializa el Page Object con la página activa.
  constructor(page: Page) {
    super(page);
  }

  // Abre el menú solicitado.
  async clickMenu(menuName: string): Promise<void> {
    logger.info(`Clicking menu: ${menuName}`);
    await this.page.locator(`a[title="${menuName}"], span:has-text("${menuName}")`).first().click();
    await this.waitForPageLoad();
  }

  // Busca un cliente por identificación en la pantalla de cotización.
  async searchClient(identification: string): Promise<void> {
    logger.info(`Searching client with identification: ${identification}`);

    const searchCandidates = [
      this.page.locator('div:has(input#input-2510), lightning-input:has(#input-2510)').locator('input.slds-input').first(),
      this.page.locator('lightning-input:has-text("Documento de identidad") input').first(),
      this.page.locator('input[part="input"][type="text"]').first(),
      this.page.locator('div[role="main"] input.slds-input[type="text"]').first()
    ];

    await this.fillFirstVisibleLocator(searchCandidates, identification, TIMEOUTS.LONG);
  }

  // Pulsa el botón de búsqueda del formulario de cotización.
  async clickSearchButton(): Promise<void> {
    logger.info('Clicking search button on quotation screen');

    const btnCandidates = [
      this.page.locator('button.slds-button_neutral').filter({ hasText: /^Buscar$/i }).first(),
      this.page.getByRole('button', { name: /^Buscar$/i }).first(),
      this.page.locator('button[part="button"]').filter({ hasText: /^Buscar$/i }).first()
    ];
    
    await this.clickFirstVisibleLocator(btnCandidates, TIMEOUTS.MEDIUM);
  }

  // Selecciona la persona encontrada en los resultados.
  async selectFoundPerson(identification: string): Promise<void> {
    logger.info(`Selecting found person with ID: ${identification}`);

    const personCandidates = [
      this.page.locator(`p.slds-truncate[title="${identification}"]`).first(),
      this.page.locator(`div:has(p[title="${identification}"])`).first(),
      this.page.getByText(identification, { exact: true }).first()
    ];
    
    await this.clickFirstVisibleLocator(personCandidates, TIMEOUTS.LONG);
  }

  // Pulsa un botón genérico del formulario o modal actual.
  async clickGenericButton(buttonName: string): Promise<void> {
    logger.info(`Clicking generic button: ${buttonName}`);

    const btnCandidates = [
      this.page.locator('.slds-modal__container, force-record-edit-form, lightning-modal-footer, .slds-is-open')
        .locator('button[type="submit"], button.slds-button_neutral, button.slds-button_brand')
        .filter({ hasText: new RegExp(`^${buttonName}$`, 'i') }).first(),
      this.page.locator('button.slds-button_neutral[type="submit"]').filter({ hasText: new RegExp(`^${buttonName}$`, 'i') }).first(),
      this.page.locator('button[type="submit"]').filter({ hasText: new RegExp(`^${buttonName}$`, 'i') }).first(),
      this.page.getByRole('button', { name: new RegExp(`^${buttonName}$`, 'i') }).last()
    ];
    
    await this.clickFirstVisibleLocator(btnCandidates, TIMEOUTS.MEDIUM);
    await this.waitForPageLoad();
  }

  // Selecciona una preexistencia y la mueve al listado de seleccionadas.
  async moveNewPreexistences(defaultDisease: string = "ACALASIA"): Promise<void> {
    logger.info(`Selecting disease and moving to selected: "${defaultDisease}"`);

    const availableDiseases = [
      defaultDisease,
      "AFASIA DE BROCA",
      "AGRANULOSITOSIS NEUTROPENIA",
      "ALCOHOLISMO",
      "ALERGIA BRONQUIAL",
      "ALERGIA DE CONTACTO",
      "ALERGIAS",
      "ALOPECIA",
      "AMBLIOPÍA (OJO VAGO)",
      "AMPUTACIÓN DE MIEMBRO",
      "ANAFILACTICO",
      "ANEMIA",
      "ANSIEDAD",
      "ASMA",
      "CANCER",
      "DIABETES CRÓNICA",
      "HIPERTENSIÓN ARTERIAL",
      "MIGRAÑA"
    ];

    // Seleccionar una enfermedad de forma segura
    const selectedDisease = availableDiseases.includes(defaultDisease) 
      ? defaultDisease 
      : availableDiseases[Math.floor(Math.random() * availableDiseases.length)];
      
    logger.info(`Target disease to select: "${selectedDisease}"`);

    // Selector directo y rápido filtrando por el texto exacto dentro del rol option
    const diseaseOption = this.page.locator('div[role="option"]')
      .filter({ hasText: new RegExp(`^${selectedDisease}$`, 'i') })
      .first();

    const diseaseOptionVisible = await diseaseOption
      .waitFor({ state: 'visible', timeout: TIMEOUTS.SHORT })
      .then(() => true)
      .catch(() => false);

    if (diseaseOptionVisible) {
      await diseaseOption.scrollIntoViewIfNeeded();
      await diseaseOption.click({ force: true });
      logger.info(`Disease option "${selectedDisease}" clicked successfully.`);
    } else {
      logger.warn(`Disease option "${selectedDisease}" was not visible.`);
    }

    // Selector directo para el botón de flecha derecha del dueling list
    const moveRightBtn = this.page.locator('button:has(svg[data-key="right"]), button[title*="Mover" i], button[title*="Agregar" i]').first();

    const moveRightBtnVisible = await moveRightBtn
      .waitFor({ state: 'visible', timeout: TIMEOUTS.SHORT })
      .then(() => true)
      .catch(() => false);

    if (moveRightBtnVisible) {
      await moveRightBtn.click();
      logger.info('Moved selected disease to the right column.');
    } else {
      logger.warn('Right arrow button for dueling list not visible.');
    }
  }

  // Completa el campo de preexistencia con el texto recibido.
  async fillPreexistence(text: string): Promise<void> {
    logger.info(`Filling Preexistence field: ${text}`);
    const preexistenceCandidates = [
      this.page.locator('lightning-input:has-text("Preexistencia"), div:has-text("Preexistencia")').locator('input.slds-input').first(),
      this.page.locator('input#input-2999').first()
    ];
    await this.fillFirstVisibleLocator(preexistenceCandidates, text, TIMEOUTS.MEDIUM);
  }

  // Completa la fecha de tratamiento con el día actual.
  async fillTreatmentDate(): Promise<void> {
    logger.info('Filling current date in treatment date field');
    const currentDate = new Date().toISOString().split('T')[0];

    const dateCandidates = [
      this.page.locator('lightning-input:has-text("Fecha"), div:has-text("Fecha")').locator('input[type="date"]').first(),
      this.page.locator('input[type="date"]').first(),
      this.page.locator('input#input-2892').first()
    ];
    await this.fillFirstVisibleLocator(dateCandidates, currentDate, TIMEOUTS.MEDIUM);
  }

  // Completa el campo de observaciones o tratamiento.
  async fillObservations(text: string): Promise<void> {
    logger.info(`Filling observations field: ${text}`);
    const obsCandidates = [
      this.page.locator('lightning-input:has-text("Observ"), div:has-text("Observ")').locator('input.slds-input').first(),
      this.page.locator('input#input-2896').first()
    ];
    await this.fillFirstVisibleLocator(obsCandidates, text, TIMEOUTS.MEDIUM);
  }

  // Selecciona una opción concreta en un combobox por su etiqueta.
  async selectComboboxOption(comboBoxLabel: string, optionToSelect: string): Promise<void> {
    logger.info(`Selecting option '${optionToSelect}' in combobox '${comboBoxLabel}'`);

    const comboboxCandidates = [
      this.page.locator(`button[aria-label="${comboBoxLabel}"][role="combobox"]`).first(),
      this.page.locator(`button[aria-label*="${comboBoxLabel}" i]`).first(),
      this.page.getByRole('combobox', { name: new RegExp(comboBoxLabel, 'i') }).first()
    ];

    if (comboBoxLabel.toLowerCase() === 'parentezco') {
      comboboxCandidates.push(this.page.locator('button.slds-combobox__input').nth(6));
    }

    await this.clickFirstVisibleLocator(comboboxCandidates, TIMEOUTS.MEDIUM);

    const optionCandidates = [
      this.page.locator('lightning-base-combobox-item').filter({ hasText: new RegExp(optionToSelect, 'i') }).first(),
      this.page.getByRole('option', { name: new RegExp(optionToSelect, 'i') }).first(),
      this.page.locator(`[data-value="${optionToSelect}"]`).first(),
      this.page.getByText(new RegExp(optionToSelect, 'i')).first()
    ];
    
    // Las opciones del desplegable se muestran justo después de abrir el combobox;
    await this.clickFirstVisibleLocator(optionCandidates, TIMEOUTS.MEDIUM);
  }

  // Marca o desmarca la casilla de titular de la cuenta.
  async checkAccountHolder(isHolder: string): Promise<void> {
    logger.info(`Checking account holder as: ${isHolder}`);
    const desiredChecked = /^(s[ií]|true|yes|1)$/i.test(isHolder.trim());

    const checkboxIndicator = this.page.locator('span.slds-checkbox_faux[part="indicator"]').first();
    const checkboxInput = checkboxIndicator.locator('xpath=preceding-sibling::input[@type="checkbox"]').first();

    const checkboxIndicatorVisible = await checkboxIndicator
      .waitFor({ state: 'visible', timeout: TIMEOUTS.SHORT })
      .then(() => true)
      .catch(() => false);

    if (checkboxIndicatorVisible) {
      const isChecked = await checkboxInput.isChecked().catch(() => false);
      if (isChecked !== desiredChecked) {
        await checkboxIndicator.click();
      } else {
        logger.info('Account holder checkbox already in the desired state, skipping click.');
      }
    }
  }

  // Completa el número de cuenta del asegurado.
  async fillAccountNumber(accNumber: string): Promise<void> {
    logger.info(`Filling account number: ${accNumber}`);
    const accCandidates = [
      this.page.locator('lightning-input:has-text("cuenta"), div:has-text("Número de cuenta")').locator('input.slds-input').first(),
      this.page.locator('input#input-3027').first()
    ];
    await this.fillFirstVisibleLocator(accCandidates, accNumber, TIMEOUTS.MEDIUM);
  }

  // Abre la búsqueda de beneficiarios.
  async clickSearchBeneficiaryButton(): Promise<void> {
    logger.info('Clicking search beneficiary button');
    const searchBeneficiaryBtn = this.page.locator('lightning-button c-bclistadopersonas_bclistadopersonas button.slds-button_neutral').last();
    await searchBeneficiaryBtn.waitFor({ state: 'visible', timeout: TIMEOUTS.MEDIUM });
    await searchBeneficiaryBtn.click();
  }

  // Selecciona el primer beneficiario visible en la lista.
  async selectFirstBeneficiary(): Promise<void> {
    logger.info('Selecting first beneficiary from results');
    const firstBeneficiary = this.page.locator('slot a[c-bclistadopersonas_bclistadopersonas]').first();
    await firstBeneficiary.waitFor({ state: 'visible', timeout: TIMEOUTS.MEDIUM });
    await firstBeneficiary.click();
  }

  // Añade la relación seleccionada al formulario.
  async clickAddButton(): Promise<void> {
    logger.info('Clicking add relationship button');
    const addBtn = this.page.locator('button.slds-button_icon[title="Agregar"]').first();
    await addBtn.waitFor({ state: 'visible', timeout: TIMEOUTS.MEDIUM });
    await addBtn.click();
  }

  // Gestiona la firma delegada según el método indicado.
  async handleDelegatedSignature(method: string): Promise<void> {
    logger.info(`Handling delegated signature with method: ${method}`);

    const sigComboboxCandidates = [
      this.page.locator('button[aria-label*="Firma delegada" i][role="combobox"]').first(),
      this.page.getByRole('combobox', { name: /Firma delegada/i }).first()
    ];
    
    if (await this.isAnyLocatorVisible(sigComboboxCandidates, TIMEOUTS.MEDIUM)) {
      await this.clickFirstVisibleLocator(sigComboboxCandidates, TIMEOUTS.MEDIUM);

      const optionCandidates = [
        this.page.getByRole('option', { name: new RegExp(`^${method}$`, 'i') }).first(),
        this.page.locator(`[data-value="${method}"]`).first(),
        this.page.getByText(new RegExp(`^${method}$`, 'i')).first()
      ];
      await this.clickFirstVisibleLocator(optionCandidates, TIMEOUTS.MEDIUM);
    }

    const normalizedMethod = method.toLowerCase().trim();
    
    if (normalizedMethod === 'correo' || normalizedMethod === 'celular') {
      logger.info('Clicking "Enviar código" button');
      const sendCodeCandidates = [
        this.page.locator('button.slds-button_neutral').filter({ hasText: /^Enviar código$/i }).first(),
        this.page.getByRole('button', { name: /^Enviar código$/i }).first()
      ];
      await this.clickFirstVisibleLocator(sendCodeCandidates, TIMEOUTS.MEDIUM);
    } else if (normalizedMethod === 'presencial') {
      logger.info('Clicking "Ha firmado" button');
      const signedCandidates = [
        this.page.locator('button.slds-button_neutral').filter({ hasText: /^Ha firmado$/i }).first(),
        this.page.getByRole('button', { name: /^Ha firmado$/i }).first()
      ];
      await this.clickFirstVisibleLocator(signedCandidates, TIMEOUTS.MEDIUM);
    }

    await this.waitForPageLoad().catch(() => {});
  }
}