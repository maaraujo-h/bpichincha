/**
 * Configuración del navegador y ajustes anti-detección.
 */

export const BROWSER_CONFIG = {
  /**
   * User agent realista para evitar detección
   */
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  
  /**
   * Viewport por defecto
   */
  viewport: {
    width: 1920,
    height: 1080,
  },
  
  /**
   * Configura el idioma del navegador para alinearlo con el sitio objetivo.
   */
  locale: 'es-ES',
  
  /**
   * Argumentos de Chromium optimizados para velocidad y anti-detección
   */
  launchArgs: [
    // Anti-detección
    '--disable-blink-features=AutomationControlled',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    
    // Optimización de rendimiento
    '--disable-dev-shm-usage',
    '--disable-gpu',
    '--disable-extensions',
    '--disable-software-rasterizer',
    
    // Evitar throttling
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    
    // Seguridad deshabilitada para tests
    '--disable-web-security',
    '--disable-features=IsolateOrigins,site-per-process',
  ] as const, // Nota: el 'as const' hace que sea readonly, lo cual solucionamos en hooks.ts con el spread operator
  
  /**
   * Scripts de inicialización para ocultar automatización
   * Restaurado para que hooks.ts pueda acceder a él.
   */
  initScripts: `
    // Ocultar navigator.webdriver
    Object.defineProperty(navigator, 'webdriver', {
      get: () => false,
    });
    
    // Inyectar window.chrome
    window.chrome = {
      runtime: {},
    };
  `,
} as const;