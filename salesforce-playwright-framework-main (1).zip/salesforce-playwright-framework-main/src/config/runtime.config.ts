import dotenv from 'dotenv';

dotenv.config();

// Lee la primera variable de entorno definida entre varias opciones posibles.
function readFirstDefinedEnv(names: string[]): string | undefined {
  for (const name of names) {
    const rawValue = process.env[name];
    if (rawValue && rawValue.trim().length > 0) {
      return rawValue;
    }
  }

  return undefined;
}

// Lee una variable obligatoria y falla rápido si no está configurada.
function readRequiredEnv(names: string[]): string {
  const value = readFirstDefinedEnv(names);
  if (!value) {
    throw new Error(`Missing required environment variable. Set one of: ${names.join(', ')}`);
  }

  return value;
}

const salesforceHomeUrl = readRequiredEnv([ 'SALESFORCE_URL']);
const baseURL = new URL(salesforceHomeUrl).origin;

// Credenciales centralizadas: Si no están en el .env, el framework fallará rápido.
const username = readRequiredEnv(['SALESFORCE_USERNAME']);
const password = readRequiredEnv(['SALESFORCE_PASSWORD']);

function readBooleanEnv(name: string, defaultValue: boolean): boolean {
  const rawValue = process.env[name];
  if (rawValue === undefined) {
    return defaultValue;
  }

  return rawValue.toLowerCase() === 'true';
}

function readNumberEnv(name: string, defaultValue: number): number {
  const rawValue = process.env[name];
  if (rawValue === undefined) {
    return defaultValue;
  }

  const parsed = Number.parseInt(rawValue, 10);
  return Number.isNaN(parsed) ? defaultValue : parsed;
}

// Construye la configuración opcional de proxy si el entorno la define.
function buildProxySettings() {
  if (!process.env.PROXY_HOST) {
    return undefined;
  }

  return {
    server: `${process.env.PROXY_PROTOCOL ?? 'http'}://${process.env.PROXY_HOST}:${process.env.PROXY_PORT ?? '80'}`,
    bypass: process.env.NO_PROXY,
  };
}

// Agrupa la configuración de ejecución del framework para reutilizarla en todo el proyecto.
export const RUNTIME_CONFIG = {
  baseURL,
  salesforceHomeUrl,
  username,
  password,
  useSalesforceStorageState: readBooleanEnv('SALESFORCE_USE_STORAGE_STATE', true),
  saveSalesforceStorageState: readBooleanEnv('SALESFORCE_SAVE_STORAGE_STATE', true),
  salesforceStorageStatePath: process.env.SALESFORCE_STORAGE_STATE_PATH ?? 'storage-state/salesforce-auth.json',
  allowManualOtp: readBooleanEnv('SALESFORCE_ALLOW_MANUAL_OTP', false),
  manualOtpTimeoutMs: readNumberEnv('SALESFORCE_MANUAL_OTP_TIMEOUT_MS', 120000),
  headless: readBooleanEnv('HEADLESS', true),
  timeout: readNumberEnv('TIMEOUT', 60000),
  proxy: buildProxySettings(),
  
  // Banderas de evidencia restauradas para que hooks.ts pueda acceder a ellas
  screenshotOnFailure: readBooleanEnv('SCREENSHOT_ON_FAILURE', false),
  traceOnFailure: readBooleanEnv('TRACE_ON_FAILURE', false),
  videoOnFailure: readBooleanEnv('VIDEO_ON_FAILURE', false),
} as const;