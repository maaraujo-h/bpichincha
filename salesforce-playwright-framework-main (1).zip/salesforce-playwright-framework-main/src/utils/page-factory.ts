import { Page } from '@playwright/test';
import { LoginFlowPage } from '../pages/loginFlowPage';
import { CommercialFlowPage } from '../pages/commercialFlowPage';
import { QuotationFlowPage } from '../pages/quotationFlowPage';

/**
 * Crear y reutilizar Page Objects de forma consistente.
 */
export interface IPageContext {
  loginFlowPage?: LoginFlowPage;
  commercialFlowPage?: CommercialFlowPage;
  quotationFlowPage?: QuotationFlowPage;
  [key: string]: unknown;
}

// Page Objects compartida entre los steps.
export class PageFactory {
  
  // Crea o reutiliza el Page Object del flujo de login.
  static getSalesforceLoginPage(context: IPageContext, page: Page): LoginFlowPage {
    if (!context.loginFlowPage) {
      context.loginFlowPage = new LoginFlowPage(page);
    }
    return context.loginFlowPage as LoginFlowPage;
  }

  // Crea o reutiliza el Page Object del flujo comercial.
  static getSalesforceCommercialFlowPage(context: IPageContext, page: Page): CommercialFlowPage {
    if (!context.commercialFlowPage) {
      context.commercialFlowPage = new CommercialFlowPage(page);
    }
    return context.commercialFlowPage as CommercialFlowPage;
  }

  // Devuelve el Page Object del flujo de cotización y lo instancia una sola vez.
  static getQuotationFlowPage(context: IPageContext, page: Page): QuotationFlowPage {
    if (!context.quotationFlowPage) {
      context.quotationFlowPage = new QuotationFlowPage(page);
    }
    return context.quotationFlowPage as QuotationFlowPage;
  }
}