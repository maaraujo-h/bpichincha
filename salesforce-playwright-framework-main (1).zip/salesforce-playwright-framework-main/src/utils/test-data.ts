/**
 * Datos y constantes centralizadas para los escenarios de prueba.
 */

export const TEST_DATA = {
  SALESFORCE: {
    QUOTATION: {
      // Datos para el flujo de interacción manual y caso.
      contactType: 'In',
      contactChannel: 'Teléfono',
      caseType: 'Requerimientos',
      caseSubtype: 'Aviso de Siniestros',
      caseCreationReason: 'Envío aviso de siniestro',
      caseAttentionPoint: 'MATRIZ - QUITO',
      caseDetails: 'Accidente de tránsito',
    },
    COMMERCIAL: {
      // Datos para la creación de prospecto.
      prospectIdentification: '1723111102',
      prospectPhone: '987654321',
      prospectEmail: 'usuario@gmail.com',
      prospectBusinessLine: 'Salud',
      prospectBroker: 'Broker Principal',
      prospectEstimatedPremium: '1000000',
      prospectValidityDays: '10',
      prospectBranches: 'VIDA COLECTIVO, TRANSPORTE',
      // Datos para la creación de oportunidad.
      opportunityEstimatedPremium: '15000',
      opportunityValidityDays: '30',
      opportunityBranch: 'VIDA COLECTIVO',
      opportunityExpectedStatus: 'Compromiso',
    },
  },
} as const;

/**
 * Utilidades para generar datos de prueba.
 */
export class TestDataGenerator {
  /**
   * Genera un correo electrónico aleatorio.
   */
  static generateEmail(prefix: string = 'test'): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `${prefix}-${timestamp}-${random}@test.com`;
  }

  /**
   * Genera un nombre aleatorio.
   */
  static generateName(): string {
    const firstNames = ['Juan', 'María', 'Pedro', 'Ana', 'Luis', 'Carmen', 'José', 'Isabel'];
    const lastNames = ['García', 'Martínez', 'López', 'González', 'Rodríguez', 'Fernández'];
    
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    
    return `${firstName} ${lastName}`;
  }

  /**
   * Genera un número de teléfono con formato habitual en España.
   */
  static generatePhoneNumber(): string {
    const prefix = ['6', '7', '9'][Math.floor(Math.random() * 3)];
    const number = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    return `${prefix}${number}`;
  }

  /**
   * Genera una dirección con formato habitual en España.
   */
  static generateAddress(): {
    street: string;
    number: string;
    city: string;
    postalCode: string;
  } {
    const streets = ['Calle Mayor', 'Avenida de la Constitución', 'Paseo de Gracia', 'Gran Vía'];
    const cities = ['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Zaragoza'];
    
    return {
      street: streets[Math.floor(Math.random() * streets.length)],
      number: Math.floor(Math.random() * 200 + 1).toString(),
      city: cities[Math.floor(Math.random() * cities.length)],
      postalCode: Math.floor(Math.random() * 50000 + 1000).toString().padStart(5, '0'),
    };
  }

  /**
   * Genera una cadena aleatoria de longitud configurable.
   */
  static generateRandomString(length: number = 10): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }
}
