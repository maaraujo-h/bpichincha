/**
 * Constantes globales del proyecto - Optimizadas para velocidad
 */

import { RUNTIME_CONFIG } from '../config/runtime.config';

/**
 * Timeouts en milisegundos - Ajustados para tests rápidos
 */
export const TIMEOUTS = {
  /** Detección rápida de elementos (cookies, modales) */
  INSTANT: 3000,
  /** Elementos que deberían aparecer rápido */
  SHORT: 5000,
  /** Elementos estándar - timeout por defecto */
  MEDIUM: 8000,
  /** Espera para elementos más pesados */
  LONG: 15000,
  /** Navegación de páginas completas */
  NAVIGATION: 20000,
  /** Búsquedas con carga de resultados */
  SEARCH: 25000,
} as const;

/**
 * URLs principales del sitio para evitar repetir valores en los tests.
 */
export const URLS = {
  BASE: RUNTIME_CONFIG.baseURL,
  HOME: '/lightning/page/home',
  SALESFORCE_HOME_ENTRY: RUNTIME_CONFIG.salesforceHomeUrl,
} as const;

/**
 * Pausas cortas que solo se usan cuando no hay una alternativa más fiable.
 */
export const WAIT_TIMES = {
  /** Minimal wait after accepting cookies */
  AFTER_COOKIES: 500,
  /** Espera antes de iniciar búsqueda */
  BEFORE_SEARCH: 1000,
} as const;

// Puntos de ruptura reutilizados por los escenarios y utilidades de UI.
export const BREAKPOINTS = {
  MOBILE: 375,
  TABLET: 768,
  DESKTOP: 1920,
} as const;