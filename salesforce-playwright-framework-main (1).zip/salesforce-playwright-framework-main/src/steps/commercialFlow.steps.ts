import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PageFactory } from '../utils/page-factory';

//─────── Pasos Compartidos) ───────
// Ejecuta la navegación al menú para el flujo comercial.
When('the user clicks the {string} menu in Salesforce', async function (menuName: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.clickCommercialFlowMenu(menuName);
});

// Abre el formulario correcto según si el escenario crea prospecto u oportunidad.
When('the user clicks the {string} button on the Commercial Flow screen', async function (buttonTitle: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  
  // Este IF permite que el mismo paso funcione para el escenario del prospecto Y el de la oportunidad
  if (buttonTitle.toLowerCase().includes('oportunidad') || buttonTitle.toLowerCase().includes('opportunity')) {
    await commercialPage.clickCreateOpportunityButton(buttonTitle);
  } else {
    await commercialPage.clickCreateProspectButton(buttonTitle);
  }
});


//─────── Pasos Exclusivos de Prospecto ───────
// Selecciona el tipo de identificación del prospecto.
When('the user selects {string} in the Identification Type field', async function (idType: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.selectProspectIdentificationType(idType);
});

// Completa el número de identificación del prospecto.
When('the user enters {string} in the Identification Number field', async function (identification: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectIdentification(identification);
});

// Completa el nombre del prospecto.
When('the user enters {string} in the First Name field', async function (firstName: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectFirstName(firstName);
});

// Completa el segundo nombre del prospecto.
When('the user enters {string} in the Middle Name field', async function (secondName: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectSecondName(secondName);
});

// Completa el primer apellido del prospecto.
When('the user enters {string} in the First Last Name field', async function (lastName: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectFirstLastName(lastName);
});

// Completa el segundo apellido del prospecto.
When('the user enters {string} in the Second Last Name field', async function (secondLastName: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectSecondLastName(secondLastName);
});

// Completa el teléfono del prospecto.
When('the user enters {string} in the Phone field', async function (phone: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectPhone(phone);
});

// Completa el correo del prospecto.
When('the user enters {string} in the Salesforce prospect email field', async function (email: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectEmail(email);
});

// Selecciona la línea de negocio del prospecto.
When('the user selects {string} in the Business Line field', async function (businessLine: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.selectProspectBusinessLine(businessLine);
});

// Completa el broker o sponsor del prospecto.
When('the user enters {string} in the Broker \\/ Sponsor field', async function (broker: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectBroker(broker);
});

// Completa la prima estimada del prospecto.
When('the user enters {string} in the Estimated Premium field', async function (premium: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectEstimatedPremium(premium);
});

// Completa los días de vigencia del prospecto.
When('the user enters {string} in the Validity Days field', async function (days: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.fillProspectValidityDays(days);
});

// Selecciona una sucursal y la mueve al listado de elegidas.
When('the user selects {string} in the Branch Options and moves it to Selected', async function (branch: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.selectRandomBranchAndMoveToSelected(branch);
});

// Verifica que el prospecto se haya creado correctamente.
When('the Salesforce prospect should be created successfully showing a confirmation message', async function () {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  const isCreated = await commercialPage.isProspectCreatedSuccessfully();
  expect(isCreated, 'Expected the prospect to be created successfully with a confirmation message').toBeTruthy();
});

// Verifica que la aplicación redirigió al detalle del prospecto creado.
Then('the system should automatically redirect to the created Salesforce prospect screen', async function () {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  const isRedirected = await commercialPage.isRedirectedToCreatedProspectScreen();
  expect(isRedirected, 'Expected the system to redirect to the created prospect details screen').toBeTruthy();
});


//─────── Pasos Exclusivos de Oportunidad ───────
// Busca y selecciona un prospecto para continuar con la oportunidad.
When('the user enters {string} in the Search Identification Number or Prospect Name field', async function (searchTerm: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  await commercialPage.searchAndSelectProspect(searchTerm);
});

// Pulsa el botón principal del flujo de oportunidad o guarda el registro.
When('the user clicks the {string} button', async function (buttonName: string) {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  
  if (buttonName.toLowerCase() === 'seleccionar' || buttonName.toLowerCase() === 'select') {
     await commercialPage.clickSelectButton(buttonName);
  } else {
     await commercialPage.saveRecord(buttonName); // Sirve también para Oportunidad
  }
});

// Verifica que la oportunidad se creó y que existe una confirmación visible.
Then('the Salesforce opportunity should be created successfully showing a confirmation message', async function () {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  
  const actualMessage = await commercialPage.getNotificationMessage();
  console.log(`Mensaje capturado en pantalla: "${actualMessage}"`);

  // Si no capturó texto por el DOM pero la URL ya cambió al registro creado, consideramos la prueba ok
  const currentUrl = this.page.url();
  const isCreated = actualMessage.length > 0 || currentUrl.includes('SDP_OpportunityLead__c') || currentUrl.includes('/lightning/r/');
  
  expect(isCreated, 'Expected opportunity to be created successfully').toBeTruthy();
});

// Verifica que la aplicación redirigió al detalle de la oportunidad creada.
Then('the system should automatically redirect to the created Salesforce opportunity screen', async function () {
  const commercialPage = PageFactory.getSalesforceCommercialFlowPage(this, this.page);
  const isRedirected = await commercialPage.isRedirectedToCreatedOpportunityScreen();
  expect(isRedirected, 'Expected the system to redirect to the created opportunity details screen').toBeTruthy();
});