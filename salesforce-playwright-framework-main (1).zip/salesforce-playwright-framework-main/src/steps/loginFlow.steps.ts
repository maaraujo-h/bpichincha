import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PageFactory } from '../utils/page-factory';
import { logger } from '../utils/logger';
import { RUNTIME_CONFIG } from '../config/runtime.config';

const SALESFORCE_LOGIN_TIMEOUT_MS = Math.max(150_000, RUNTIME_CONFIG.manualOtpTimeoutMs + 60_000);

// Abre la pantalla de entrada.
Given('the user opens the Salesforce home entry page', async function () {
  logger.info('Opening Salesforce home entry page');
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  await salesforceLoginPage.navigateToHomeEntry();
  await salesforceLoginPage.logLandingSummary();
});

// Garantiza que la sesión esté autenticada antes de seguir con los escenarios.
Given('the user is authenticated in Salesforce', { timeout: SALESFORCE_LOGIN_TIMEOUT_MS }, async function () {
  logger.info('Ensuring authenticated Salesforce session');
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  await salesforceLoginPage.navigateToHomeEntry();
  // Usamos la configuración del entorno para saber si debe esperar por el OTP manual o no
  await salesforceLoginPage.loginWithConfiguredCredentials(RUNTIME_CONFIG.allowManualOtp);
});

// Comprueba que el formulario de login sigue visible.
Then('the Salesforce login page should be visible', async function () {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  const isVisible = await salesforceLoginPage.isLoginPageVisible();
  expect(isVisible, 'Expected Salesforce login page to be visible').toBeTruthy();
});

// Valida que la URL actual contiene el texto esperado.
Then('the URL should contain {string}', async function (expectedText: string) {
  const currentUrl = this.page.url();
  expect(currentUrl).toContain(expectedText);
});

// Verifica que exista una acción principal disponible en el login.
Then('a primary Salesforce action should be visible', async function () {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  const isPrimaryActionVisible = await salesforceLoginPage.isPrimaryActionVisible();
  expect(isPrimaryActionVisible, 'Expected login/continue primary action to be visible').toBeTruthy();
});

// Verifica que el campo de usuario esté visible.
Then('the Salesforce username input should be visible', async function () {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  const hasUsernameInput = await salesforceLoginPage.isUsernameInputVisible();
  expect(hasUsernameInput, 'Expected username input on Salesforce login page').toBeTruthy();
});

// Inicia sesión con las credenciales definidas en el entorno.
When('the user signs in to Salesforce with configured credentials', { timeout: SALESFORCE_LOGIN_TIMEOUT_MS }, async function () {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  await salesforceLoginPage.loginWithConfiguredCredentials(true);
});

// Verifica que la portada de Lightning esté visible tras el login.
Then('the Salesforce lightning home should be visible', async function () {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  const isHomeVisible = await salesforceLoginPage.isLightningHomeVisible();
  expect(isHomeVisible, 'Expected Salesforce Lightning home after login').toBeTruthy();
});

// Intenta iniciar sesión con credenciales concretas para escenarios negativos.
When('the user attempts to sign in with username {string} and password {string}', async function (username: string, password: string) {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  await salesforceLoginPage.attemptLoginWithCredentials(username, password);
});

// Verifica que aparezca un mensaje de error de autenticación.
Then('an authentication error message should be visible', async function () {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  const isErrorVisible = await salesforceLoginPage.isLoginErrorVisible();
  
  // Aserción: si no aparece el error, el test falla
  expect(isErrorVisible, 'Expected login error message to be visible on the screen').toBeTruthy();
});