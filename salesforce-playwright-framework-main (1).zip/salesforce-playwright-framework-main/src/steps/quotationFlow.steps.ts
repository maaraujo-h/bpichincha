import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PageFactory } from '../utils/page-factory';

// Abre el menú indicado dentro del flujo de cotización.
When('the user accesses the {string} menu in Salesforce', async function (menuName: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.clickMenu(menuName);
});

// Escribe el identificador del cliente en la búsqueda.
When('the user enters {string} in the client search field', async function (identification: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.searchClient(identification);
});

// Pulsa el botón de búsqueda de la pantalla de cotización.
When('the user clicks the {string} button on the quotation screen', async function (btnName: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.clickSearchButton();
});

// Selecciona a la persona encontrada por su identificación.
When('the user selects the found person with identification {string}', async function (identification: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectFoundPerson(identification);
});

// Pulsa un botón genérico del formulario de cotización.
When('the user clicks the {string} button in the quotation form', async function (btnName: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.clickGenericButton(btnName);
});

// Selecciona una enfermedad y la mueve a la lista de seleccionadas.
When('the user selects the disease {string} in the options and moves it to selected', async function (diseaseName: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.moveNewPreexistences(diseaseName);
});

// Completa el campo de preexistencia.
When('the user enters {string} in the Preexistence field', async function (text: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.fillPreexistence(text);
});

// Completa la fecha actual en el campo de tratamiento.
When('the user enters the current date in the treatment date field', async function () {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.fillTreatmentDate();
});

// Completa el campo de tratamiento u observación.
When('the user enters {string} in the Treatment or Observation field', async function (text: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.fillObservations(text);
});

// Selecciona una opción en el combo de tipo de venta.
When('the user selects {string} in the sales type combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Tipo de venta', option);
});

// Selecciona una opción en el combo de producto.
When('the user selects {string} in the product combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Producto', option);
});

// Selecciona una opción en el combo de plan.
When('the user selects {string} in the Plan combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Plan', option);
});

// Selecciona una opción en el combo de frecuencia de pago.
When('the user selects {string} in the payment frequency combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Frecuencia de pago', option);
});

// Marca o desmarca la opción de titular de la cuenta.
When('the user marks the account holder option as {string}', async function (isHolder: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.checkAccountHolder(isHolder);
});

// Selecciona una opción en el combo de medios.
When('the user selects {string} in the Methods combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Medios', option);
});

// Selecciona una opción en el combo de bancos.
When('the user selects {string} in the Banks combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Bancos', option);
});

// Completa el número de cuenta.
When('the user enters {string} in the Account Number field', async function (accNumber: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.fillAccountNumber(accNumber);
});

// Abre la búsqueda de beneficiarios.
When('the user clicks the {string} button to assign a beneficiary', async function (btnName: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.clickSearchBeneficiaryButton();
});

// Selecciona el primer beneficiario de la lista de resultados.
When('the user selects the first beneficiary from the results list', async function () {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectFirstBeneficiary();
});

// Añade la relación seleccionada.
When('the user clicks the {string} button for the relationship', async function (btnName: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.clickAddButton();
});

// Selecciona el parentesco en el combo.
When('the user selects the relationship {string} in the combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Parentezco', option);
});

// Selecciona una opción en el combo de participación y beneficio.
When('the user selects {string} in the Participation and Benefit combobox', async function (option: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.selectComboboxOption('Part./Benef.', option);
});

// Gestiona la firma delegada con el método indicado.
When('the user manages the delegated signature using the {string} method', async function (method: string) {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  await quotationPage.handleDelegatedSignature(method);
});

// Verifica que la pantalla final de confirmación de la firma delegada esté visible.
Then('the system should transition to the delegated signature confirmation screen', async function () {
  const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
  
  const successMessage = this.page.locator('text="Operación correcta"').first();
  await expect(successMessage).toBeVisible({ timeout: 10000 });
});