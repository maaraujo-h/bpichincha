# 🚀 Salesforce SdP - Framework E2E

**Framework de automatización E2E para Salesforce Seguros del Pichincha (SdP)** con Playwright, BDD (Cucumber) y Page Object Model (POM).

> ⚡ **Velocidad optimizada**: Ejecución completa de escenarios Salesforce en ~30-45 segundos

## 📋 Índice

- [🎯 Inicio Rápido](#-inicio-rápido)
- [✨ Características](#-características)
- [📦 Instalación](#-instalación)
- [🚀 Ejecución de Tests](#-ejecución-de-tests)
- [📚 Documentación](#-documentación)

---

## 🎯 Inicio Rápido

```powershell
# 1. Instalar dependencias
npm install

# 2. Instalar navegadores
npm run playwright:install

# 3. Configurar credenciales Salesforce
# Crea un archivo .env en la raíz y añade las variables de Salesforce

# 4. Ejecutar tests
npm test -- --tags "@salesforce"
```

**Siguiente paso**: Lee [docs/GETTING-STARTED.md](docs/GETTING-STARTED.md)

---

## ✨ Características

### 🎯 Core Automation

- ✅ **Playwright Hardened** - Anti-detección configurado
- ✅ **BDD con Cucumber** - Tests en Gherkin (inglés)
- ✅ **Page Object Model** - Código mantenible y escalable
- ✅ **TypeScript Strict** - Tipado estático completo
- ✅ **Configuración Centralizada** - Timeouts, URLs, browser config

### 🔐 Salesforce-Específico

- ✅ **Autenticación Multiframe** - Soporte para Lightning
- ✅ **MFA/OTP Handling** - Gestión automática de OTP
- ✅ **Storage State Persistence** - Reutilización de sesiones
- ✅ **Sandbox Lightning** - Optimizado para sandbox de Salesforce

### 🔌 Integraciones

- ✅ **Jira MCP (Opcional)** - Lectura de tickets via Copilot
- ✅ **Playwright MCP** - Generación de selectores robustos
- ✅ **Winston Logger** - Logging estructurado

---

## 📦 Instalación

### Requisitos

- **Node.js**: >= 18.0.0
- **npm**: >= 9.0.0
- **Git**: Para control de versiones

### Pasos

```powershell
# 1. Instalar dependencias
npm install

# 2. Instalar Playwright
npm run playwright:install

# 3. Configurar variables de entorno
cp .env.example .env

# Edita .env con credenciales de Salesforce
```

---

## 🚀 Ejecución de Tests

### Comandos Principales

```powershell
# Todos los tests (headless)
npm test

# Con navegador visible
npm run test:headed

# Con debugging
npm run test:debug

# Solo tests Salesforce
npm run test:salesforce

# Bootstrap de autenticación (guardar sesión)
npm run salesforce:auth:bootstrap
```

### Por Tags

```powershell
npm test -- --tags "@smoke"
npm test -- --tags "@critical"
npm test -- --tags "@auth"
npm test -- --tags "@salesforce and @smoke"
```

### Feature Específico

```powershell
npx cucumber-js features/salesforce-login-flow/salesforce-login.feature
```

---

## 📚 Documentación

| Documento | Descripción |
|-----------|-------------|

| [docs/GETTING-STARTED.md](docs/GETTING-STARTED.md) | Guía paso-a-paso |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Estructura y patrones |
| [docs/CODING-STANDARDS.md](docs/CODING-STANDARDS.md) | Estándares de código |
| [docs/DEBUG-CHEATSHEET.md](docs/DEBUG-CHEATSHEET.md) | Debugging rápido |
| [docs/SALESFORCE-SPECIFICS.md](docs/SALESFORCE-SPECIFICS.md) | Detalles Salesforce |
| [docs/SELECTOR-VERIFICATION.md](docs/SELECTOR-VERIFICATION.md) | Verificar selectores |
| [docs/CI-CD-SETUP.md](docs/CI-CD-SETUP.md) | GitHub Actions |
| [docs/PROXY-CONFIG.md](docs/PROXY-CONFIG.md) | Proxy corporativo |

---

## 📁 Estructura

```Text
salesforce-SdP-framework/
├── features/
│   ├── salesforce-login-flow/
│   ├── salesforce-commercial-flow/
│   └── salesforce-quotation-flow/
├── src/
│   ├── config/          (browser, runtime)
│   ├── pages/           (Page Objects Salesforce)
│   ├── steps/           (Step Definitions)
│   ├── support/         (Hooks)
│   ├── types/           (Definiciones TS)
│   └── utils/           (logger, constants, factory)
├── docs/                (Documentación)
├── .env.example         (Variables de entorno)
└── package.json         (Dependencias)
```

---

## 🔐 Configuración de Credenciales

Edita `.env`:

```env
# Salesforce Credentials
SALESFORCE_USERNAME=your-username@sandbox.com
SALESFORCE_PASSWORD=your-password

# Salesforce URLs
SALESFORCE_URL=https://tu_empresa.net.lightning.force.com/lightning/page/home

# OTP Settings
SALESFORCE_ALLOW_MANUAL_OTP=true
SALESFORCE_MANUAL_OTP_TIMEOUT_MS=120000

# Session Persistence
SALESFORCE_USE_STORAGE_STATE=true
SALESFORCE_SAVE_STORAGE_STATE=true

# Reporting
SCREENSHOT_ON_FAILURE=true
TRACE_ON_FAILURE=true
```

---

## 🛠️ Scripts Disponibles

```powershell
npm test                           # Tests headless
npm run test:headed                # Con navegador
npm run test:debug                 # Con Inspector
npm run test:salesforce            # Solo Salesforce
npm run salesforce:auth:bootstrap  # Guardar sesión
npm run type-check                 # Verificar TS
```

---

## 🚦 Inicio Rápido - Tu Primer Test

**Tiempo**: ~5 minutos

1. Lee [docs/GETTING-STARTED.md](docs/GETTING-STARTED.md)
2. Configura `.env` con credenciales Salesforce
3. Ejecuta: `npm run test:headed -- --tags "@smoke"`
4. Observa Chromium ejecutando tests

---

## 🤝 Contribuir

Antes de commit:

- `npm run type-check` - Verificar tipos
- `npm test` - Ejecutar tests
- Lee [docs/CODING-STANDARDS.md](docs/CODING-STANDARDS.md)

---

## 📞 Soporte

1. Lee la documentación en `docs/`
2. Consulta [docs/DEBUG-CHEATSHEET.md](docs/DEBUG-CHEATSHEET.md)
3. Abre una issue en el repositorio

---

**Última actualización**: Julio 2026 | **Versión**: 1.0.0 | **Mantenedor**: QA Team
