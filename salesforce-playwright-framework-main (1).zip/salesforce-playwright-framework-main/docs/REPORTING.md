# 📊 Sistema de Reportes

## Descripción General

El proyecto genera reportes de ejecución mediante los formatters nativos de
Cucumber, configurados en [cucumber.js](../cucumber.js). No existe (todavía)
un generador de dashboard propio: esta guía describe únicamente lo que el
framework produce hoy.

## 📁 Reportes Generados

Cada ejecución (`npm test`, `npm run test:full`, etc.) escribe en
`cucumber-report/`:

| Archivo | Formato | Uso típico |
|---------|---------|------------|
| `cucumber-report.html` | HTML autocontenido | Revisión visual local, desglose por feature/step |
| `cucumber-report.json` | JSON (formato Cucumber) | Integraciones (Xray, herramientas de terceros) |
| `cucumber-report.xml` | JUnit XML | Publicación de resultados en CI/CD (GitHub Actions, Azure DevOps, etc.) |

Adicionalmente, Playwright genera su propio reporte HTML (`playwright-report/`)
y un JSON de resultados (`test-results/results.json`), configurados en
[playwright.config.ts](../playwright.config.ts).

En fallos, según los flags `SCREENSHOT_ON_FAILURE` / `TRACE_ON_FAILURE` del
`.env`, se adjuntan capturas al reporte de Cucumber y se guardan trazas en
`traces/`.

## 🚀 Uso

```powershell
npm test                 # Ejecuta los tests y genera los reportes anteriores
start cucumber-report/cucumber-report.html   # Abrir el reporte HTML de Cucumber
start playwright-report/index.html           # Abrir el reporte HTML de Playwright
```

## 📈 Integración con CI/CD

El workflow [`.github/workflows/e2e-tests.yml`](../.github/workflows/e2e-tests.yml)
ya sube estos artefactos automáticamente tras cada ejecución:

- `cucumber-report/` y `test-results/` (30 días de retención)
- `playwright-report/` (30 días de retención)
- `traces/` solo si la ejecución falla (7 días de retención)

### Trazabilidad con Jira/Xray

Ver la sección "Trazabilidad Jira/Xray" en
[`.github/workflows/README.md`](../.github/workflows/README.md): si se
configuran los secrets `XRAY_CLIENT_ID`/`XRAY_CLIENT_SECRET`, el propio
`cucumber-report.json` se importa automáticamente a Xray Cloud como una Test
Execution al final del job `test`.

## 🔮 Roadmap (no implementado)

Estas ideas se han planteado para el futuro, pero **no existen todavía** en el
código (no hay script `test:report`, ni `report-generator.ts`, ni dependencia
de `cucumber-html-reporter`/`Chart.js` en `package.json`). Si se decide
construirlas, deberían añadirse como una nueva utilidad en `src/utils/` con su
propio script en `package.json`:

- Dashboard interactivo con métricas de éxito/duración y gráficos (Chart.js)
- Detección automática de fallos recurrentes agrupados por mensaje de error
- Comparación de tendencias entre ejecuciones
- Notificaciones (email/Slack) con resumen de ejecución

## 📚 Referencias

- [Cucumber JSON Format](https://github.com/cucumber/cucumber-json-schema)
- [Playwright HTML Reporter](https://playwright.dev/docs/test-reporters#html-reporter)

---

**¿Preguntas o sugerencias?** Contacta al equipo de QA.
