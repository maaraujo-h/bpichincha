# 🔐 Salesforce-Specifics - Detalles Técnicos

Documentación técnica de aspectos específicos de Salesforce implementados en este framework.

---

## 📋 Tabla de Contenidos

1. [Autenticación Multiframe](#autenticación-multiframe)
2. [OTP/MFA Handling](#otpmfa-handling)
3. [Storage State Persistence](#storage-state-persistence)
4. [Lightning DOM Inspection](#lightning-dom-inspection)
5. [Selectores Salesforce](#selectores-salesforce)

---

## 🔐 Autenticación Multiframe

### Problema

Salesforce Lightning usa iframes para componentes específicos. Los selectores deben buscar tanto en la página principal como en frames anidados.

### Solución Implementada

#### En `src/pages/loginFlowPage.ts`:

```typescript
private async getFirstVisibleLocatorInPageAndFrames(
  candidates: string[]
): Promise<Locator | undefined> {
  // Busca en página principal
  for (const selector of candidates) {
    const locator = this.page.locator(selector);
    if (await locator.isVisible().catch(() => false)) {
      return locator;
    }
  }

  // Busca en frames
  const frameHandles = await this.page.evaluate(() => {
    return Array.from(document.querySelectorAll('iframe')).map(
      (iframe) => iframe.src || 'frame'
    );
  });

  for (const frameHandle of frameHandles) {
    const frame = this.page.frameLocator(`iframe[src*="${frameHandle.split('/').pop()}"]`);
    for (const selector of candidates) {
      const locator = frame.locator(selector);
      if (await locator.isVisible().catch(() => false)) {
        return locator;
      }
    }
  }

  return undefined;
}
```

### Uso en Steps

```typescript
Given('the user opens the Salesforce home entry page', async function () {
  const salesforceLoginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  await salesforceLoginPage.navigateToHomeEntry();
  // Internamente usa multiframe logic
});
```

---

## 🔑 OTP/MFA Handling

### Configuración

En `.env`:

```env
SALESFORCE_ALLOW_MANUAL_OTP=true
SALESFORCE_MANUAL_OTP_TIMEOUT_MS=120000
```

### Flujo Automático

```
1. Envía credenciales
   ↓
2. Salesforce solicita OTP
   ↓
3. Si ALLOW_MANUAL_OTP=true:
   - Pausa la ejecución
   - Permite entrada manual del OTP
   - Espera 120 segundos (configurable)
   ↓
4. Continúa ejecución
   ↓
5. Valida que login fue exitoso
```

### Código en `src/pages/loginFlowPage.ts`

```typescript
async loginWithConfiguredCredentials(allowManualOtp: boolean): Promise<void> {
  // 1. Llenar credenciales
  await this.fillUsername(RUNTIME_CONFIG.username);
  await this.fillPassword(RUNTIME_CONFIG.password);
  
  // 2. Hacer click en la acción principal
  await this.clickPrimaryAction();
  
  // 3. Esperar login, home o OTP
  const landing = await Promise.race([
    this.isOtpChallengeVisible().then((visible) => (visible ? 'otp' : null)),
    this.isLightningHomeVisible().then((visible) => visible ? 'home' : 'login'),
  ]);
  
  // 4. Si OTP y está permitido, esperar entrada manual
  if (landing === 'otp' && allowManualOtp) {
    logger.info('Esperando completado manual de OTP...');
    await this.page.pause(); // Espera entrada del usuario
  }
  
  // 5. Guardar sesión si está configurado
  if (RUNTIME_CONFIG.saveSalesforceStorageState) {
    // La sesión se persiste desde el Page Object cuando se alcanza Lightning home.
  }
}
```

### Uso en Tests

```gherkin
Given the user is authenticated in Salesforce
When the user signs in to Salesforce with configured credentials
```

---

## 💾 Storage State Persistence

### ¿Qué es Storage State?

Es un archivo JSON que guarda:
- Cookies de sesión
- LocalStorage
- SessionStorage
- Estado de autenticación

### Beneficio

En lugar de hacer login en cada test (~30 segundos), reutilizamos la sesión guardada (~2 segundos).

### Configuración

En `.env`:

```env
SALESFORCE_USE_STORAGE_STATE=true
SALESFORCE_SAVE_STORAGE_STATE=true
SALESFORCE_STORAGE_STATE_PATH=storage-state/salesforce-auth.json
```

### Proceso

#### Primera Ejecución

```
1. npm run salesforce:auth:bootstrap
2. Sistema ejecuta scenario @auth
3. Completa login (con OTP manual si es necesario)
4. Guarda sesión en storage-state/salesforce-auth.json
5. File se crea automáticamente
```

#### Ejecuciones Posteriores

```
1. hooks.ts carga storage state antes de abrir el escenario
2. Tests no necesitan hacer login
3. Navegación directa a página solicitada
4. Ahorro: ~30 segundos por escenario
```

### Archivos Relacionados

**`src/support/hooks.ts`**:
```typescript
const storageStatePath = path.resolve(RUNTIME_CONFIG.salesforceStorageStatePath);
const hasStorageState =
  !isGuest && RUNTIME_CONFIG.useSalesforceStorageState && fs.existsSync(storageStatePath);

context = await browser.newContext({
  storageState: hasStorageState ? storageStatePath : undefined,
});
```

**`runtime.config.ts`**:
```typescript
export const RUNTIME_CONFIG = {
  useSalesforceStorageState: process.env.SALESFORCE_USE_STORAGE_STATE === 'true',
  saveSalesforceStorageState: process.env.SALESFORCE_SAVE_STORAGE_STATE === 'true',
  salesforceStorageStatePath: process.env.SALESFORCE_STORAGE_STATE_PATH || 'storage-state/salesforce-auth.json',
};
```

---

## 🔍 Lightning DOM Inspection

### Estructura Típica de Salesforce Lightning

```html
<!-- Navbar -->
<div class="lightning-container">
  <lightning-nav-bar></lightning-nav-bar>
</div>

<!-- App Container -->
<div id="lightning-app-container">
  <!-- Frames anidados -->
  <iframe name="branding-frame"></iframe>
  <iframe name="workspace-frame"></iframe>
</div>

<!-- Modales -->
<div class="uiModal"></div>
```

### Selectores Robustos

En lugar de:
```typescript
// ❌ Frágil - se rompe con cambios de clase
'.navbar .button'
```

Usa:
```typescript
// ✅ Robusto - usa data-testid o role
'[data-testid="logout-btn"]'
getByRole('button', { name: /logout/i })
```

### Ejemplos en Código

**`src/pages/loginFlowPage.ts`**:
```typescript
private readonly selectors = {
  usernameByCss: '#username, input[name="username"], input[type="email"]',
  passwordByCss: '#password, input[name="pw"], input[type="password"]',
  loginButtonByCss: '#Login, input[type="submit"][value*="Log In"]',
  lightningHeaderByCss: 'div.slds-global-header, one-appnav',
};
```

---

## 🎯 Selectores Salesforce

### Jerarquía de Preferencia

1. **data-testid** (IDEAL - explícito)
   ```typescript
   '#Login'
   ```

2. **getByRole** (ACCESIBLE - semántico)
   ```typescript
   page.getByRole('button', { name: /guardar|save/i })
   ```

3. **getByLabel/getByText** (FLEXIBLE - texto)
   ```typescript
   page.getByLabel('Username')
   page.getByText('Log In')
   ```

4. **locator CSS** (ÚLTIMOS RECURSOS)
   ```typescript
   '.slds-button_brand'
   ```

### Patrones de Fallback

```typescript
// Array de candidatos - usa el primero que funcione
private readonly buttonCandidates = [
  '[data-testid="save-btn"]',               // Preferido
  page.getByRole('button', { name: /guardar|save/i }), // Accesible
  'button:has-text("Guardar")',             // Fallback
  '.slds-button_brand',                     // Último recurso
];

async clickFinalizeButton(): Promise<void> {
  const locator = await this.getFirstVisibleLocator(
    this.buttonCandidates
  );
  if (!locator) throw new Error('Finalize button not found');
  await locator.click();
}
```

---

## 🧪 Testing con Selectores

### Verificar Selector Manualmente

En `npm run test:headed`:

```powershell
# Abre navegador, pausa, permite inspeccionar
npm run test:headed -- --tags "@mytest"
# Presiona F10 en VS Code o Inspector para step-by-step
```

### Verificar con Playwright Inspector

```powershell
$env:PWDEBUG=1; npm test -- --tags "@salesforce"
```

En el Inspector:

1. Paste selector en "Evaluate in console"
2. Ve si retorna elementos
3. Verifica si son visibles

### Script de Test

```typescript
// Crear archivo: tests/selector-check.spec.ts
import { test, expect } from '@playwright/test';

test('Verificar selectores Salesforce', async ({ page }) => {
  await page.goto('https://tu_empresa.net.lightning.force.com/lightning/page/home');
  
  // Verificar logotipo
  const login = page.locator('#username');
  await expect(login).toBeVisible();
  
  // Verificar username input
  const username = page.locator('input[name="username"]');
  await expect(username).toBeVisible();
});
```

---

## 🔧 Troubleshooting

### ❌ "OTP Input Not Found"

**Causa**: Frame diferente o selector incorrecto

**Solución**:
1. Ejecutar con `npm run test:headed`
2. Inspeccionar elemento
3. Actualizar selector en `src/pages/loginFlowPage.ts`

### ❌ "Storage State Expired"

**Causa**: Sesión expiró (típicamente después de 2-3 días)

**Solución**:
```powershell
# Regenerar storage state
npm run salesforce:auth:bootstrap
```

### ❌ "Cannot Find Element in Frame"

**Causa**: Selector solo busca en página principal

**Solución**:
Usar método `getFirstVisibleLocatorInPageAndFrames()` que busca en todos los frames.

---

## 📊 Referencia Rápida

| Aspecto | Configuración | Archivo |
|--------|---------------|---------|
| **Credenciales** | `.env` | SALESFORCE_USERNAME, PASSWORD |
| **OTP** | `.env` | SALESFORCE_ALLOW_MANUAL_OTP |
| **Storage State** | `playwright.config.ts` | `storageState` option |
| **Selectores** | `src/pages/*.ts` | Private `selectors` object |
| **Timeouts** | `src/utils/constants.ts` | TIMEOUTS object |
| **Base URL** | `src/config/runtime.config.ts` | baseURL |

---

**Última actualización**: Julio 2026
