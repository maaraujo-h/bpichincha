# 📘 Estándares de Codificación - Playwright BDD POM Template

## 📅 Última actualización: 12 de Noviembre de 2025

---

## 🎯 Objetivo

Este documento define los **estándares de codificación obligatorios** para garantizar:

- ✅ Código mantenible y escalable
- ✅ Reutilización de componentes (steps, page objects)
- ✅ Trazabilidad a tickets de Jira sin acoplamiento
- ✅ Consistencia en todo el proyecto

---

## 🗂️ 1. Organización de Archivos

### 1.1 Features (Archivos Gherkin)

#### ❌ INCORRECTO
```
features/
├── login-flow/loginFlow.feature        # Usar nombres funcionales
├── commercial-flow/create-prospectFlow.feature
└── quotation-flow/quotationFlow.feature
```

#### ✅ CORRECTO
```
features/
├── login-flow/
│   └── loginFlow.feature
├── commercial-flow/
│   ├── create-prospectFlow.feature
│   └── create-opportunityFlow.feature
└── quotation-flow/
    └── quotationFlow.feature
```

**Reglas**:
1. Organiza en subdirectorios por **dominio funcional**
2. Usa nombres **descriptivos de la acción**, no IDs de tickets
3. Mantén referencia al ticket en **comentarios** y **tags** del feature
4. Máximo 10-15 escenarios por feature (divide si crece más)

---

### 1.2 Step Definitions

#### ❌ INCORRECTO
```
src/steps/
├── loginFlow.steps.ts
├── commercialFlow.steps.ts
└── quotationFlow.steps.ts
```

#### ✅ CORRECTO
```
src/steps/
├── cart.steps.ts                     # Nombrado según Page Object
├── search.steps.ts                   # Nombrado según Page Object
├── authentication.steps.ts           # Nombrado según funcionalidad
└── common.steps.ts                   # Steps reutilizables comunes
```

**Reglas**:
1. Nombra según el **Page Object relacionado** (e.g., `cart.steps.ts` para `CartPage`)
2. Agrupa steps por **funcionalidad común**
3. Documenta tickets relacionados en **JSDoc** (no en código ejecutable)
4. Reutiliza steps existentes antes de crear nuevos

---

### 1.3 Page Objects

#### ✅ ESTRUCTURA CORRECTA
```typescript
/**
 * Page Object para el flujo de login de Salesforce
 * 
 * Tickets relacionados:
 * - Login con credenciales configuradas
 * - Manejo de OTP/MFA
 * 
 * @see CartPage
 * @see ProductDetailPage
 */
export class LoginFlowPage extends BasePage {
  // 1. Selectores centralizados
  private readonly selectors = {
    usernameByCss: '#username, input[name="username"]',
    passwordByCss: '#password, input[name="pw"]',
  };

  // 2. Métodos de navegación
  async navigateToHomeEntry(): Promise<void> { }

  // 3. Métodos de espera
  async waitForLanding(): Promise<'login' | 'home'> { }

  // 4. Métodos de acción
  async loginWithConfiguredCredentials(allowManualOtp: boolean): Promise<void> { }

  // 5. Métodos de verificación (retornan boolean)
  async isLightningHomeVisible(): Promise<boolean> { }

  // 6. Métodos de obtención de datos
  async isOtpChallengeVisible(): Promise<boolean> { }
}
```

**Reglas**:
1. Todos los Page Objects **heredan de `BasePage`**
2. Selectores **centralizados** en objeto `selectors`
3. Métodos agrupados por categoría (navegación, espera, acción, verificación, datos)
4. **No hagas assertions** en Page Objects (solo retorna datos)
5. Documenta con **JSDoc** incluyendo tickets relacionados

---

## 🚫 2. Prohibiciones Críticas

### 2.1 NO Referencias a Tickets en Código Ejecutable

#### ❌ INCORRECTO - Referencias en código
```typescript
// En cart.steps.ts
When('el usuario busca {string}', async function (term: string) {
  logger.info(`KAN-1212: Ejecutando búsqueda: ${term}`);  // ¡NO!
  
  if (!hasProducts) {
    throw new Error('KAN-1212: No hay productos');        // ¡NO!
  }
  
  expect(count, 'KAN-1212: Falló').toBeGreaterThan(0);   // ¡NO!
});
```

#### ✅ CORRECTO - Código genérico reutilizable
```typescript
// En cart.steps.ts
/**
 * Step Definitions para operaciones de Carrito
 * 
 * Tickets relacionados:
 * - KAN-1212: Añadir producto desde PLP     ✅ En JSDoc
 * - KAN-1213: Eliminar producto del carrito
 * 
 * @see SearchResultsPage
 * @see CartPage
 */

When('el usuario busca {string}', async function (term: string) {
  logger.info(`Ejecutando búsqueda: ${term}`);           // ✅ Genérico
  
  if (!hasProducts) {
    throw new Error('No hay productos disponibles');     // ✅ Genérico
  }
  
  expect(count, 'Debería haber al menos 1 producto').toBeGreaterThan(0);  // ✅ Descriptivo sin ticket ID
});
```

**Razón**: Los steps son **código compartido** que se reutiliza en múltiples tickets. Un step puede usarse en KAN-1212, KAN-1213, KAN-1214, etc.

---

### 2.2 Lugares Permitidos para Referencias a Tickets

#### ✅ PERMITIDO: Comentarios JSDoc en archivos steps
```typescript
/**
 * Step Definitions para operaciones de Carrito
 * 
 * Tickets relacionados:
 * - KAN-1212: Añadir producto desde PLP
 * - KAN-1213: Eliminar producto
 */
```

#### ✅ PERMITIDO: Comentarios en features
```gherkin
# language: es
# Ticket: KAN-1212 - https://jira.../KAN-1212
@KAN-1212 @salesforce @auth
Característica: Añadir producto al carrito
```

#### ✅ PERMITIDO: Tags en features
```gherkin
@KAN-1212 @salesforce @commercial-flow @prospect
Escenario: Añadir primer producto al carrito
```

#### ❌ PROHIBIDO: Código ejecutable
- ❌ `logger.info('KAN-1212: ...')`
- ❌ `throw new Error('KAN-1212: ...')`
- ❌ `console.log('KAN-1212: ...')`
- ❌ `expect(x, 'KAN-1212: ...').toBe(y)`

---

## 📝 3. Logging y Mensajes

### 3.1 Logging Estratégico

#### ✅ CORRECTO - Mensajes genéricos descriptivos
```typescript
// En cart.steps.ts
When('el usuario hace clic en {string} del primer producto', async function (actionText: string) {
  logger.info(`Haciendo clic en "${actionText}" del primer producto`);
  
  const plp = PageFactory.getSearchResultsPage(this, this.page);
  
  const hasProducts = await plp.hasProducts();
  if (!hasProducts) {
    throw new Error('No hay productos disponibles para añadir al carrito');
  }
  
  const productTitle = await plp.getFirstProductTitle();
  logger.debug(`Producto a añadir: "${productTitle}"`);
  
  await plp.addFirstProductToCart();
  logger.info(`Producto "${productTitle}" añadido al carrito`);
});
```

**Características del logging correcto**:
- ✅ Mensajes descriptivos del **qué**, no del **ticket**
- ✅ Incluye variables relevantes (`actionText`, `productTitle`)
- ✅ Niveles apropiados: `info` para acciones principales, `debug` para detalles
- ✅ Reutilizable en cualquier contexto (múltiples tickets)

---

### 3.2 Mensajes de Error

#### ✅ CORRECTO - Errores descriptivos
```typescript
// Error claro y accionable
if (!hasProducts) {
  throw new Error('No hay productos disponibles para añadir al carrito');
}

if (productCount === 0) {
  throw new Error('La búsqueda no devolvió resultados. Verifica el término de búsqueda.');
}

if (!cartButton.isVisible()) {
  throw new Error('El botón del carrito no es visible en la página');
}
```

**Características de errores correctos**:
- ✅ Describen el **problema específico**
- ✅ Dan **contexto** sobre dónde ocurrió
- ✅ Sugieren **acción correctiva** cuando sea posible
- ✅ **No incluyen IDs de tickets**

---

### 3.3 Assertions con Mensajes Claros

#### ✅ CORRECTO - Assertions descriptivas
```typescript
expect(
  productCount,
  `Debería haber al menos ${minProducts} producto(s), pero se encontraron ${productCount}`
).toBeGreaterThanOrEqual(minProducts);

expect(
  cartCount,
  'El carrito debería contener al menos 1 producto'
).toBeGreaterThan(0);

expect(
  isVisible,
  'La confirmación de añadir al carrito debería ser visible'
).toBeTruthy();
```

**Características de assertions correctas**:
- ✅ Mensaje describe la **expectativa**
- ✅ Incluye **valores actuales** cuando sea útil
- ✅ Usa lenguaje de negocio (no técnico)
- ✅ **Sin IDs de tickets**

---

## 🔍 4. Selectores Robustos

### 4.1 Jerarquía de Preferencia

1. **`data-testid`** ⭐⭐⭐⭐⭐ (Más robusto)
2. **`getByRole`** ⭐⭐⭐⭐
3. **`getByText`** ⭐⭐⭐
4. **`getByLabel`** ⭐⭐⭐
5. **CSS específico** ⭐⭐
6. **XPath** ⭐ (Último recurso)

### 4.2 Ejemplos por Tipo

```typescript
// ✅ EXCELENTE - data-testid
await page.locator('[data-testid="add-to-cart-btn"]').click();

// ✅ MUY BUENO - getByRole con nombre accesible
await page.getByRole('button', { name: 'Añadir al carrito' }).click();

// ✅ BUENO - getByText para texto estático
await page.getByText('Iniciar sesión').click();

// ✅ BUENO - getByLabel para formularios
await page.getByLabel('Correo electrónico').fill('user@example.com');

// ⚠️ ACEPTABLE - CSS selector estable
await page.locator('.product-card__add-button').click();

// ❌ EVITAR - Selectores frágiles
await page.locator('div > div > button').click();  // Muy frágil
await page.locator('#btn-123').click();            // ID dinámico
```

---

## ✅ 5. Checklist Pre-Commit

Antes de hacer commit, verifica:

### Organización
- [ ] ✅ Feature en subdirectorio funcional (`features/cart/`, `features/search/`)
- [ ] ✅ Feature con nombre descriptivo (`add-product-from-plp.feature`)
- [ ] ✅ Steps nombrados según Page Object (`cart.steps.ts`)
- [ ] ✅ Steps no duplicados (busqué antes de crear)

### Código Limpio
- [ ] ✅ Logging sin IDs de tickets (`logger.info('Añadiendo producto')`)
- [ ] ✅ Errores sin IDs de tickets (`throw new Error('No hay productos')`)
- [ ] ✅ Assertions sin IDs de tickets en mensaje
- [ ] ✅ JSDoc completo en métodos públicos
- [ ] ✅ TypeScript estricto (sin `any`)

### Trazabilidad
- [ ] ✅ Referencia a ticket en comentario del feature (`# Ticket: KAN-1212`)
- [ ] ✅ Tags incluyen ID de ticket (`@KAN-1212`)
- [ ] ✅ JSDoc de steps documenta tickets relacionados
- [ ] ✅ Tests pasando localmente

---

## 📚 6. Recursos

- **Copilot Instructions**: `.github/copilot-instructions.md`
- **Refactor Summary**: `REFACTOR-SUMMARY.md`
- **MCP Workflow Guide**: `docs/MCP-WORKFLOW-GUIDE.md`
- **Ejemplo Completo**: `docs/KAN-1212-IMPLEMENTATION-SUMMARY.md`

---

## 🚨 7. Violaciones Comunes y Cómo Corregirlas

### ❌ Violación 1: Logging con ID de Ticket
```typescript
// INCORRECTO
logger.info('KAN-1212: Añadiendo producto al carrito');

// CORRECTO
logger.info('Añadiendo producto al carrito');
```

### ❌ Violación 2: Feature nombrado por Ticket
```bash
# INCORRECTO
features/KAN-1212-add-to-cart.feature

# CORRECTO
features/cart/add-product-from-plp.feature
# Con comentario: # Ticket: KAN-1212
```

### ❌ Violación 3: Steps nombrados por Ticket
```bash
# INCORRECTO
src/steps/KAN-1212.steps.ts

# CORRECTO
src/steps/cart.steps.ts
# Con JSDoc: Tickets relacionados: KAN-1212
```

### ❌ Violación 4: Error con ID de Ticket
```typescript
// INCORRECTO
throw new Error('KAN-1212: No hay productos disponibles');

// CORRECTO
throw new Error('No hay productos disponibles para añadir al carrito');
```

---

**Mantenido por**: Equipo de QA
**Versión**: 1.0.0  
**Fecha**: 12 de Noviembre de 2025
