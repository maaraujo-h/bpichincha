# 🔧 Guía de Configuración de MCPs

Esta guía explica cómo configurar y utilizar los Model Context Protocols (MCPs) en este proyecto.

## 📌 ¿Qué son los MCPs?

Los MCPs (Model Context Protocols) son servidores que permiten a GitHub Copilot acceder a contexto externo y herramientas adicionales para generar código más preciso y contextualizado.

## 🎭 MCP de Playwright (Microsoft)

### Descripción
**Paquete**: `@microsoft/mcp-server-playwright`

El MCP oficial de Microsoft Playwright proporciona capacidades avanzadas para:
- ✅ Navegación automática y captura de DOM en tiempo real
- ✅ Generación de selectores robustos desde páginas reales
- ✅ Inspección de elementos interactivos
- ✅ Capturas de screenshots y snapshots
- ✅ Interacción con elementos (click, type, fill)
- ✅ Debugging asistido con evidencias visuales

### ✅ Estado
- **Estado**: ✅ Operativo y verificado
- **Última prueba**: 2025-11-11 18:03
- **Funcionalidades probadas**: Navegación a Google, screenshot, snapshot DOM (136+ elementos)

### Configuración

Ya está configurado correctamente en `.vscode/mcp.json`:

```json
{
  "servers": {
    "microsoft/playwright-mcp": {
      "type": "stdio",
      "command": "npx",
      "args": ["@playwright/mcp@latest"]
    }
  }
}
```

**Nota**: El MCP de Playwright usa la última versión disponible (@latest) y se ejecuta localmente mediante stdio.

### Uso con Copilot

**Ejemplo 1: Generar selectores**
```
Prompt: "Usando el MCP de Playwright, genera un selector robusto para el botón principal del login de Salesforce"

Respuesta esperada:
- Selector con data-testid
- Fallback con role
- Esperas automáticas configuradas
```

**Ejemplo 2: Crear Page Object**
```
Prompt: "Crea un Page Object para el flujo de login de Salesforce usando mejores prácticas de Playwright"

Respuesta esperada:
- Clase con estructura correcta
- Selectores organizados
- Métodos con esperas adecuadas
```

**Ejemplo 3: Debugging**
```
Prompt: "Este selector no funciona: '.slds-button_brand'. Sugiere alternativas"

Respuesta esperada:
- Análisis del problema
- Selectores alternativos más robustos
- Estrategias de espera
```

## 🎫 MCP de Atlassian (Jira)

### Descripción
**Paquete**: `atlassian-mcp-server`

El MCP oficial de Atlassian permite:
- ✅ Leer issues y test cases directamente desde Jira (KAN-1212, etc.)
- ✅ Crear y actualizar issues
- ✅ Búsqueda avanzada con JQL
- ✅ Gestionar comentarios y transiciones
- ✅ Generar features de Gherkin desde tickets
- ✅ Sincronizar resultados de tests con Jira

### ✅ Estado
- **Estado**: ✅ Operativo y verificado
- **Última prueba**: 2025-11-11 18:03
- **Conexión**: plataformas.atlassian.net
- **Cloud ID**: 14768af6-ce1c-4dd3-b223-5eb3ed495dc3
- **Permisos**: `read:jira-work`, `write:jira-work`
- **Ticket verificado**: KAN-1212 leído exitosamente

### Configuración

Ya está configurado correctamente en `.vscode/mcp.json`:

```json
{
  "servers": {
    "atlassian/atlassian-mcp-server": {
      "type": "http",
      "url": "https://mcp.atlassian.com/v1/sse",
      "gallery": "https://api.mcp.github.com",
      "version": "1.0.0"
    }
  }
}
```

**Nota**: El MCP de Atlassian usa autenticación OAuth mediante conexión HTTP al servidor remoto de Atlassian. No requiere configurar tokens API manualmente.

### 🔐 Autenticación

**Autenticación OAuth**: El MCP de Atlassian utiliza autenticación OAuth integrada.

**Primera vez que uses el MCP**:
1. GitHub Copilot te solicitará autenticarte
2. Se abrirá una ventana del navegador
3. Inicia sesión con tu cuenta de Atlassian
4. Autoriza el acceso al MCP
5. La autenticación se guardará automáticamente

**Sitio Atlassian configurado**: https://plataformas.atlassian.net

**No se requiere configuración manual de tokens** - La autenticación OAuth se gestiona automáticamente mediante el servidor HTTP remoto de Atlassian.

### Uso con Copilot

**Ejemplo 1: Leer ticket específico**
```
@github Usando el MCP de Jira, lee el ticket KAN-1212 y muéstrame:
- Título
- Descripción
- Criterios de aceptación
- Estado actual
```

**Ejemplo 2: Generar test desde ticket**
```
@github Lee el ticket KAN-1212 de Jira y genera:
- Feature file en Gherkin (español)
- Steps definitions con PageFactory
- Page Object con selectores robustos
- Referencias al ticket en comentarios
```

**Ejemplo 3: Buscar tickets con JQL**
```
@github Usando el MCP de Jira, busca todos los tickets del proyecto KAN 
con estado "To Do" y tipo "Test"
```

**Ejemplo 4: Actualizar ticket**
```
@github Transiciona el ticket KAN-1212 a "In Progress" 
y añade un comentario: "Implementación de test automatizado iniciada"
- Assignee
```

**Ejemplo 3: Generar múltiples tests**
```
Prompt: "Lee todos los tickets del sprint actual del proyecto KAN y genera los test cases"

Respuesta esperada:
- Múltiples archivos .feature
- Steps compartidos en common.steps.ts
- Page Objects necesarios
```

**Ejemplo 4: Actualizar test existente**
```
Prompt: "El ticket KAN-1212 ha sido actualizado. Modifica el test correspondiente"

Respuesta esperada:
- Leer cambios del ticket
- Identificar test afectado
- Actualizar feature/steps según cambios
```

## 🔄 Workflow Recomendado

### 1. Inicio de Sprint

```
Prompt: "Lista todos los test cases del proyecto KAN del sprint actual"
```

### 2. Generación de Tests

```
Prompt: "Para cada ticket de testing del proyecto KAN, genera:
1. Feature file en Gherkin
2. Step definitions necesarios
3. Page Objects si no existen
4. Actualiza README con nuevos tests"
```

### 3. Mantenimiento

```
Prompt: "Revisa los tickets KAN-X, KAN-Y, KAN-Z y actualiza los tests si hay cambios"
```

## 🎯 Ejemplos Prácticos

### Caso 1: Test de Login desde Jira

**Ticket Jira (KAN-1212)**:
```
Título: Test E2E - Login de usuario
Descripción:
- Verificar login con credenciales válidas
- Verificar mensaje de error con credenciales inválidas
- Verificar redirección después de login
```

**Prompt a Copilot**:
```
"Lee el ticket KAN-1212 y genera un test completo con:
- Feature en Gherkin
- Steps
- LoginPage en POM
- Manejo de errores"
```

**Resultado esperado**:
- `features/login.feature`
- `src/steps/login.steps.ts`
- `src/pages/LoginPage.ts`

### Caso 2: Actualizar Test de Búsqueda

**Ticket actualizado (KAN-1212)**:
```
Se añade nuevo requisito:
- La búsqueda debe mostrar sugerencias mientras se escribe
```

**Prompt a Copilot**:
```
"El ticket KAN-1212 ha sido actualizado con un nuevo requisito sobre sugerencias.
Actualiza el test de búsqueda para incluir esta verificación"
```

**Resultado esperado**:
- Actualización de `features/search.feature`
- Nuevo step para verificar sugerencias
- Actualización de `SearchPage` con selector de sugerencias

## 🔐 Seguridad

### ⚠️ Autenticación OAuth

El MCP de Atlassian utiliza **autenticación OAuth**, por lo que no necesitas configurar tokens manuales ni credenciales en archivos de configuración.

**Ventajas de OAuth**:
- ✅ No hay tokens para gestionar manualmente
- ✅ No hay riesgo de commitear credenciales
- ✅ Autenticación segura mediante navegador
- ✅ Tokens gestionados automáticamente por el sistema

**Archivo seguro para commitear**:
- `.vscode/mcp.json` - ✅ **Seguro**: No contiene credenciales, solo configuración de servidores

## ✅ Verificación de MCPs

### Estado Actual (2025-11-11)

| MCP | Paquete | Estado | Última Prueba | Funcionalidades Verificadas |
|-----|---------|--------|---------------|----------------------------|
| **Playwright** | `@microsoft/mcp-server-playwright` | ✅ Operativo | 18:03 | Navegación, screenshots, DOM inspection |
| **Atlassian** | `atlassian-mcp-server` | ✅ Operativo | 18:03 | Lectura tickets KAN-1212, permisos verificados |

### Pruebas Realizadas

#### ✅ Playwright MCP
```javascript
// Navegación exitosa
await page.goto('https://www.google.com');
// URL actual: https://www.google.com/
// Título: "Google"

// Screenshot capturado
await page.screenshot({ path: 'test-mcp-playwright.png' });
// Guardado en: .playwright-mcp/test-mcp-playwright.png

// Snapshot DOM
const snapshot = await page.snapshot();
// 136+ elementos detectados
// Modal de cookies identificado correctamente
```

#### ✅ Atlassian MCP
```javascript
// Conexión verificada
const resources = await getAccessibleAtlassianResources();
// Cloud ID: 14768af6-ce1c-4dd3-b223-5eb3ed495dc3
// URL: https://plataformas.atlassian.net
// Permisos: read:jira-work, write:jira-work

// Lectura de ticket
const issue = await getJiraIssue({ issueIdOrKey: 'KAN-1212' });
// ✅ Título: "[MODA] PLP - Añadir producto..."
// ✅ Estado: To Do
// ✅ Descripción completa obtenida
// ✅ Precondiciones: 5 items
// ✅ Escenario detallado disponible
```

### Comandos de Verificación

#### Verificar Playwright MCP
```
@github Usando el MCP de Playwright, navega a https://www.google.com 
y toma un screenshot
```

#### Verificar Atlassian MCP
```
@github Usando el MCP de Jira, lee el ticket KAN-1212
```

## 🐛 Troubleshooting

### ❌ Playwright MCP no responde

**Síntomas**: El navegador no se abre o no responde

**Solución**:
1. Verificar que Playwright está instalado:
   ```powershell
   npm run playwright:install
   ```

2. Comprobar la configuración en `.vscode/settings.json`:
   ```json
   "playwright": {
     "command": "npx",
     "args": ["-y", "@microsoft/mcp-server-playwright"]
   }
   ```

3. Reiniciar VS Code

### ❌ Atlassian MCP: 401 Unauthorized

**Síntomas**: Error de autenticación con Jira

**Solución**:
1. El MCP de Atlassian usa autenticación OAuth, no tokens manuales
2. Si ves este error, intenta re-autenticarte:
   - GitHub Copilot te solicitará autenticación
   - Se abrirá una ventana del navegador
   - Inicia sesión con tu cuenta de Atlassian
   - Autoriza el acceso al MCP
3. Verifica que tu cuenta tiene acceso a: https://plataformas.atlassian.net
4. Si el problema persiste, revisa `.vscode/mcp.json` y verifica que la URL del servidor es correcta

### ❌ MCP no se ejecuta

**Síntomas**: Copilot no reconoce los MCPs

**Solución**:
1. Verificar que GitHub Copilot está instalado y activo
2. Comprobar que `.vscode/mcp.json` existe en la raíz del proyecto con la configuración correcta
3. Verificar la sintaxis JSON en `.vscode/mcp.json` (no debe tener errores)
4. Reiniciar VS Code completamente
5. Revisar logs: View > Output > GitHub Copilot
4. Verificar sintaxis JSON del archivo settings

### ❌ Error "command not found: npx"

**Síntomas**: npx no está instalado

**Solución**:
```powershell
# Verificar versión de Node.js (debe ser >= 18)
node --version

# Verificar versión de npm (debe ser >= 9)
npm --version

# Si es necesario, actualizar npm
npm install -g npm@latest
```

### Copilot no usa los MCPs

1. Verificar que GitHub Copilot está activo
2. Usar prompts explícitos: "Usando el MCP de Playwright..."
3. Verificar configuración en VS Code settings

## 📚 Recursos

- [MCP Documentation](https://modelcontextprotocol.io/)
- [Playwright MCP GitHub](https://github.com/microsoft/playwright-mcp)
- [Jira REST API](https://developer.atlassian.com/cloud/jira/platform/rest/v3/)
- [GitHub Copilot Docs](https://docs.github.com/copilot)

## 💡 Tips

1. **Sé específico**: Menciona el MCP explícitamente en tus prompts
2. **Usa contexto**: Referencia números de ticket Jira (KAN-1212)
3. **Itera**: Si la primera respuesta no es perfecta, refina el prompt
4. **Documenta**: Mantén este documento actualizado con nuevos casos de uso

---

**Última actualización**: Noviembre 2025
