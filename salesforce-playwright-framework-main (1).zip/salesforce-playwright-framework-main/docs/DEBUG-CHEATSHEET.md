# 🐛 Debugging Cheat Sheet - Referencia Rápida

## ⚡ Inicio Rápido

### Método 1: Debug con F5 (RECOMENDADO)
```
1. Abre feature file
2. F9 para poner breakpoints en steps
3. F5 → Selecciona "Debug Cucumber - Current Feature"
```

### Método 2: Terminal con Inspector
```powershell
$env:PWDEBUG=1; npm test -- features/tu-feature.feature
```

### Método 3: Navegador Visible
```powershell
$env:HEADLESS="false"; npm test -- --tags "@TU-TAG"
```

---

## 🎮 Controles de Debugging

| Tecla | Acción |
|-------|--------|
| **F5** | Continue (siguiente breakpoint) |
| **F10** | Step Over (siguiente línea) |
| **F11** | Step Into (entrar en función) |
| **Shift+F11** | Step Out (salir de función) |
| **F9** | Toggle breakpoint |
| **Shift+F5** | Stop debugging |

---

## 💻 Debug Console - Comandos Esenciales

### Contar Elementos
```javascript
await this.page.locator('selector').count()
```

### Ver Texto
```javascript
await this.page.locator('selector').textContent()
await this.page.locator('selector').allTextContents()
```

### Visibilidad
```javascript
await this.page.locator('selector').isVisible()
await this.page.locator('selector').isEnabled()
```

### Screenshots
```javascript
// Elemento
await this.page.locator('selector').screenshot({ path: 'debug.png' })

// Página completa
await this.page.screenshot({ path: 'debug.png', fullPage: true })
```

### Estado del Navegador
```javascript
// URL
this.page.url()

// Evaluar JS
await this.page.evaluate(() => ({
  title: document.title,
  url: window.location.href,
  elements: document.querySelectorAll('selector').length
}))
```

### Pausar Ejecución
```typescript
await this.page.pause() // Abre Playwright Inspector
```

---

## 🎯 Breakpoints Estratégicos

### En Steps (cart.steps.ts)
```typescript
When('el usuario hace clic en {string}', async function (text: string) {
  const plp = PageFactory.getSearchResultsPage(this, this.page);
  
  // 🔴 BREAKPOINT: Antes de la acción
  const hasProducts = await plp.hasProducts();
  
  // 🔴 BREAKPOINT: Ver datos
  const title = await plp.getFirstProductTitle();
  
  // 🔴 BREAKPOINT: Antes de click
  await plp.addFirstProductToCart();
});
```

### En Page Objects
```typescript
async addFirstProductToCart(): Promise<void> {
  // 🔴 BREAKPOINT: Verificar selectores
  await this.waitForResults();
  
  // 🔴 BREAKPOINT: Antes de hover
  const firstProduct = this.page.locator(this.selectors.productCard).first();
  await firstProduct.hover();
  
  // 🔴 BREAKPOINT: Antes de click
  await firstProduct.locator(this.selectors.addToCartBtn).click();
}
```

---

## 🔍 Debugging de Problemas Comunes

### ❌ Selector no encuentra elementos
```javascript
// Contar elementos con selector actual
await this.page.locator('[data-testid="product"]').count()  // 0

// Probar selectores alternativos
await this.page.locator('article').count()  // 24 ✅
await this.page.locator('.product-card').count()

// Ver estructura HTML
await this.page.locator('body').innerHTML()
```

### ❌ Elemento no visible
```javascript
// Verificar visibilidad
await this.page.locator('button').isVisible()  // false

// Hacer scroll al elemento
await this.page.locator('button').scrollIntoViewIfNeeded()

// Hacer hover en elemento padre
await this.page.locator('.parent').hover()
await this.page.locator('button').isVisible()  // true ✅
```

### ❌ Click no funciona
```javascript
// Verificar si está habilitado
await this.page.locator('button').isEnabled()

// Click con force
await this.page.locator('button').click({ force: true })

// Click con delay
await this.page.locator('button').click({ delay: 100 })

// Ver atributos
await this.page.locator('button').getAttribute('disabled')
```

### ❌ Timeout esperando elemento
```javascript
// Aumentar timeout temporalmente
await this.page.locator('selector').waitFor({ 
  state: 'visible', 
  timeout: 60000 
})

// Ver estado actual
await this.page.locator('selector').isHidden()
await this.page.locator('selector').isVisible()

// Tomar screenshot del problema
await this.page.screenshot({ path: 'timeout-debug.png', fullPage: true })
```

---

## 🎭 Playwright Inspector

### Abrir Inspector
```typescript
// En código
await this.page.pause()

// Desde terminal
$env:PWDEBUG=1; npm test
```

### Usar Pick Locator
1. Click en "🎯 Pick Locator"
2. Hover sobre elemento en navegador
3. Click en el elemento
4. Inspector muestra mejor selector

### Console en Inspector
```javascript
// Probar selectores
page.locator('[data-testid="product"]')
page.getByRole('button', { name: 'Añadir' })

// Ver elementos
await page.locator('button').count()
await page.locator('button').allTextContents()
```

---

## 📊 Watch Expressions (Vigilar)

Añade estas expresiones en el panel "WATCH":

```javascript
this.page.url()
await this.page.title()
await this.page.locator('[data-testid="product-card"]').count()
```

---

## 🚀 Configuraciones Launch.json

### Debug Feature Actual
```json
{
  "name": "🥒 Debug Cucumber - Current Feature",
  "request": "launch",
  "program": "${workspaceFolder}/node_modules/@cucumber/cucumber/bin/cucumber-js",
  "args": ["${file}"]
}
```

### Debug por Tag
```json
{
  "name": "🥒 Debug Cucumber - Specific Tag",
  "args": [
    "features/**/*.feature",
    "--tags", "@KAN-1212"  // Cambia el tag aquí
  ]
}
```

### Debug con Inspector
```json
{
  "name": "🎭 Debug Playwright Inspector",
  "env": {
    "PWDEBUG": "1"
  }
}
```

---

## 📸 Screenshots y Traces

### Screenshots Automáticos
```typescript
// En hooks.ts (ya configurado)
After(async function (scenario) {
  if (scenario.result?.status === 'failed') {
    const screenshot = await this.page.screenshot();
    this.attach(screenshot, 'image/png');
  }
});
```

### Traces
```typescript
// En playwright.config.ts (ya configurado)
trace: 'retain-on-failure'
```

Ver trace:
```bash
npx playwright show-trace traces/trace-*.zip
```

---

## 🎯 Tips Rápidos

### ✅ DO's
- ✅ Pon breakpoints en lugares estratégicos (no en cada línea)
- ✅ Usa Debug Console para probar selectores
- ✅ Toma screenshots cuando algo falla
- ✅ Usa `page.pause()` para inspección interactiva
- ✅ Lee los logs del navegador (pueden tener errores JS)

### ❌ DON'Ts
- ❌ No uses `waitForTimeout()` en código productivo
- ❌ No debuggees con paralelización activada
- ❌ No pongas breakpoints en node_modules
- ❌ No ignores los errores de console del navegador

---

## 🆘 Troubleshooting

### Inspector no se abre
```powershell
# Verificar instalación
npx playwright install chromium

# Intentar con navegador específico
$env:PLAYWRIGHT_BROWSER="chromium"; $env:PWDEBUG=1; npm test
```

### Breakpoints no se activan
```
1. Verifica que el código TypeScript esté compilado
2. Verifica sourceMaps en tsconfig.json: "sourceMap": true
3. Reinicia VS Code (Ctrl+Shift+P > "Developer: Reload Window")
```

### Test muy lento en debug
```
# Desactiva paralelización
"--parallel", "1"

# Ejecuta solo un escenario
--tags "@TU-TAG"
```

---

## 📚 Recursos

- **Tutorial Completo**: `docs/DEBUG-TUTORIAL.md`
- **Guía Visual**: `docs/DEBUG-VISUAL-GUIDE.md`
- **Launch Config**: `.vscode/launch.json`
- **Playwright Docs**: https://playwright.dev/docs/debug

---

**Última actualización**: 12 de Noviembre de 2025
