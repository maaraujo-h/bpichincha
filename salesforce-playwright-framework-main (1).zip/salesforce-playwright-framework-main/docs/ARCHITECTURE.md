# 🏗️ Arquitectura del Proyecto

## 📁 Estructura del Proyecto

```Text
# 🏗️ Arquitectura del Proyecto

## 📁 Estructura del Proyecto

```Text
salesforce-SdP-framework/
├── .github/
│   ├── agents/                           # 🤖 Agentes autónomos de IA
│   │   ├── playwright-test-generator.agent.md
│   │   ├── playwright-test-healer.agent.md
│   │   └── playwright-test-planner.agent.md
│   └── workflows/
│       ├── copilot-setup-steps.yml
│       └── e2e-tests.yml
├── .requirements/                        # 📂 Req. descargados de Jira (en .gitignore)
├── features/                             # 📝 Escenarios en Gherkin
│   ├── login-flow/loginFlow.feature
│   ├── commercial-flow/create-prospectFlow.feature
│   ├── commercial-flow/create-opportunityFlow.feature
│   └── quotation-flow/quotationFlow.feature
├── scripts/
│   └── orchestrator/                     # 🧠 Orquestador y Extractor de Jira
│       ├── jira-extractor.ts
│       └── orchestrator.ts
├── src/
│   ├── config/
│   │   ├── browser.config.ts
│   │   └── runtime.config.ts
│   ├── pages/                            # 💻 Page Object Model (POM)
│   │   ├── BasePage.ts
│   │   ├── clientFilePage.ts
│   │   ├── commercialFlowPage.ts
│   │   ├── loginFlowPage.ts
│   │   └── quotationFlowPage.ts
│   ├── steps/                            # 👣 Definición de Steps de Cucumber
│   │   ├── commercialFlow.steps.ts
│   │   ├── loginFlow.steps.ts
│   │   └── quotationFlow.steps.ts
│   ├── support/
│   │   └── hooks.ts
│   └── utils/
│       ├── constants.ts
│       ├── logger.ts
│       ├── page-factory.ts
│       └── test-data.ts
├── docs/                                 # 📚 Documentación del proyecto
└── .env
```

## 🎯 Patrones Implementados

### Page Object Model (POM)

```typescript
// BasePage: Métodos comunes
export class BasePage {
  async navigate(url: string): Promise<void>
  async waitForElement(selector: string): Promise<void>
  async click(selector: string): Promise<void>
  // ... más métodos reutilizables
}

// loginFlowPage: flujo de autenticación Salesforce
export class LoginFlowPage extends BasePage {
  async navigateToHomeEntry(): Promise<void>
  async loginWithConfiguredCredentials(allowManualOtp: boolean): Promise<void>
}
```

**Beneficios:**

- ✅ Un cambio en el selector → un solo lugar para actualizar
- ✅ Reutilización de código (BasePage)
- ✅ Tests más legibles y mantenibles

### PageFactory Pattern

```typescript
// Evita duplicación de inicialización inyectando en el contexto
const loginPage = PageFactory.getSalesforceLoginPage(this, this.page);
const quotationPage = PageFactory.getQuotationFlowPage(this, this.page);
```

**Evita código como:**

```typescript
// ❌ Duplicado en cada step
this.homePage = this.homePage || new HomePage(this.page);
```

### Configuration Over Code

```typescript
// Timeouts centralizados
export const TIMEOUTS = {
  INSTANT: 3000,
  SHORT: 5000,
  MEDIUM: 8000,
  LONG: 15000,
  NAVIGATION: 20000,
  SEARCH: 25000,
};

// Browser config centralizada
export const BROWSER_CONFIG = {
  userAgent: '...',
  launchArgs: [...],
  initScripts: '...',
};
```

## 🔄 Orquestación Autónoma con IA (AI-Driven Testing)

El framework incorpora un pipeline autónomo capaz de leer Historias de Usuario (US) de Jira, planificar los escenarios de prueba en Gherkin, generar los localizadores bajo el patrón POM, escribir las implementaciones de los steps y autosanar fallos inesperados en el navegador real utilizando servidores MCP de Playwright y Atlassian.

## 🔄 Flujo de Ejecución

### Flujo Estándar de Pruebas (Manual/CI)

```Text
1. Before Hook (hooks.ts)
   ├─ Lanzar Chromium con configuración hardened
   ├─ Leer configuración centralizada (`browser.config.ts` + `runtime.config.ts`)
   ├─ Aplicar configuración anti-detección
   ├─ Iniciar tracing cuando `TRACE_ON_FAILURE=true`
   └─ Crear página e inyectar init scripts

2. Feature Execution
   ├─ Leer feature/*.feature (Gherkin)
   ├─ Ejecutar steps/*.steps.ts
   │   └─ Usar PageFactory para obtener Page Objects
   └─ Page Objects ejecutan acciones en pages/*.ts

3. After Hook
   ├─ Screenshot si falla (opcional)
   ├─ Guardar trace solo si falla (o descartar en éxito)
   └─ Cerrar navegador
```

### Flujo de Generación y Ejecución Autónoma (IA Pipeline)

```Text
Jira Cloud (US ID) ──> scripts/orchestrator/orchestrator.ts
                           │
                           ├──> 1. jira-extractor.ts (Crea .requirements/KAN-1212-requirements.md)
                           │
                           ├──> 2. Test Planner Agent (Escribe features/new-flow/*.feature)
                           │
                           ├──> 3. Test Generator Agent (Escribe src/pages/*Page.ts y src/steps/*.ts)
                           │
                           └──> 4. Test Healer Agent (Ejecuta 'npm test' y autocorrige si falla)
```

## ⚡ Optimizaciones Aplicadas

### Timeouts Inteligentes

- **INSTANT (3s)**: Detección rápida (cookies, modales)
- **SHORT (5s)**: Elementos rápidos
- **MEDIUM (8s)**: Elementos estándar (default)
- **LONG (15s)**: Elementos pesados
- **NAVIGATION (20s)**: Navegación de páginas
- **SEARCH (25s)**: Búsquedas con carga

### Estrategias de Navegación

- ✅ `waitUntil: 'commit'` - Inicio rápido de navegación
- ✅ `waitUntil: 'domcontentloaded'` - Para búsquedas
- ❌ Evita `waitUntil: 'load'` - Muy lento
- ❌ Evita `waitUntil: 'networkidle'` - Muy lento e innecesario

### Anti-Detección (Hardened)

```typescript
// User agent realista
userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)...'

// Argumentos optimizados
args: [
  '--disable-blink-features=AutomationControlled',
  '--no-sandbox',
]

// Scripts de inicialización
await page.addInitScript(() => {
  Object.defineProperty(navigator, 'webdriver', { get: () => false });
  window.chrome = { runtime: {} };
});
```

## 📊 Componentes Clave

### BasePage

## Clase base con métodos comunes para todos los Page Objects

- `navigate()`, `click()`, `fill()`, `getText()`: Interacciones básicas con esperas implícitas.
- `isVisibleWithRealWait()` y `getFirstVisibleLocator()`: Implementaciones optimizadas para hacer polling real, solventando las deficiencias de los timeouts estáticos en la API de Playwright.
- `clearLocalStorage()` y `clearSessionStorage()`: Limpieza de estado para un aislamiento puro de escenarios.

### PageFactory

## Fábrica estática que utiliza la interfaz IPageContext para asegurar una única instancia compartida por World de Cucumber

```typescript
static getHomePage(context: any, page: Page): HomePage
static getSearchResultsPage(context: any, page: Page): SearchResultsPage
```

### Browser Config

## Configuración centralizada del navegador

- Launch args optimizados para velocidad y anti-detección
- User agent realista
- Init scripts para ocultar automatización
- Viewport y locale configurables

## Manejo de Ciclo de Vida - Hooks

- Before: Inicializa el navegador, verifica si es un escenario de invitado `(@guest)` o autenticado `(@auth)` para cargar inteligentemente el storageState de Salesforce, inyectando los contextos.
- AfterStep / After: Mecanismos automáticos de captura de fallos. Generan screenshots completos y empaquetan trazas `(traces/trace-*.zip)` para agilizar el diagnóstico.

### Constants y Datos `(constants.ts & test-data.ts)`

Timeouts, URLs y esperas centralizadas:

```typescript
TIMEOUTS    // Timeouts por tipo de operación
URLS        // URLs del sitio (BASE, SEARCH, etc.)
WAIT_TIMES  // Esperas necesarias (cookies, search)
```

- TIMEOUTS & URLS: Consolidación de variables críticas.
- TEST_DATA: Objeto inmutable con valores clave de Salesforce (ej. caseType, contactChannel, prospectIdentification).
- TestDataGenerator: Utilidades estáticas para la generación dinámica de emails, nombres, teléfonos aleatorios y direcciones.

## Logger Centralizado `(logger.ts)`

- Implementación de `winston` que separa alertas en `logs/error.log` e históricos en `logs/combined.log` (rotación máxima de 5MB por archivo).

## 🎓 Guía para Desarrolladores

### Generación de Pruebas vía Orquestador de IA (Recomendado)

- Para automatizar un nuevo requerimiento o ticket de extremo a extremo, asegúrate de tener configurado tu archivo `.env` (en caso de usar Jira o la API de Anthropic) y ejecuta el pipeline principal desde la consola.
- El orquestador es flexible y te permite elegir tanto el origen de la información como el modo en el que interactúas con la IA:

- Ejemplo 1 (Anthropic + Jira): Ejecutar TODO usando Anthropic desde Jira. El script detecta que no es un archivo local, llama a `extractJiraIssue` para descargar los requerimientos del ticket, y luego ejecuta automáticamente las fases utilizando la API de Claude.
Comando:```bash
npx ts-node scripts/orchestrator/orchestrator.ts KAN-1212

- Ejemplo 2 (Anthropic + Spec Local): Ejecutar TODO usando Anthropic desde un Spec Local. El script lee directamente el archivo `.md` local y arranca el pipeline automático completo mediante la API de Anthropic.
Comando:```bash
npx ts-node scripts/orchestrator/orchestrator.ts specs/quotation-flow.md

- Ejemplo 3 (Copilot + Jira): Ejecutar TODO usando Copilot desde Jira. El script extrae los datos desde Jira, prepara el contexto en la carpeta de requerimientos, y aplica el freno de seguridad (`--copilot`) para que el trabajo de generación lo haga la IA de tu editor.
Comando:```bash
npx ts-node scripts/orchestrator/orchestrator.ts KAN-1212 --copilot

- Ejemplo 4 (Copilot + Spec Local): Ejecutar TODO usando Copilot desde un Spec Local. El script valida la ruta de tu spec local y se detiene limpiamente (`--copilot`) para que utilices GitHub Copilot o Cursor directamente en tu IDE.
Comando:```bash
npx ts-node scripts/orchestrator/orchestrator.ts specs/quotation-flow.md --copilot

------

 1. Origen de los Datos (Jira vs. Spec Local)

- Puedes alimentar el orquestador desde dos fuentes distintas:

#### Desde Jira

  1. Flujo: El script activa `jira-extractor.ts`, conectándose a la API de Atlassian para descargar la Historia de Usuario y los criterios de aceptación.
  2. Almacenamiento: Guarda los requisitos de forma limpia en la carpeta local oculta `.requirements/KAN-1212-requirements.md`.

#### Desde un Spec Local

   1. Flujo: Se omite por completo la llamada a la API de Jira y el uso de la red.
   2. Almacenamiento: Utiliza directamente un archivo Markdown local que ya tengas versionado en la carpeta `specs/` (ej. `specs/quotation-flow.md`), permitiéndote trabajar de forma totalmente offline.

2. Modos de Ejecución de IA (Automático vs. Copilot)

- Dependiendo de si deseas que la máquina haga todo el trabajo o si prefieres apoyarte en tu IDE, puedes lanzar el comando de dos maneras:

#### A. Modo Automático (Anthropic API)

-Comando:

```bash
npx ts-node scripts/orchestrator/orchestrator.ts KAN-1212
*(Puedes reemplazar `KAN-1212` por la ruta de un spec local).*
```

- Continuación: Inyecta el archivo extraído como contexto a los agentes MCP. Alimenta exactamente el motor posterior completo `(Planner ➔ Generator ➔ Ejecución de npm test ➔ Healer si hay fallos)`. El orquestador generará automáticamente el archivo `.feature`, el `Page Object` correspondiente, el `step definition` y verificará su éxito en tiempo real. (Requiere `ANTHROPIC_API_KEY` en el `.env`).

#### B. Modo Híbrido / Manual (GitHub Copilot)

- Comando:

```bash
npx ts-node scripts/orchestrator/orchestrator.ts KAN-1212 --copilot
```

- Continuación: El script extrae el contexto (desde Jira o Spec) y se detiene de inmediato sin consumir tokens de APIs externas. Te permite abrir el requerimiento guardado directamente en Visual Studio Code y utilizar tu extensión de GitHub Copilot para redactar paso a paso el Gherkin y el código TypeScript a voluntad.

### Agregar Nueva Página

1. Crear clase en `src/pages/NombrePage.ts`
2. Extender `BasePage`
3. Definir selectores privados
4. Implementar métodos de acción

```typescript
import { BasePage } from './BasePage';

export class ExamplePage extends BasePage {
  private readonly selectors = {
    exampleButton: 'button[data-testid="example-button"]',
    exampleTitle: 'h1.example-title',
  };

  async clickExample(): Promise<void> {
    await this.click(this.selectors.exampleButton);
  }

  async getExampleTitle(): Promise<string> {
    return await this.getText(this.selectors.exampleTitle);
  }
}
```

### Agregar Nuevos Steps

1. Crear/editar archivo en `src/steps/nombre.steps.ts`
2. Usar PageFactory para obtener Page Objects
3. Implementar lógica usando métodos del Page Object

```typescript
import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PageFactory } from '../utils/page-factory';

When('el usuario añade el producto al carrito', async function () {
  const productPage = PageFactory.getProductPage(this, this.page);
  await productPage.addToCart();
});
```

### Agregar Nueva Feature

1. Crear archivo en `features/nombre.feature`
2. Usar sintaxis Gherkin en inglés
3. Agregar tags para organización

```gherkin
@salesforce @auth
Feature: Salesforce Login flow - Signin
  As a Salesforce user
  I want to access the Salesforce lightning home URL
  So I can reach either the login page or the authenticated home safely

  Background:
    Given the user opens the Salesforce home entry page

  @login-page-validation
  Scenario: Validate Salesforce login page loads correctly
    Then the Salesforce login page should be visible
    And the URL should contain "lightning.force.com"
    And a primary Salesforce action should be visible
    And the Salesforce username input should be visible
```

### Modificar Timeouts

1. Editar `src/utils/constants.ts`
2. Actualizar el valor en `TIMEOUTS`
3. El cambio afecta automáticamente a todo el proyecto

## 🔍 Selectores - Mejores Prácticas

### Orden de Preferencia

1. **data-testid**- Lo más estable
   ```typescript
   'button[data-testid="SearchBarLink"]'
   ```

2. **aria-label / role** - Bueno para accesibilidad
   ```typescript
   'ul[aria-label="Lista de productos"]'
   ```

3. **ID único** - Estable si no cambia
   ```typescript
   '#search-button'
   ```

4. **Clases CSS** - Menos estable
   ```typescript
   '.search-button'  // Usar solo si es necesario
   ```

### Verificación con MCP

Todos los selectores deben verificarse con Playwright MCP antes de usar:

```Text
@copilot Usando MCP de Playwright, verifica el selector del botón de búsqueda
```

## 📈 Métricas de Performance

### Benchmarks Actuales

- **Tiempo Total**: ~1m02s para 3 escenarios
- **Tiempo por Escenario**: ~20s
- **Tests por Hora**: ~180 tests
- **Tasa de Éxito**: 100%

### Cómo Mantener la Velocidad

1. ✅ Usar timeouts apropiados según operación
2. ✅ Evitar `wait()` fijos cuando sea posible
3. ✅ Usar `domcontentloaded` en vez de `load`
4. ✅ No usar `networkidle` (muy lento)
5. ✅ Screenshots solo en fallos

## 🛠️ Troubleshooting

### Tests Lentos

- Revisar si hay `waitForLoadState('networkidle')` - reemplazar por `domcontentloaded`
- Revisar timeouts muy largos - usar constantes apropiadas
- Revisar `wait()` fijos - usar `waitForElement()` en su lugar

### Selectores No Encontrados

1. Verificar con Playwright MCP que el selector es correcto
2. Aumentar timeout si el elemento tarda en aparecer
3. Verificar que la página ha cargado completamente

### Detección de Bot

- Verificar que el hardening de navegador está activo
- Revisar user agent - debe ser realista
- Revisar init scripts - deben ocultar webdriver
- Considerar aumentar esperas antes de acciones críticas

## 📚 Referencias

- [Playwright Docs](https://playwright.dev/)
- [Cucumber.js](https://cucumber.io/docs/cucumber/)
- [Page Object Model Pattern](https://playwright.dev/docs/pom)

## Mantenido por: Equipo de QA

## Versión: 1.1.0

## Última actualización: Julio 2026
