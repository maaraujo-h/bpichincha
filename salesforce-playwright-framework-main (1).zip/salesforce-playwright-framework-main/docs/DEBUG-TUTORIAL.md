# 🐛 Tutorial Práctico: Debugging de Test Cucumber

## 📋 Objetivo
Debuggear el escenario "Añadir primer producto al carrito desde PLP" para productos de moda (KAN-1212).

---

## 🎯 Escenario de Ejemplo

**Feature**: `features/cart/add-product-from-plp.feature`  
**Tag**: `@KAN-1212 @fashion`  
**Término de búsqueda**: "zapatillas nike"

```gherkin
@KAN-1212 @fashion @happy-path
Escenario: Añadir primer producto al carrito desde PLP - Productos de moda
  Cuando el usuario busca "zapatillas nike"
  Y el usuario espera a que se carguen los resultados
  Entonces debería haber al menos 1 producto en los resultados
  Cuando el usuario hace clic en "Añadir" del primer producto
  Entonces el producto debería agregarse al carrito
  Y debería aparecer confirmación de producto añadido
```

---

## 🚀 Método 1: Debug con VS Code (F5)

### Paso 1: Abrir el Feature File
1. Abre `features/cart/add-product-from-plp.feature` en VS Code
2. Revisa el escenario que quieres debuggear

### Paso 2: Colocar Breakpoints Estratégicos

#### En `src/steps/cart.steps.ts`:

**Breakpoint 1** - Antes de hacer clic en "Añadir":
```typescript
When('el usuario hace clic en {string} del primer producto', async function (actionText: string) {
  logger.info(`Haciendo clic en "${actionText}" del primer producto`);
  
  const plp = PageFactory.getSearchResultsPage(this, this.page);
  
  // 🔴 BREAKPOINT AQUÍ - Inspeccionar estado antes de añadir
  const hasProducts = await plp.hasProducts();
  
  if (!hasProducts) {
    throw new Error('No hay productos disponibles para añadir al carrito');
  }
  
  // 🔴 BREAKPOINT AQUÍ - Ver título del producto
  const productTitle = await plp.getFirstProductTitle();
  logger.debug(`Producto a añadir: "${productTitle}"`);
  
  // 🔴 BREAKPOINT AQUÍ - Antes de hacer clic
  await plp.addFirstProductToCart();
  
  logger.info(`Producto "${productTitle}" añadido al carrito`);
});
```

**Breakpoint 2** - Verificar que se agregó:
```typescript
Then('el producto debería agregarse al carrito', async function () {
  logger.info('Verificando que el producto se agregó al carrito');
  
  const plp = PageFactory.getSearchResultsPage(this, this.page);
  
  // 🔴 BREAKPOINT AQUÍ - Ver si hay confirmación
  const hasConfirmation = await plp.isCartConfirmationVisible();
  
  expect(hasConfirmation, 'Confirmación de carrito debería ser visible').toBeTruthy();
});
```

### Paso 3: Iniciar Debug
1. **Presiona F5** (o `Run > Start Debugging`)
2. **Selecciona**: `🥒 Debug Cucumber - Current Feature`
3. VS Code abrirá el navegador en modo **visible** (no headless)

### Paso 4: Interactuar en los Breakpoints

Cuando el test se detenga en un breakpoint, puedes:

#### **A) Inspeccionar Variables**
En la pestaña "VARIABLES" de VS Code verás:
```
this.page: Page { ... }
plp: SearchResultsPage { ... }
hasProducts: true
productTitle: "Nike Air Max 90..."
```

#### **B) Usar Debug Console**
```javascript
// Ver cuántos productos hay
await this.page.locator('[data-testid="product-card"]').count()

// Ver título del primer producto
await this.page.locator('[data-testid="product-title"]').first().textContent()

// Ver si el botón añadir está visible
await this.page.locator('[data-testid="add-to-cart"]').first().isVisible()

// Tomar screenshot
await this.page.screenshot({ path: 'debug-productos.png' })
```

#### **C) Evaluar en el Navegador**
```javascript
// Estado del DOM
await this.page.evaluate(() => ({
  url: window.location.href,
  title: document.title,
  productsFound: document.querySelectorAll('[data-testid="product-card"]').length
}))
```

### Paso 5: Avanzar Paso a Paso
- **F10**: Step Over (siguiente línea)
- **F11**: Step Into (entrar en función)
- **Shift+F11**: Step Out (salir de función)
- **F5**: Continue (hasta siguiente breakpoint)

---

## 🎭 Método 2: Debug con Playwright Inspector

### Paso 1: Iniciar con Inspector
1. **Presiona F5**
2. **Selecciona**: `🎭 Debug Playwright Inspector`

### Paso 2: Usar Playwright Inspector

Se abrirá una ventana con controles:

```
┌─────────────────────────────────────┐
│  Playwright Inspector               │
├─────────────────────────────────────┤
│  ▶️ Resume  ⏸️ Pause  ⏭️ Step Over  │
│                                     │
│  🎯 Pick Locator (Selector Picker)  │
│  📸 Screenshot                      │
│  🔍 Explore                         │
│                                     │
│  Console:                           │
│  > await page.locator('...')        │
└─────────────────────────────────────┘
```

#### **A) Pick Locator (Selector Picker)**
1. Haz clic en **"Pick Locator"** (🎯)
2. Pasa el mouse sobre elementos en la página
3. Inspector te mostrará el mejor selector:
   ```typescript
   getByRole('button', { name: 'Añadir al carrito' })
   // o
   page.locator('[data-testid="add-to-cart"]')
   ```

#### **B) Explorar Elementos**
En la consola del Inspector:
```javascript
// Buscar productos
await page.locator('[data-testid="product-card"]').count()
// Output: 24

// Ver primer producto
await page.locator('[data-testid="product-title"]').first().textContent()
// Output: "Nike Air Max 90 Zapatillas - Hombre"

// Verificar botón
await page.locator('[data-testid="add-to-cart"]').first().isVisible()
// Output: true
```

#### **C) Tomar Screenshots**
```javascript
// Screenshot del primer producto
await page.locator('[data-testid="product-card"]').first().screenshot({ 
  path: 'primer-producto.png' 
})

// Screenshot de toda la página
await page.screenshot({ path: 'plp-completa.png', fullPage: true })
```

---

## 💻 Método 3: Debug desde Terminal

### Con Playwright Inspector:
```powershell
# Ejecutar con Inspector
$env:PWDEBUG=1; npm test -- features/cart/add-product-from-plp.feature

# Solo el tag específico
$env:PWDEBUG=1; npm test -- --tags "@KAN-1212"

# Con más logging
$env:DEBUG="pw:api"; $env:PWDEBUG=1; npm test -- --tags "@KAN-1212"
```

### Con Navegador Visible (sin Inspector):
```powershell
# Navegador visible
$env:HEADLESS="false"; npm test -- --tags "@KAN-1212"

# Navegador visible + logs detallados
$env:HEADLESS="false"; $env:DEBUG="pw:api"; npm test -- --tags "@KAN-1212"
```

---

## 🔍 Debugging Avanzado: Casos Comunes

### Problema 1: Selector no funciona

**Síntoma**: Test falla en `await plp.addFirstProductToCart()`

**Debug**:
```typescript
// En el breakpoint, ejecuta en Debug Console:

// 1. Verificar si hay productos
await this.page.locator('[data-testid="product-card"]').count()

// 2. Si es 0, intentar otros selectores
await this.page.locator('article').count()
await this.page.locator('.product-item').count()

// 3. Ver estructura del HTML
await this.page.locator('body').innerHTML()

// 4. Tomar screenshot para análisis
await this.page.screenshot({ path: 'debug-no-products.png' })
```

**Solución**: Actualizar selector en `SearchResultsPage.ts`

---

### Problema 2: Confirmación no aparece

**Síntoma**: Test falla en verificación de confirmación

**Debug**:
```typescript
// En el breakpoint después de añadir:

// 1. Ver si hay modal/toast de confirmación
await this.page.locator('[role="alert"]').count()
await this.page.locator('.toast').count()

// 2. Ver todos los elementos visibles
await this.page.locator('visible=true').count()

// 3. Esperar manualmente
await this.page.waitForTimeout(2000) // Solo para debug
await this.page.screenshot({ path: 'debug-after-add.png' })

// 4. Ver logs del navegador
const logs = await this.page.evaluate(() => 
  JSON.stringify(console.logs)
)
```

**Solución**: Ajustar timeout o selector de confirmación

---

### Problema 3: Producto no se añade

**Síntoma**: Botón hace clic pero no se añade al carrito

**Debug**:
```typescript
// 1. Verificar que el clic funciona
const button = this.page.locator('[data-testid="add-to-cart"]').first();

// Ver si está visible
await button.isVisible() // true

// Ver si está habilitado
await button.isEnabled() // true

// Ver el texto del botón
await button.textContent() // "Añadir al carrito"

// 2. Hacer clic con opciones
await button.click({ force: true, delay: 100 })

// 3. Ver red requests (API calls)
this.page.on('request', req => console.log('REQUEST:', req.url()))
this.page.on('response', res => console.log('RESPONSE:', res.status(), res.url()))
```

---

## 📊 Comandos Útiles en Debug Console

### Inspección de Elementos:
```javascript
// Contar elementos
await this.page.locator('selector').count()

// Ver texto
await this.page.locator('selector').textContent()

// Ver todos los textos
await this.page.locator('selector').allTextContents()

// Verificar visibilidad
await this.page.locator('selector').isVisible()

// Ver atributos
await this.page.locator('selector').getAttribute('class')
```

### Screenshots:
```javascript
// Screenshot de elemento
await this.page.locator('selector').screenshot({ path: 'element.png' })

// Screenshot de viewport
await this.page.screenshot({ path: 'viewport.png' })

// Screenshot página completa
await this.page.screenshot({ path: 'full.png', fullPage: true })
```

### Estado del Navegador:
```javascript
// URL actual
this.page.url()

// Título de página
await this.page.title()

// Evaluar JS en navegador
await this.page.evaluate(() => ({
  url: window.location.href,
  cookies: document.cookie,
  localStorage: Object.keys(localStorage),
  sessionStorage: Object.keys(sessionStorage)
}))
```

### Pausar Ejecución:
```typescript
// Pausar con Inspector
await this.page.pause()

// Esperar manualmente (solo debug)
await this.page.waitForTimeout(5000)
```

---

## 🎓 Ejercicio Práctico

### Debuggea este escenario siguiendo los pasos:

1. **Prepara el entorno**:
   - Abre `features/cart/add-product-from-plp.feature`
   - Pon breakpoint en línea 54 de `cart.steps.ts` (dentro del When de "hace clic en Añadir")

2. **Inicia debug**:
   - Presiona **F5**
   - Selecciona **"🥒 Debug Cucumber - Current Feature"**

3. **Cuando llegue al breakpoint**:
   - Inspecciona `productTitle` en Variables
   - Ejecuta en Debug Console:
     ```javascript
     await this.page.locator('[data-testid="product-card"]').count()
     ```
   - Toma un screenshot:
     ```javascript
     await this.page.screenshot({ path: 'antes-añadir.png' })
     ```

4. **Avanza con F10** hasta después de `addFirstProductToCart()`

5. **Verifica el resultado**:
   - Ejecuta:
     ```javascript
     await this.page.locator('[role="alert"]').isVisible()
     ```
   - Toma otro screenshot:
     ```javascript
     await this.page.screenshot({ path: 'despues-añadir.png' })
     ```

6. **Presiona F5** para continuar hasta el final

---

## 📚 Referencias

- **Playwright Debugging**: https://playwright.dev/docs/debug
- **VS Code Debugging**: https://code.visualstudio.com/docs/editor/debugging
- **Cucumber Debugging**: https://github.com/cucumber/cucumber-js/blob/main/docs/debugging.md

---

**Creado**: 12 de Noviembre de 2025  
**Proyecto**: Playwright BDD POM Template  
**Autor**: QA Team
