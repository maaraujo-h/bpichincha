# 🚀 Guía de Inicio - Salesforce SdP

Esta guía te llevará paso a paso para ejecutar tu primer test Salesforce en **5 minutos**.

---

## ⚡ Setup Rápido (5 minutos)

### Paso 1: Verificar Requisitos

```powershell
# Verificar Node.js (debe ser >= 18)
node --version

# Verificar npm
npm --version
```

**Si no tienes Node.js**, descárgalo desde [nodejs.org](https://nodejs.org)

### Paso 2: Instalar Dependencias

```powershell
# Navega a la carpeta del proyecto
cd ..\salesforce-SdP-framework

# Instala todas las dependencias
npm install

# Instala navegadores de Playwright
npm run playwright:install
```

**Tiempo esperado**: ~2 minutos

### Paso 3: Configurar Salesforce

```powershell
# Crea un archivo .env en la raíz del proyecto
notepad .env
```

Edita `.env` e ingresa tus credenciales:

```env
SALESFORCE_USERNAME=your-username@seg-pichincha.sandbox.com
SALESFORCE_PASSWORD=your-password
SALESFORCE_ALLOW_MANUAL_OTP=true
```

### Paso 4: Ejecutar Tu Primer Test

```powershell
# Opción A: Ejecutar con navegador visible (RECOMENDADO para principiantes)
npm run test:headed

# Opción B: Ejecutar en background (más rápido)
npm test
```

**Resultado esperado**:

- ✅ Chromium se lanza automáticamente
- ✅ Se abre Salesforce
- ✅ Se ejecutan 3 escenarios
- ✅ Se genera reporte en `cucumber-report/cucumber-report.html`

---

## 📝 Crear Tu Primer Test

## 🤖 Crear Tu Primer Test usando IA (Recomendado)

En lugar de crear los archivos `.feature`, Page Objects y Step Definitions manualmente, puedes usar nuestro orquestador autónomo para generarlos a partir de un requerimiento.

Asegúrate de tener tu `.env` configurado. Dependiendo de tu flujo de trabajo, puedes elegir entre automatización total o asistencia con tu IDE:

### Opción A: Automatización Total (Vía API de Anthropic)

Si tienes configurada tu `ANTHROPIC_API_KEY`, el orquestador se encargará de todo el ciclo de vida por ti.

```powershell
# Extrae de Jira, genera Gherkin, genera POM/Steps y ejecuta el test
npx ts-node scripts/orchestrator/orchestrator.ts KAN-1212
```

La IA creará los archivos bajo la carpeta features/ y src/, y ejecutará la prueba automáticamente sanando los selectores si es necesario.

### Opción B: Modo Asistido (Vía GitHub Copilot)

Si no usas APIs de pago y prefieres apoyarte en la extensión de GitHub Copilot de tu editor, utiliza la bandera `--copilot` para extraer el contexto de Jira y detener el script.

```powershell
# Solo extrae de Jira y guarda el requerimiento en .requirements/
npx ts-node scripts/orchestrator/orchestrator.ts KAN-1212 --copilot
```

### Paso 1: Crear Feature File con Copilot

Abre el archivo descargado en `.requirements/`, abre el chat de GitHub Copilot en tu IDE y pídele que genere el escenario de prueba. Guárdalo en el archivo `features/mi-primer-test/mi-primer-test.feature`:

```gherkin
# language: en
Feature: Mi primer test de Salesforce

  @salesforce @mytest
  Scenario: Login en Salesforce
    Given the user opens the Salesforce home entry page
    When the user signs in to Salesforce with configured credentials
    Then the Salesforce lightning home should be visible
```

### Paso 2: Generar POM y Steps

- Usa Copilot en tu IDE para generar el código TypeScript correspondiente basándose en tu archivo `.feature`.

### Paso 3: Ejecutar Tu Test

- Lanza la prueba de forma local usando la etiqueta que asignaste:

```powershell
npm run test:headed -- --tags "@mytest"
```

¡Listo! Acabas de escribir tu primer test end-to-endcon asistencia de IA.

---

## 🎯 Entender la Estructura

### Features (Archivo `.feature`)

Archivo en lenguaje natural (Gherkin):

```gherkin
# language: en
Feature: Descripción de la funcionalidad

  @tag1 @tag2
  Scenario: Descripción del caso de prueba
    Given condición inicial
    When acción del usuario
    Then resultado esperado
```

**Ubicación**: `features/[dominio]/[archivo].feature`

### Steps (Archivo `.ts`)

Implementación de los pasos Gherkin:

```typescript
import { Given, When, Then } from '@cucumber/cucumber';
import { PageFactory } from '../utils/page-factory';

Given('the user opens the Salesforce home entry page', async function () {
  const loginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  await loginPage.navigateToHomeEntry();
});

When('the user signs in to Salesforce', async function () {
  const loginPage = PageFactory.getSalesforceLoginPage(this, this.page);
  await loginPage.loginWithConfiguredCredentials(true);
});
```

**Ubicación**: `src/steps/[archivo].steps.ts`

### Page Objects (Archivo `.ts`)

Encapsulación de la interfaz de usuario:

```typescript
import { Page } from '@playwright/test';
import { BasePage } from './BasePage';

export class MyPage extends BasePage {
  private readonly selectors = {
    buttonClick: '[data-testid="click-btn"]',
    textInput: '[data-testid="text-input"]',
  };

  async clickButton(): Promise<void> {
    await this.click(this.selectors.buttonClick);
  }

  async fillText(text: string): Promise<void> {
    await this.fill(this.selectors.textInput, text);
  }
}
```

**Ubicación**: `src/pages/[NombrePage].ts`

---

## 🔍 Debugging - Cuando Algo Falla

### Opción 1: Ver el Navegador (RECOMENDADO)

```powershell
npm run test:headed -- --tags "@mytest"
```

Verás Chromium abierto en tiempo real. Observa qué sucede paso a paso.

### Opción 2: Usar Playwright Inspector

```powershell
$env:PWDEBUG=1; npm test -- --tags "@mytest"
```

Se abrirá el **Playwright Inspector** donde puedes:
- ⏸️ Pausar la ejecución
- 🔍 Inspeccionar elementos
- 📝 Ver logs en tiempo real

### Opción 3: Agregar Breakpoint en VS Code

1. Abre tu Step File (`.steps.ts`)
2. Presiona **F9** en la línea que quieras pausar
3. Presiona **F5** → Selecciona "Debug Cucumber - Current Feature"
4. Usa **F10** para step over, **F11** para step into

### Opción 4: Ver Screenshots

Si un test falla con `SCREENSHOT_ON_FAILURE=true`, encontrarás screenshots en:
- `playwright-report/` 

Abre `playwright-report/index.html` en el navegador.

---

## 📊 Ver Reportes

### Reporte HTML (Bonito y Legible)

```powershell
# Se genera automáticamente después de cada ejecución
start cucumber-report/cucumber-report.html
```

### Reporte JSON (Para CI/CD)

```powershell
# Para procesamiento automatizado
cat cucumber-report/cucumber-report.json
```

---

## 🔑 Comandos Útiles

### Ejecutar Tests

```powershell
# Todos los tests
npm test

# Con navegador visible
npm run test:headed

# Con Playwright Inspector
npm run test:debug

# Solo tests Salesforce
npm run test:salesforce

# Por tags específicos
npm test -- --tags "@salesforce"
npm test -- --tags "@auth"
npm test -- --tags "@commercial-flow"
```

### Generar Storage State (Reutilizar Sesiones)

```powershell
# Guarda una sesión autenticada
npm run salesforce:auth:bootstrap

# Los siguientes tests usarán esta sesión (más rápido)
npm test
```

### Desarrollo

```powershell
# Verificar TypeScript
npm run type-check

# Instalar nuevos navegadores
npm run playwright:install
```

---

## 🚨 Problemas Comunes

### ❌ "SALESFORCE_USERNAME is not defined"

**Causa**: Falta configurar `.env`

**Solución**:
```powershell
notepad .env  # Edita con tus credenciales
```

### ❌ "Timeout waiting for element"

**Causa**: Elemento no encontrado o tiempo insuficiente

**Solución**:
1. Verifica el selector es correcto: `npm run test:headed`
2. Aumenta timeout en `src/utils/constants.ts`
3. Lee [DEBUG-CHEATSHEET.md](DEBUG-CHEATSHEET.md)

### ❌ "Browser launch failed"

**Causa**: Playwright no instalado correctamente

**Solución**:
```powershell
npm run playwright:install
```

### ❌ "Cannot find module '@playwright/test'"

**Causa**: Dependencias no instaladas

**Solución**:
```powershell
npm install
```

---

## 📚 Siguientes Pasos

1. **Lee [ARCHITECTURE.md](ARCHITECTURE.md)** - Entiende la estructura
2. **Lee [CODING-STANDARDS.md](CODING-STANDARDS.md)** - Sigue estándares
3. **Lee [SALESFORCE-SPECIFICS.md](SALESFORCE-SPECIFICS.md)** - Detalles técnicos
4. **Crea tu primer Page Object** - Basándote en ejemplos
5. **Agrega tus features** - Organiza en carpetas por dominio

---

## 🎓 Recursos Externos

- [Playwright Docs](https://playwright.dev)
- [Cucumber Docs](https://cucumber.io)
- [TypeScript Handbook](https://www.typescriptlang.org/docs)
- [Salesforce Docs](https://developer.salesforce.com)

---

**¿Necesitas ayuda?** Consulta [DEBUG-CHEATSHEET.md](DEBUG-CHEATSHEET.md)

**Última actualización**: Julio 2026
