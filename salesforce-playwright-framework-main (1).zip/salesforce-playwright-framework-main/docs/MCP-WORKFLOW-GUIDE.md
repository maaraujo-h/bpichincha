# 🚀 Guía Práctica de MCPs - De Jira a Test Automatizado

Esta guía muestra cómo usar los MCPs de Atlassian y Playwright para generar tests automáticamente desde tickets de Jira.

> Nota: este documento mantiene un ejemplo genérico de Jira/Playwright; adapta los prompts y Page Objects a los flujos Salesforce reales del proyecto.

---

## 📋 Prerequisitos

1. ✅ MCPs configurados en `.vscode/mcp.json`
2. ✅ Autenticación OAuth con Atlassian completada (primera vez)
3. ✅ GitHub Copilot activo en VS Code

---

## 🎯 Workflow Completo: KAN-1212 como Ejemplo

### Paso 1: Leer Test Case desde Jira

**Prompt para Copilot**:
```
Lee el test case KAN-1212 desde Jira usando el MCP de Atlassian 
y muéstrame toda la información disponible
```

**Copilot ejecuta**:
```typescript
mcp_atlassian-mcp_getJiraIssue({
  cloudId: "14768af6-ce1c-4dd3-b223-5eb3ed495dc3",
  issueIdOrKey: "KAN-1212"
})
```

**Información extraída del ticket**:
- **Título**: [MODA] PLP - Añadir producto a la cesta
- **Descripción**: Pasos de prueba detallados
- **Pre-condiciones**: Usuario en página principal
- **Pasos**:
  1. Buscar "Zapatillas nike"
  2. Click en "Añadir" del primer producto
  3. Verificar que producto se agrega al carrito
- **Resultado esperado**: Producto en carrito, contador actualizado

---

### Paso 2: Generar Feature File

**Prompt para Copilot**:
```
Basándote en el ticket KAN-1212 que acabas de leer, genera un feature file 
en Gherkin siguiendo las mejores prácticas del proyecto (.github/copilot-instructions.md)
```

**Copilot genera** (`features/plp/moda.feature`):
```gherkin
# language: es
# Referencia: KAN-1212
# URL: https://plataformas.atlassian.net/browse/KAN-1212
@KAN-1212 @salesforce @auth
Característica: [MODA] Añadir producto desde página de listado de productos
  Como usuario de un sitio web
  Quiero añadir productos al carrito desde la PLP
  Para realizar compras de forma rápida sin entrar al detalle del producto

  Antecedentes:
    Dado el usuario está en la página principal del sitio web
    Y el usuario acepta las cookies

  @critical
  Escenario: Añadir primer producto al carrito desde PLP
    Cuando el usuario busca "zapatillas nike"
    Y el usuario espera a que se carguen los resultados
    Y el usuario hace clic en "Añadir" del primer producto
    Entonces el producto debería agregarse al carrito
    Y el contador del carrito debería mostrar 1 producto
    Y debería aparecer confirmación de producto añadido

  @regression
  Escenario: Verificar que el carrito mantiene el producto
    Cuando el usuario busca "zapatillas nike"
    Y el usuario hace clic en "Añadir" del primer producto
    Y el usuario navega al carrito
    Entonces el carrito debería contener "zapatillas nike"
    Y el total del carrito debería ser mayor que 0
```

---

### Paso 3: Analizar Página Real con MCP de Playwright

**Prompt para Copilot**:
```
Usando el MCP de Playwright, navega a 
https://www.example.com/search-nwx/?s=zapatillas%20nike
y captura la estructura del DOM para generar selectores robustos 
para ProductListPage
```

**Copilot ejecuta**:
```typescript
mcp_microsoft_pla_browser_navigate({
  url: "https://www.example.com/search-nwx/?s=zapatillas%20nike"
})

mcp_microsoft_pla_browser_snapshot()
```

**DOM capturado** (ejemplo simplificado):
```
[Document]
  ├── [main]
  │   ├── [section] "Resultados de búsqueda"
  │   │   ├── [ul aria-label="Lista de productos"]
  │   │   │   ├── [li] Producto 1
  │   │   │   │   ├── [article]
  │   │   │   │   │   ├── [img alt="Nike Air Max"]
  │   │   │   │   │   ├── [h2] "Nike Air Max 90"
  │   │   │   │   │   ├── [button] "Añadir"
  │   │   │   │   │   └── [span] "59,99 €"
```

---

### Paso 4: Generar Page Object con Selectores Verificados

**Prompt para Copilot**:
```
Basándote en el snapshot del DOM que capturaste, genera ProductListPage 
con selectores robustos siguiendo la jerarquía:
data-testid > getByRole > getByText > CSS

Incluye métodos para:
- Esperar resultados de búsqueda
- Añadir primer producto al carrito
- Verificar confirmación
- Obtener contador de carrito
```

**Copilot genera** (`src/pages/ProductListPage.ts`):
```typescript
/**
 * Referencia: KAN-1212
 * Page Object para la página de listado de productos (PLP)
 * Selectores generados desde DOM real usando MCP de Playwright
 * 
 * @example
 * const plp = PageFactory.getProductListPage(context, page);
 * await plp.waitForResults();
 * await plp.addFirstProductToCart();
 */
import { Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { logger } from '../utils/logger';
import { TIMEOUTS } from '../utils/constants';

export class ProductListPage extends BasePage {
  /** 
   * Selectores verificados contra DOM real
   * Jerarquía: data-testid > getByRole > getByText > CSS
   */
  private readonly selectors = {
    // Lista de productos - verificado con MCP
    productList: 'ul[aria-label="Lista de productos"]',
    
    // Tarjetas de producto - múltiples estrategias
    productCard: '[data-testid="product-card"], article',
    productTitle: '[data-testid="product-title"], h2',
    
    // Botón añadir - jerarquía robusta
    addToCartBtn: '[data-testid="add-to-cart"], button:has-text("Añadir"), button[aria-label*="Añadir"]',
    
    // Confirmación - múltiples estrategias
    cartConfirmation: '[data-testid="cart-confirmation"], [role="alert"]:has-text("añadido"), .notification-success',
    
    // Contador de carrito
    cartCounter: '[data-testid="cart-counter"], [aria-label*="carrito"] .badge, .cart-count',
  };

  constructor(page: Page) {
    super(page);
  }

  /**
   * Espera a que los resultados de búsqueda estén cargados
   * KAN-1212: Pre-condición para añadir producto
   */
  async waitForResults(): Promise<void> {
    logger.info('Esperando resultados de búsqueda en PLP');
    
    // ✅ Espera el contenedor de productos
    await this.waitForElement(this.selectors.productList, TIMEOUTS.LONG);
    
    // ✅ Verifica que haya al menos un producto
    await this.page.locator(this.selectors.productCard).first().waitFor({
      state: 'visible',
      timeout: TIMEOUTS.MEDIUM
    });
    
    logger.debug('Resultados de búsqueda cargados');
  }

  /**
   * Añade el primer producto al carrito desde PLP
   * KAN-1212: Acción principal del test case
   * 
   * @throws {Error} Si no hay productos disponibles
   */
  async addFirstProductToCart(): Promise<void> {
    logger.info('KAN-1212: Añadiendo primer producto al carrito');
    
    // Esperar que haya productos
    await this.waitForResults();
    
    // Obtener primer producto
    const firstProduct = this.page.locator(this.selectors.productCard).first();
    
    // Hacer hover para asegurar que el botón es visible
    await firstProduct.hover();
    logger.debug('Hover realizado en primer producto');
    
    // Click en botón añadir
    const addButton = firstProduct.locator(this.selectors.addToCartBtn).first();
    await addButton.click();
    logger.debug('Click realizado en botón Añadir');
    
    // Esperar confirmación
    await this.waitForElement(this.selectors.cartConfirmation, TIMEOUTS.MEDIUM);
    logger.info('Producto añadido al carrito exitosamente');
  }

  /**
   * Verifica si aparece la confirmación de producto añadido
   * KAN-1212: Resultado esperado
   * 
   * @returns true si la confirmación es visible
   */
  async isCartConfirmationVisible(): Promise<boolean> {
    try {
      await this.waitForElement(this.selectors.cartConfirmation, TIMEOUTS.SHORT);
      return true;
    } catch {
      logger.warn('Confirmación de carrito no visible');
      return false;
    }
  }

  /**
   * Obtiene el número de productos en el carrito desde el contador
   * KAN-1212: Verificación de contador actualizado
   * 
   * @returns Número de productos en el carrito
   */
  async getCartCount(): Promise<number> {
    try {
      const counterText = await this.page.locator(this.selectors.cartCounter).textContent();
      const count = parseInt(counterText?.trim() || '0');
      logger.debug(`Contador de carrito: ${count}`);
      return count;
    } catch (error) {
      logger.error('Error obteniendo contador de carrito', error);
      return 0;
    }
  }

  /**
   * Verifica si hay productos en la lista
   * 
   * @returns true si hay al menos un producto
   */
  async hasProducts(): Promise<boolean> {
    const count = await this.page.locator(this.selectors.productCard).count();
    return count > 0;
  }

  /**
   * Obtiene el título del primer producto
   * 
   * @returns Título del primer producto
   */
  async getFirstProductTitle(): Promise<string> {
    await this.waitForResults();
    const titleElement = this.page.locator(this.selectors.productCard).first().locator(this.selectors.productTitle);
    return await titleElement.textContent() || '';
  }
}
```

---

### Paso 5: Generar Step Definitions

**Prompt para Copilot**:
```
Genera step definitions para el feature KAN-1212-add-to-cart.feature
siguiendo las mejores prácticas:
- Usa PageFactory para instanciar Page Objects
- Añade logging en cada step
- Assertions con mensajes descriptivos
- Manejo de errores apropiado
```

**Copilot genera** (`src/steps/KAN-1212.steps.ts`):
```typescript
/**
 * Step Definitions para KAN-1212
 * [MODA] Añadir producto desde PLP
 * 
 * Referencia: https://plataformas.atlassian.net/browse/KAN-1212
 */
import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PageFactory } from '../utils/page-factory';
import { logger } from '../utils/logger';

/**
 * WHEN - Acciones del usuario
 */

When('el usuario espera a que se carguen los resultados', async function () {
  logger.info('KAN-1212: Esperando carga de resultados');
  const plp = PageFactory.getProductListPage(this, this.page);
  await plp.waitForResults();
});

When('el usuario hace clic en {string} del primer producto', async function (actionText: string) {
  logger.info(`KAN-1212: Haciendo clic en "${actionText}" del primer producto`);
  
  const plp = PageFactory.getProductListPage(this, this.page);
  
  // Verificar que hay productos antes de intentar añadir
  const hasProducts = await plp.hasProducts();
  if (!hasProducts) {
    throw new Error('No hay productos disponibles para añadir al carrito');
  }
  
  await plp.addFirstProductToCart();
});

When('el usuario navega al carrito', async function () {
  logger.info('KAN-1212: Navegando al carrito');
  // Implementar navegación al carrito
  await this.page.click('[data-testid="cart-icon"], a[href*="cart"], a:has-text("Carrito")');
});

/**
 * THEN - Verificaciones
 */

Then('el producto debería agregarse al carrito', async function () {
  logger.info('KAN-1212: Verificando que producto se agregó al carrito');
  
  const plp = PageFactory.getProductListPage(this, this.page);
  const confirmed = await plp.isCartConfirmationVisible();
  
  expect(confirmed, 'KAN-1212: Debería aparecer confirmación de producto añadido').toBeTruthy();
});

Then('el contador del carrito debería mostrar {int} producto(s)', async function (expectedCount: number) {
  logger.info(`KAN-1212: Verificando contador de carrito = ${expectedCount}`);
  
  const plp = PageFactory.getProductListPage(this, this.page);
  const actualCount = await plp.getCartCount();
  
  expect(
    actualCount, 
    `KAN-1212: El contador debería mostrar ${expectedCount} producto(s), pero muestra ${actualCount}`
  ).toBe(expectedCount);
});

Then('debería aparecer confirmación de producto añadido', async function () {
  logger.info('KAN-1212: Verificando confirmación visible');
  
  const plp = PageFactory.getProductListPage(this, this.page);
  const isVisible = await plp.isCartConfirmationVisible();
  
  expect(isVisible, 'KAN-1212: Confirmación de producto añadido debería ser visible').toBeTruthy();
});

Then('el carrito debería contener {string}', async function (productName: string) {
  logger.info(`KAN-1212: Verificando que carrito contiene "${productName}"`);
  
  // Verificar que el producto está en el carrito
  const cartContent = await this.page.textContent('.cart-items, [data-testid="cart-items"]');
  
  expect(
    cartContent?.toLowerCase() || '', 
    `KAN-1212: El carrito debería contener "${productName}"`
  ).toContain(productName.toLowerCase());
});

Then('el total del carrito debería ser mayor que {int}', async function (minTotal: number) {
  logger.info(`KAN-1212: Verificando total del carrito > ${minTotal}`);
  
  const totalText = await this.page.textContent('.cart-total, [data-testid="cart-total"]');
  const total = parseFloat(totalText?.replace(/[^\d.,]/g, '').replace(',', '.') || '0');
  
  expect(
    total, 
    `KAN-1212: El total del carrito debería ser > ${minTotal}, pero es ${total}`
  ).toBeGreaterThan(minTotal);
});
```

---

### Paso 6: Actualizar PageFactory (si necesario)

**Copilot verifica si ProductListPage está en PageFactory**:

```typescript
// src/utils/page-factory.ts
export class PageFactory {
  // ... otros métodos ...

  /**
   * KAN-1212: Obtiene instancia de ProductListPage
   */
  static getProductListPage(context: any, page: Page): ProductListPage {
    if (!context.productListPage) {
      context.productListPage = new ProductListPage(page);
    }
    return context.productListPage;
  }
}
```

---

### Paso 7: Ejecutar Tests

**Comando**:
```bash
npm test -- features/KAN-1212-add-to-cart.feature
```

**Output esperado**:
```
info: KAN-1212: Esperando carga de resultados
info: KAN-1212: Añadiendo primer producto al carrito
info: KAN-1212: Producto añadido al carrito exitosamente
info: KAN-1212: Verificando que producto se agregó al carrito

✅ 2 scenarios (2 passed)
✅ 12 steps (12 passed)
⚡ 45s
```

---

## 🎯 Comandos Rápidos por Caso de Uso

### Caso 1: Implementar Test desde Ticket Nuevo

```
Prompt completo:
"Lee el ticket KAN-1212X desde Jira usando MCP de Atlassian.
Luego, usando MCP de Playwright, navega a [URL] y captura el DOM.
Finalmente, genera una implementación completa:
1. Feature file con referencia al ticket
2. Page Objects con selectores verificados desde DOM real
3. Step definitions siguiendo mejores prácticas
4. Actualiza PageFactory si es necesario"
```

### Caso 2: Mejorar Test Existente

```
Prompt:
"Analiza el feature KAN-1212-add-to-cart.feature.
Usa MCP de Playwright para verificar que todos los selectores 
en ProductListPage.ts funcionan en [URL].
Sugiere mejoras y actualiza selectores si es necesario."
```

### Caso 3: Debugging de Test Fallido

```
Prompt:
"El test KAN-1212 falla en el paso 'el usuario hace clic en Añadir'.
Usa MCP de Playwright para:
1. Navegar a [URL]
2. Tomar screenshot
3. Inspeccionar selectores de botón 'Añadir'
4. Sugerir solución"
```

### Caso 4: Generar Documentación

```
Prompt:
"Lee los tickets KAN-1212, KAN-1213, KAN-1214 desde Jira.
Genera un documento TESTING-COVERAGE.md que muestre:
- Tabla con tickets implementados
- Features asociados
- Cobertura de criterios de aceptación
- Estado de automatización"
```

---

## 📊 Validación de Selectores con MCP

**Prompt para validar todos los selectores**:
```
Usando MCP de Playwright, valida todos los selectores en ProductListPage.ts
navegando a https://www.example.com/search-nwx/?s=zapatillas%20nike

Para cada selector:
1. Intenta localizarlo
2. Verifica si es visible
3. Reporta si funciona o falla
4. Sugiere alternativa si falla
```

**Copilot ejecuta validación**:
```typescript
// Navegar
await mcp_microsoft_pla_browser_navigate({ 
  url: "https://www.example.com/search-nwx/?s=zapatillas%20nike" 
});

// Validar cada selector
const selectors = {
  productList: 'ul[aria-label="Lista de productos"]',
  productCard: '[data-testid="product-card"], article',
  addToCartBtn: '[data-testid="add-to-cart"], button:has-text("Añadir")',
  // ...
};

// Reporte de validación
Results:
✅ productList: OK (elemento encontrado, visible)
✅ productCard: OK (24 elementos encontrados)
⚠️ addToCartBtn: PARCIAL (data-testid no existe, pero button:has-text("Añadir") funciona)
✅ cartConfirmation: OK (encontrado, no visible hasta acción)

Sugerencias:
- addToCartBtn: Eliminar `[data-testid="add-to-cart"]` del selector
- Alternativa más robusta: `button[aria-label*="Añadir"]`
```

---

## 🔄 Flujo Completo Resumido

```
1️⃣ Leer Ticket Jira (MCP Atlassian)
   └─> Extraer: Título, Descripción, Pasos, Criterios

2️⃣ Generar Feature File
   └─> Gherkin con referencia a ticket

3️⃣ Analizar Página Real (MCP Playwright)
   └─> Capturar DOM, identificar elementos

4️⃣ Generar Page Objects
   └─> Selectores verificados, métodos por categoría

5️⃣ Generar Step Definitions
   └─> Logging, assertions, error handling

6️⃣ Ejecutar y Validar
   └─> npm test, revisar logs

7️⃣ Actualizar Ticket Jira (opcional)
   └─> Comentario: "Automatización completa"
```

---

## 📝 Checklist de Implementación con MCPs

Antes de considerar el test completo:

- [ ] ✅ Ticket leído desde Jira con MCP Atlassian
- [ ] ✅ Feature file con referencia al ticket (@KAN-1212X)
- [ ] ✅ Selectores validados con MCP Playwright en URL real
- [ ] ✅ Page Object con selectores jerarquizados
- [ ] ✅ Step definitions con logging y assertions
- [ ] ✅ PageFactory actualizado
- [ ] ✅ Tests ejecutados y pasando
- [ ] ✅ Screenshot de éxito guardado
- [ ] ✅ Comentario en ticket Jira (opcional)

---

## 🎓 Recursos Adicionales

- **Guía completa de MCPs**: `docs/MCP-GUIDE.md`
- **Instrucciones Copilot**: `.github/copilot-instructions.md`
- **Ejemplos reales**: `features/plp/moda.feature`

---

**✨ Con MCPs, la implementación de tests se reduce de horas a minutos!**
