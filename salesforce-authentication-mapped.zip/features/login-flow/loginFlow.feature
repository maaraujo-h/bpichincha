@salesforce
Feature: Salesforce Login flow - Signin
  As a Salesforce user
  I want to access the Salesforce lightning home URL
  So I can reach either the login page or the authenticated home safely

  Background:
    Given the user opens the Salesforce home entry page

  @auth @auth-bootstrap
  Scenario: Create an authorized reusable Salesforce session
    When the user signs in to Salesforce with configured credentials
    Then the Salesforce lightning home should be visible

  @auth-validation
  Scenario: Validate the stored Salesforce session
    Then the Salesforce lightning home should be visible
