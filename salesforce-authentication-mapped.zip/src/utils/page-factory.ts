import { Page } from '@playwright/test';
import { LoginFlowPage } from '../pages/loginFlowPage';

export class PageFactory {
  static getSalesforceLoginPage(
    context: any,
    page: Page
  ): LoginFlowPage {
    if (!context.loginFlowPage) {
      context.loginFlowPage = new LoginFlowPage(page);
    }
    return context.loginFlowPage;
  }
}
