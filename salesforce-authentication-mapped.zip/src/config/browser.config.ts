/**
 * Configuración mínima del navegador para la POC.
 */

export const BROWSER_CONFIG = {
  /**
   * Viewport por defecto
   */
  viewport: {
    width: 1920,
    height: 1080,
  },
  
  /**
   * Configura el idioma del navegador para alinearlo con el sitio objetivo.
   */
  locale: 'es-ES',
  
  launchArgs: [
    '--disable-dev-shm-usage',
  ] as const,
} as const;
