import { Before, After, AfterStep, Status, setDefaultTimeout } from '@cucumber/cucumber';
import * as fs from 'fs';
import * as path from 'path';
import { chromium, Browser, BrowserContext, Page } from '@playwright/test';
import dotenv from 'dotenv';
import { logger } from '../utils/logger'; 
import { BROWSER_CONFIG } from '../config/browser.config';
import { RUNTIME_CONFIG } from '../config/runtime.config';

// Carga el archivo .env cuando se ejecuta Cucumber directamente.
dotenv.config();

setDefaultTimeout(30_000);

// Referencias compartidas para reutilizarlas entre hooks.
let browser: Browser | undefined;
let context: BrowserContext | undefined;
let page: Page | undefined;

/**
 * Prepara el navegador y el contexto antes de cada escenario.
 */
Before(async function ({ pickle }) {
  logger.info('Starting new test scenario');

  const scenarioTags = pickle.tags.map((tag) => tag.name);
  const requiresInteractiveSalesforceAuth =
    scenarioTags.includes('@auth') && RUNTIME_CONFIG.allowManualOtp;

  // Detecta si el escenario es de invitado para omitir storage state.
  const isGuest = scenarioTags.includes('@guest');

  browser = await chromium.launch({
    headless: false,
    args: [...BROWSER_CONFIG.launchArgs],
  });

  const storageStatePath = path.resolve(RUNTIME_CONFIG.salesforceStorageStatePath);
  
  // Reutiliza storage state solo cuando el escenario no es de invitado.
  const hasStorageState =
    !isGuest && RUNTIME_CONFIG.useSalesforceStorageState && fs.existsSync(storageStatePath);
  if (RUNTIME_CONFIG.useSalesforceStorageState && !hasStorageState) {
    logger.warn(`Salesforce storage state not found at: ${storageStatePath}`);
  }

  // Crea el contexto del navegador con la configuración de anti-detección.
  context = await browser.newContext({
    viewport: BROWSER_CONFIG.viewport,
    locale: BROWSER_CONFIG.locale,
    proxy: RUNTIME_CONFIG.proxy,
    storageState: hasStorageState ? storageStatePath : undefined,
  });

  if (RUNTIME_CONFIG.traceOnFailure) {
    await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
  }

  page = await context.newPage();
  
  // Guarda las instancias para que los steps las usen.
  this.page = page;
  this.context = context;
  this.browser = browser;
});

/**
 * Captura evidencia tras cada paso cuando el paso falla.
 */
AfterStep(async function ({ result }) {
  const currentPage = this.page ?? page;
  if (currentPage && result && result.status === Status.FAILED && RUNTIME_CONFIG.screenshotOnFailure) {
    const screenshot = await currentPage.screenshot({ fullPage: true });
    this.attach(screenshot, 'image/png');
  }
});

/**
 * Limpia recursos y guarda evidencias al finalizar cada escenario.
 */
After(async function ({ result }) {
  logger.info(`Finishing scenario - Status: ${result?.status}`);

  // Si el escenario falló, guarda evidencia adicional.
  if (result && result.status === Status.FAILED) {
    // Guarda una captura adicional.
    if (page && !page.isClosed() && RUNTIME_CONFIG.screenshotOnFailure) {
      const screenshot = await page.screenshot({ fullPage: true });
      this.attach(screenshot, 'image/png');
    }
  }

  if (context && RUNTIME_CONFIG.traceOnFailure) {
    if (result && result.status === Status.FAILED) {
      fs.mkdirSync('traces', { recursive: true });
      // Usa una ruta compatible con cualquier plataforma.
      await context.tracing.stop({ path: `traces/trace-${Date.now()}.zip` });
    } else {
      await context.tracing.stop();
    }
  }

  // Cierra los recursos de forma segura y libera memoria.
  if (page) { await page.close(); page = undefined; }
  if (context) { await context.close(); context = undefined; }
  if (browser) { await browser.close(); browser = undefined; }
});
