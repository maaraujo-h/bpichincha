# Autenticación Salesforce con Playwright

Esta carpeta rescata únicamente el módulo de autenticación del framework
adjunto. Su propósito es crear una sesión autorizada con MFA manual y reutilizar
esa sesión en los casos de la POC, comenzando por `SGCI-5109`.

## Archivos mapeados

- `src/config/runtime.config.ts`: lee URL, credenciales y opciones de sesión.
- `src/pages/loginFlowPage.ts`: identifica login, MFA y Lightning Home.
- `src/support/hooks.ts`: abre el navegador y carga `storageState`.
- `features/login-flow/loginFlow.feature`: bootstrap y validación de la sesión.
- `storage-state/salesforce-auth.json`: se genera localmente; no está incluido.

## Preparación inicial

Desde esta carpeta:

```powershell
npm install
npm run playwright:install
Copy-Item .env.example .env
```

Edita `.env` y coloca la URL, usuario y contraseña autorizados para la POC.
Nunca envíes ni subas `.env` o `storage-state/salesforce-auth.json`.

## Crear o renovar la sesión

```powershell
npm run auth:bootstrap
```

Se abrirá Chromium. Completa el MFA manualmente y espera hasta visualizar
Lightning Home. Al finalizar se generará:

```text
storage-state/salesforce-auth.json
```

## Comprobar la sesión guardada

En `.env`, cambia temporalmente:

```dotenv
SALESFORCE_SAVE_STORAGE_STATE=false
SALESFORCE_ALLOW_MANUAL_OTP=false
```

Luego ejecuta:

```powershell
npm run auth:validate
```

La prueba debe llegar a Lightning Home reutilizando la sesión, sin escribir un
archivo nuevo.

## Capturar SGCI-5109 con Codegen

Después de generar la sesión:

```powershell
New-Item -ItemType Directory -Force tests\capturas
npx playwright codegen --load-storage=storage-state/salesforce-auth.json --output=tests/capturas/SGCI-5109-captura.spec.ts "$env:SALESFORCE_URL"
```

Si PowerShell no tiene cargada la variable, reemplaza
`"$env:SALESFORCE_URL"` por la URL autorizada de Salesforce.

## Alcance y seguridad

- El MFA no se omite: una persona lo completa durante el bootstrap.
- La sesión guardada contiene cookies y tokens; se excluye mediante `.gitignore`.
- No se incluyó el `.env` original del ZIP ni ningún valor sensible.
- La publicación automática en Xray Cloud se agregará después del primer caso
  funcional; este paquete cubre solamente autenticación y sesión.
